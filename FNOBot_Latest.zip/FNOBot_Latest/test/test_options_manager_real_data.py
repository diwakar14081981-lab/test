#!/usr/bin/env python3
"""
Test DeltaOptionsManager with REAL data fetching in paper trading mode
"""

import sys
sys.path.insert(0, 'D:\\Latest_Bot\\final_bot')

from live_trading_credentials import LIVE_API_KEY, LIVE_API_SECRET
from delta_options_manager import DeltaOptionsManager

print("="*70)
print("Testing DeltaOptionsManager - REAL Data in Paper Trading Mode")
print("="*70)

# Initialize in PAPER TRADING mode
manager = DeltaOptionsManager(LIVE_API_KEY, LIVE_API_SECRET, paper_trading=True)

print("\n1. Testing _get_btc_options() - should fetch REAL options...")
try:
    btc_options = manager._get_btc_options()
    print(f"   Result: Found {len(btc_options)} live BTC options")

    if len(btc_options) > 0:
        print(f"   SUCCESS: Fetched real options data")

        # Show sample option
        sample = btc_options[0]
        print(f"\n2. Sample option:")
        print(f"   Symbol: {sample.get('symbol')}")
        print(f"   Product ID: {sample.get('id')}")
        print(f"   Strike: {sample.get('strike_price')}")
        print(f"   Type: {sample.get('contract_type')}")

        # Test finding a specific option
        print(f"\n3. Testing _find_option_product()...")
        from datetime import datetime, timedelta

        # Get next day expiry
        expiry = manager._get_next_day_expiry()

        # Get ATM strike for current BTC price (assume ~93000)
        spot_price = 93000
        atm_strike = manager._find_atm_strike(spot_price, 'BTCUSD')

        print(f"   Looking for: Strike={atm_strike}, Type=put, Expiry={expiry.strftime('%Y-%m-%d')}")

        option_product = manager._find_option_product(atm_strike, 'put', expiry)

        if option_product:
            print(f"   ✓ FOUND OPTION:")
            print(f"     Symbol: {option_product.get('symbol')}")
            print(f"     Product ID: {option_product.get('id')}")
            print(f"     Strike: {option_product.get('strike_price')}")

            # Verify it's NOT 999999 (fake ID)
            if option_product.get('id') != 999999:
                print(f"   REAL PRODUCT ID (not 999999)")
            else:
                print(f"   FAILED: Still using fake product ID!")
        else:
            print(f"   No matching option found")
            print(f"   Note: Option might not exist for next day expiry")

    else:
        print(f"   FAILED: No options fetched")

except Exception as e:
    print(f"   ERROR: {e}")
    import traceback
    traceback.print_exc()

print("\n" + "="*70)
