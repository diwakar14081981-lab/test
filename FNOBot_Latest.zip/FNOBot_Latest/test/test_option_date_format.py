#!/usr/bin/env python3
"""
Check Delta Exchange option date format
"""

import sys
sys.path.insert(0, 'D:\\Latest_Bot\\final_bot')

from live_trading_credentials import LIVE_API_KEY, LIVE_API_SECRET
from delta_options_manager import DeltaOptionsManager

print("="*70)
print("Checking Delta Exchange Option Date Format")
print("="*70)

manager = DeltaOptionsManager(LIVE_API_KEY, LIVE_API_SECRET, paper_trading=True)

# Get all options
btc_options = manager._get_btc_options()

print(f"\nFound {len(btc_options)} options")
print("\nChecking date formats in settlement_time vs symbol:")

# Show first 5 options to see the pattern
for i, opt in enumerate(btc_options[:5]):
    symbol = opt.get('symbol', '')
    settlement_time = opt.get('settlement_time', '')
    strike = opt.get('strike_price')

    print(f"\n{i+1}. Symbol: {symbol}")
    print(f"   Settlement Time: {settlement_time}")
    print(f"   Settlement Date part: {settlement_time[:10]}")
    print(f"   Strike: {strike}")

# Look for specific next-day option
print("\n" + "="*70)
print("Looking for options expiring on 2025-11-20:")

target_date = '2025-11-20'
matching = [opt for opt in btc_options if opt.get('settlement_time', '')[:10] == target_date]

print(f"\nFound {len(matching)} options with settlement_time starting with {target_date}")

if matching:
    print("\nSample matches:")
    for opt in matching[:3]:
        print(f"  Symbol: {opt.get('symbol')}, Strike: {opt.get('strike_price')}, Type: {opt.get('contract_type')}")

print("\n" + "="*70)
