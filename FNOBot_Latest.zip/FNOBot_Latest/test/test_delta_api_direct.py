#!/usr/bin/env python3
"""Direct API test using requests"""

import sys
sys.path.insert(0, 'D:\\Latest_Bot\\final_bot')

from live_trading_credentials import LIVE_API_KEY, LIVE_API_SECRET
from delta_rest_client import DeltaRestClient

print("="*70)
print("Testing Delta Exchange API - Direct Method")
print("="*70)

client = DeltaRestClient(
    base_url='https://api.india.delta.exchange',
    api_key=LIVE_API_KEY,
    api_secret=LIVE_API_SECRET
)

print("\n1. Testing direct request() method to get products...")
try:
    # Use the request method directly
    response = client.request('GET', '/v2/products')
    print(f"   Response type: {type(response)}")

    # Parse JSON from response
    data = response.json()
    print(f"   Data type: {type(data)}")
    print(f"   Data keys: {list(data.keys()) if isinstance(data, dict) else 'Not a dict'}")

    if 'result' in data:
        products = data['result']
        print(f"   Total products: {len(products)}")

        # Find BTC options
        btc_options = [p for p in products
                      if 'BTC' in p.get('symbol', '')
                      and p.get('contract_type') in ['call_options', 'put_options']
                      and p.get('state') == 'live']

        print(f"   Live BTC options: {len(btc_options)}")

        if btc_options:
            sample = btc_options[0]
            print(f"\n2. Sample option: {sample.get('symbol')}")
            print(f"   Product ID: {sample.get('id')}")
            print(f"   Strike: {sample.get('strike_price')}")
            print(f"   Mark Price: {sample.get('mark_price')}")

            # Now test fetching single product with get_ticker
            product_id = sample.get('id')
            print(f"\n3. Testing get_ticker({product_id})...")
            ticker_detail = client.get_ticker(product_id)
            print(f"   Ticker type: {type(ticker_detail)}")

            if isinstance(ticker_detail, dict):
                print(f"   Ticker keys: {list(ticker_detail.keys())}")
                print(f"   Mark Price: {ticker_detail.get('mark_price')}")
                print(f"   Close: {ticker_detail.get('close')}")
                print(f"   Last Traded Price: {ticker_detail.get('last_traded_price')}")
            else:
                # It might be a Response object
                ticker_data = ticker_detail.json() if hasattr(ticker_detail, 'json') else ticker_detail
                print(f"   Ticker data: {ticker_data}")
                if isinstance(ticker_data, dict) and 'result' in ticker_data:
                    result = ticker_data['result']
                    print(f"   Mark Price: {result.get('mark_price')}")

except Exception as e:
    print(f"   ERROR: {e}")
    import traceback
    traceback.print_exc()

print("\n" + "="*70)
