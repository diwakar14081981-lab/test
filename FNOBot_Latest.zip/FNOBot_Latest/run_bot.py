#!/usr/bin/env python3
"""
Simple script to run the BTC Futures Scalping Bot
"""

from live_trading_bot_realtime import LiveTradingBotRealtime

if __name__ == "__main__":
    print("="*70)
    print("BTC FUTURES SCALPING BOT - STARTING...")
    print("="*70)
    print()
    print("IMPORTANT:")
    print("- Config files are now in config/ folder")
    print("- Switch strategies in config/config_loader.py (ACTIVE_STRATEGY)")
    print("- Edit config/scalping_config.py or config/swing_supertrend_config.py")
    print("- Set paper_trading=False below for live trading")
    print("- Press Ctrl+C to stop the bot gracefully")
    print()
    print("="*70)

    # Enter your Delta Exchange API credentials here
    API_KEY = 'GQkBVk4mVnazOzOib2Jm11V3XDz1Nk'
    API_SECRET = '4TFECpYeoR3DY1xxyEHj1mpY7WlWSSAcRQHKL7WgL1rwDFkGwlbHB9SH8Tdh'

    # Create and start bot
    bot = LiveTradingBotRealtime(
        api_key=API_KEY,
        api_secret=API_SECRET,
        paper_trading=True  # Set to False for live trading
    )

    # Start trading
    bot.start()
