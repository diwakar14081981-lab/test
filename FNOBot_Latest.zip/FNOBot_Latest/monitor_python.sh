#!/bin/bash

# Python Process Monitor Script
# Usage: ./monitor_python.sh <your_python_script.py> [args...]

if [ $# -eq 0 ]; then
    echo "Usage: $0 <python_script.py> [arguments...]"
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "$1")" && pwd)"
SCRIPT_NAME="$(basename "$1")"
LOG_FILE="${SCRIPT_DIR}/process_kill_log.txt"

echo "===============================================" >> "$LOG_FILE"
echo "Process Monitor Started" >> "$LOG_FILE"
echo "Timestamp: $(date '+%Y-%m-%d %H:%M:%S')" >> "$LOG_FILE"
echo "Script: $1" >> "$LOG_FILE"
echo "Arguments: ${@:2}" >> "$LOG_FILE"
echo "-----------------------------------------------" >> "$LOG_FILE"

# Capture initial memory state
echo "Initial Memory State:" >> "$LOG_FILE"
free -h >> "$LOG_FILE"
echo "" >> "$LOG_FILE"

# Run the Python script and capture its PID
python3 "$@" &
PID=$!

echo "Python PID: $PID" >> "$LOG_FILE"
echo "" >> "$LOG_FILE"

# Wait for the process to complete
wait $PID
EXIT_CODE=$?

# Log the exit information
echo "-----------------------------------------------" >> "$LOG_FILE"
echo "Process Terminated" >> "$LOG_FILE"
echo "Timestamp: $(date '+%Y-%m-%d %H:%M:%S')" >> "$LOG_FILE"
echo "Exit Code: $EXIT_CODE" >> "$LOG_FILE"
echo "" >> "$LOG_FILE"

# Interpret exit code
if [ $EXIT_CODE -eq 137 ]; then
    echo "Exit Status: KILLED (SIGKILL - likely OOM killer)" >> "$LOG_FILE"
elif [ $EXIT_CODE -eq 139 ]; then
    echo "Exit Status: SEGMENTATION FAULT" >> "$LOG_FILE"
elif [ $EXIT_CODE -eq 130 ]; then
    echo "Exit Status: TERMINATED (Ctrl+C)" >> "$LOG_FILE"
elif [ $EXIT_CODE -eq 0 ]; then
    echo "Exit Status: SUCCESS" >> "$LOG_FILE"
else
    echo "Exit Status: ERROR (code $EXIT_CODE)" >> "$LOG_FILE"
fi
echo "" >> "$LOG_FILE"

# Final memory state
echo "Final Memory State:" >> "$LOG_FILE"
free -h >> "$LOG_FILE"
echo "" >> "$LOG_FILE"

# Check for OOM killer messages
echo "Checking for OOM Killer Messages:" >> "$LOG_FILE"
RECENT_OOM=$(dmesg | grep -i "out of memory\|killed process" | tail -5)
if [ -n "$RECENT_OOM" ]; then
    echo "$RECENT_OOM" >> "$LOG_FILE"
else
    echo "No OOM messages found" >> "$LOG_FILE"
fi

echo "===============================================" >> "$LOG_FILE"
echo "" >> "$LOG_FILE"

# Also print to console
echo "Process terminated with exit code: $EXIT_CODE"
echo "Log written to: $LOG_FILE"

exit $EXIT_CODE
