"""
Config module for trading strategies
"""
from .config_loader import load_config, get_active_strategy_name, print_strategy_info, validate_config
from .scalping_config import ScalpingConfig
from .swing_supertrend_config import SwingSupertrendConfig

__all__ = [
    'load_config',
    'get_active_strategy_name',
    'print_strategy_info',
    'validate_config',
    'ScalpingConfig',
    'SwingSupertrendConfig'
]
