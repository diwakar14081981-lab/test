#!/usr/bin/env python3
"""
Live Trading Bot - Real-time Candle Building
Marubozu + Breakout Strategy with Real-time OHLC candles built from price ticks
"""

import sys
import time
import signal
import logging
from logging.handlers import TimedRotatingFileHandler
import os
import csv
from datetime import datetime, timedelta
from threading import Event
import traceback
import pandas as pd

# Local imports
from config import load_config, get_active_strategy_name, print_strategy_info
from delta_exchange_client import DeltaExchangeClient
from btc_futures_scalping import calculate_supertrend, calculate_adx, calculate_atr, calculate_volume_filter
from delta_order_manager import DeltaOrderManager
from delta_options_manager import DeltaOptionsManager
from live_trading_credentials import LIVE_API_KEY, LIVE_API_SECRET
from swing_supertrend_strategy import (
    identify_swing_points,
    calculate_288_ema,
    detect_swing_entry_signal,
    update_swing_trailing_stop,
    check_swing_exit,
    calculate_initial_stop_loss
)


class StdoutLogger:
    """Wrapper to redirect stdout to both console and log file"""
    def __init__(self, terminal, logger):
        self.terminal = terminal
        self.logger = logger

    def write(self, message):
        # Write to original stdout (console)
        self.terminal.write(message)
        # Also log to file (skip empty messages and single newlines)
        if message.strip():
            # Remove trailing newline as logger adds it automatically
            self.logger.info(message.rstrip('\n'))

    def flush(self):
        # Flush the original stdout
        self.terminal.flush()


class LiveTradingBotRealtime:
    """Live trading bot with real-time candle building"""

    def __init__(self, api_key=None, api_secret=None, paper_trading=True):
        """Initialize live trading bot"""
        self.config = load_config()
        self.strategy_name = get_active_strategy_name()
        self.paper_trading = paper_trading
        self.running = False
        self.shutdown_event = Event()
        self.logger = self._setup_logging()

        # Redirect stdout to capture print() statements to log file
        self.original_stdout = sys.stdout
        sys.stdout = StdoutLogger(self.original_stdout, logging.getLogger())

        # CSV logging setup
        self.trades_csv_file = self._setup_trades_csv()

        # Initialize Delta Exchange client
        if not api_key or not api_secret:
            self.logger.warning("No API keys provided, using demo credentials")
            api_key = "DEMO_KEY"
            api_secret = "DEMO_SECRET"

        self.delta_client = DeltaExchangeClient(
            api_key=api_key,
            api_secret=api_secret,
            paper_trading=paper_trading
        )

        # Initialize order manager for order execution
        # Route to options manager if OPTION_SELLING flag is True
        if getattr(self.config, 'OPTION_SELLING', False):
            self.order_manager = DeltaOptionsManager(
                api_key=LIVE_API_KEY,
                api_secret=LIVE_API_SECRET,
                paper_trading=paper_trading
            )
            self.logger.info("Using OPTIONS MANAGER for execution (selling ATM weekly options)")
        else:
            self.order_manager = DeltaOrderManager(
                api_key=LIVE_API_KEY,
                api_secret=LIVE_API_SECRET,
                paper_trading=paper_trading
            )
            self.logger.info("Using FUTURES MANAGER for execution")

        # Parse entry timeframe to minutes
        self.entry_minutes = self._parse_timeframe_to_minutes(self.config.ENTRY_TIMEFRAME)

        # Trading state
        self.current_position = None
        self.pending_signal = None
        self.bot_start_time = None  # Track when bot started
        self.first_complete_candle_seen = False  # Track if we've seen first complete candle
        self.last_exit_time = None  # Track last exit time for cooldown period

        # Store higher timeframe candles as instance variables (no cache, just storage)
        self.df_30m_global = None
        self.df_1h_global = None
        self.df_entry_tf_global = None  # Cache for entry timeframe candles during position monitoring
        self.last_30m_fetch_time = None  # Track when we last fetched 30m candles
        self.last_1h_fetch_time = None  # Track when we last fetched 1h candles
        self.last_entry_tf_fetch_time = None  # Track when we last fetched entry TF candles (for position monitoring)
        self.last_checked_candle_time = None  # Track last checked entry candle to prevent missing candles during errors

        # Real-time swing breakout monitoring (pre-flight conditions)
        self.swing_high_level = None  # Most recent confirmed swing high
        self.swing_low_level = None   # Most recent confirmed swing low
        self.ema_288_value = None     # Latest 288 EMA value
        self.supertrend_1h_direction = None  # 1 = bullish, -1 = bearish
        self.long_conditions_met = False  # 288 EMA + 1H ST aligned for LONG
        self.short_conditions_met = False  # 288 EMA + 1H ST aligned for SHORT
        self.last_swing_calculation_time = None  # Track when swings were last calculated

        # Statistics
        self.stats = {
            'start_time': None,
            'total_trades': 0,
            'winning_trades': 0,
            'losing_trades': 0,
            'total_pnl': 0.0,
            'last_error': None,
            'error_count': 0
        }

        # Signal handlers
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)

        self.logger.info("="*70)
        self.logger.info("BTC FUTURES SCALPING BOT - REAL-TIME CANDLES")
        self.logger.info("="*70)
        self.logger.info(f"Mode: {'PAPER TRADING' if paper_trading else 'LIVE TRADING'}")
        self.logger.info(f"Exchange: {self.config.EXCHANGE}")
        self.logger.info(f"Symbol: {self.config.TRADING_SYMBOL}")
        self.logger.info(f"Active Strategy: {self.strategy_name}")
        self.logger.info("")

        # Print detailed strategy information
        print_strategy_info()

    def _setup_logging(self):
        """Setup logging for ALL modules (including strategy modules)"""
        # Configure root logger first - this ensures ALL loggers inherit the config
        root_logger = logging.getLogger()
        root_logger.setLevel(logging.INFO)

        # Clear any existing handlers to avoid duplicates
        root_logger.handlers = []

        # Console handler (existing)
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        console_formatter = logging.Formatter(
            '%(asctime)s - %(levelname)s - %(message)s',
            datefmt='%H:%M:%S'
        )
        console_handler.setFormatter(console_formatter)
        root_logger.addHandler(console_handler)

        # File handler with daily rotation at midnight
        logs_dir = os.path.join(os.path.dirname(__file__), 'logs')
        os.makedirs(logs_dir, exist_ok=True)

        # Base log filename (date will be appended automatically by TimedRotatingFileHandler)
        log_filename = "trading_bot.log"
        log_filepath = os.path.join(logs_dir, log_filename)

        # TimedRotatingFileHandler: rotates at midnight UTC, keeps 90 days
        file_handler = TimedRotatingFileHandler(
            log_filepath,
            when='midnight',      # Rotate at midnight
            interval=1,           # Every 1 day
            backupCount=90,       # Keep 90 days of logs (set to 0 for unlimited)
            encoding='utf-8',
            utc=True             # Use UTC time (matches your trading times)
        )
        file_handler.setLevel(logging.INFO)
        file_formatter = logging.Formatter(
            '%(asctime)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        file_handler.setFormatter(file_formatter)
        root_logger.addHandler(file_handler)

        # Now create bot-specific logger that inherits from root
        logger = logging.getLogger('LiveTradingBotRealtime')

        return logger

    def _parse_timeframe_to_minutes(self, timeframe):
        """Parse timeframe string to minutes"""
        timeframe_map = {
            '1min': 1,
            '3min': 3,
            '5min': 5,
            '15min': 15,
            '30min': 30,
            '1h': 60,
            '2h': 120,
            '4h': 240,
            '1d': 1440
        }
        return timeframe_map.get(timeframe, 5)  # Default to 5 minutes

    def _get_reference_time(self, current_time):
        """Get reference time (17:30 UTC) for candle alignment"""
        reference_time = current_time.replace(hour=17, minute=30, second=0, microsecond=0)
        if current_time < reference_time:
            reference_time -= timedelta(days=1)
        return reference_time

    def _setup_trades_csv(self):
        """Setup CSV file for trade logging"""
        # Create trades directory if it doesn't exist
        trades_dir = os.path.join(os.path.dirname(__file__), 'trades')
        os.makedirs(trades_dir, exist_ok=True)

        # Differentiate file name based on trading mode
        option_selling = getattr(self.config, 'OPTION_SELLING', False)
        trade_type = 'options' if option_selling else 'futures'
        csv_filename = f'live_trades_{trade_type}_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
        csv_filepath = os.path.join(trades_dir, csv_filename)

        # Different headers for futures vs options
        if option_selling:
            # OPTIONS: Track option-specific data
            headers = [
                'trade_id',
                'entry_time',
                'exit_time',
                'direction',              # LONG or SHORT (based on spot signal)
                'option_symbol',          # e.g., P-BTC-93000-201125
                'option_type',            # PUT or CALL
                'strike_price',           # Strike price of option
                'spot_entry_price',       # Spot price at entry
                'spot_exit_price',        # Spot price at exit
                'option_entry_price',     # Premium received when selling
                'option_exit_price',      # Premium paid when buying back
                'stop_loss',              # Stop loss on spot price
                'trailing_stop_final',    # Final trailing stop on spot
                'position_size_usd',      # Position size in USD
                'lots',                   # Number of lots/contracts
                'first_candle_body_pct',
                'first_candle_range',
                'entry_atr',
                'trend_30m',
                'trend_1h',
                'highest_spot_price',     # Highest spot price during trade
                'lowest_spot_price',      # Lowest spot price during trade
                'exit_reason',
                'hold_time_minutes',
                'gross_pnl',
                'commission',
                'net_pnl',
                'pnl_pct',
                'cumulative_pnl'
            ]
        else:
            # FUTURES: Original format
            headers = [
                'trade_id',
                'entry_time',
                'exit_time',
                'direction',
                'entry_price',
                'exit_price',
                'take_profit',
                'stop_loss',
                'trailing_stop_final',
                'position_size_base',
                'position_size_usd',
                'leverage',
                'first_candle_body_pct',
                'first_candle_range',
                'entry_atr',
                'trend_30m',
                'trend_1h',
                'partial_profits_taken',
                'highest_price',
                'lowest_price',
                'highest_profit_pips',
                'lowest_profit_pips',
                'exit_reason',
                'hold_time_minutes',
                'gross_pnl',
                'commission',
                'net_pnl',
                'pnl_pct',
                'cumulative_pnl'
            ]

        # Create CSV file with headers
        with open(csv_filepath, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(headers)

        self.logger.info(f"Trade logging CSV created: {csv_filepath} (Mode: {trade_type.upper()})")
        return csv_filepath

    def _signal_handler(self, signum, frame):
        """Handle shutdown signals"""
        signal_name = 'SIGINT' if signum == signal.SIGINT else 'SIGTERM'
        self.logger.info(f"Received {signal_name}, shutting down...")
        self.shutdown()

    def _should_fetch_higher_tf_candles(self, current_time, timeframe):
        """
        Determine if we should fetch new higher timeframe candles
        Reference time: 17:30 UTC
        30m candles close at: X:00 and X:30
        1h candles close at: X:30
        """
        if timeframe == '30m':
            # Check if we've crossed a 30-minute boundary (X:00 or X:30)
            if self.last_30m_fetch_time is None:
                return True  # First fetch

            # Get current and last fetch minute
            current_minute = current_time.minute
            last_minute = self.last_30m_fetch_time.minute

            # 30m candles close when minute is 00 or 30
            current_boundary = (current_minute // 30) * 30  # 0 or 30
            last_boundary = (last_minute // 30) * 30

            # Check if we crossed into a new 30-minute period
            if current_time.hour != self.last_30m_fetch_time.hour:
                return True
            if current_boundary != last_boundary:
                return True

            return False

        elif timeframe == '1h':
            # Check if we've crossed an hourly boundary (X:30)
            if self.last_1h_fetch_time is None:
                return True  # First fetch

            # 1h candles close at minute 30
            # Check if current time is past X:30 and last fetch was before X:30
            current_minute = current_time.minute
            last_minute = self.last_1h_fetch_time.minute

            # Check if hour changed
            if current_time.hour != self.last_1h_fetch_time.hour:
                # If we're past minute 30, we've crossed a boundary
                if current_minute >= 30:
                    return True

            # Within same hour, check if we crossed minute 30
            if last_minute < 30 <= current_minute:
                return True

            return False

        return False

    def _should_fetch_entry_tf_candles(self, current_time):
        """
        Determine if we should fetch new entry timeframe candles
        Only fetch when a new candle has actually closed
        Reference time: 17:30 UTC
        """
        if self.last_entry_tf_fetch_time is None:
            return True  # First fetch

        # Get candle interval in minutes
        interval_minutes = self.entry_minutes

        # Calculate time since last fetch
        time_diff = (current_time - self.last_entry_tf_fetch_time).total_seconds() / 60

        # Only fetch if at least one full candle period has passed
        if time_diff >= interval_minutes:
            # Additional check: align with candle boundaries
            # For 1min: fetch every minute (X:00, X:01, X:02, etc.)
            # For 5min: fetch at X:30, X:35, X:40, X:45, X:50, X:55, X:00, X:05, etc.
            current_minutes_since_reference = (current_time.hour * 60 + current_time.minute) - (17 * 60 + 30)
            last_minutes_since_reference = (self.last_entry_tf_fetch_time.hour * 60 + self.last_entry_tf_fetch_time.minute) - (17 * 60 + 30)

            current_candle_num = current_minutes_since_reference // interval_minutes
            last_candle_num = last_minutes_since_reference // interval_minutes

            # Fetch if we're in a different candle period
            if current_candle_num != last_candle_num:
                return True

        return False

    def _calculate_atr(self, timeframe='5min', period=14):
        """Calculate Average True Range for trailing stop"""
        try:
            # Fetch candles from Delta Exchange API
            df = self.delta_client.get_historical_data(
                symbol=self.config.TRADING_SYMBOL,
                resolution=timeframe,
                lookback_candles=period + 10
            )

            if df is None or len(df) < period + 1:
                return None

            df = df.sort_values('timestamp').reset_index(drop=True)

            # Calculate True Range
            high_low = df['high'] - df['low']
            high_close = abs(df['high'] - df['close'].shift())
            low_close = abs(df['low'] - df['close'].shift())

            true_range = high_low.combine(high_close, max).combine(low_close, max)

            # Calculate ATR as simple moving average of True Range
            atr = true_range.rolling(window=period).mean().iloc[-1]

            return atr
        except Exception as e:
            self.logger.error(f"Error calculating ATR: {e}")
            return None

    def start(self):
        """Start the live trading bot"""
        if self.running:
            self.logger.warning("Bot is already running")
            return

        self.running = True
        self.stats['start_time'] = datetime.now()
        self.bot_start_time = datetime.now()  # Track bot start time

        self.logger.info("Starting live trading bot...")
        self.logger.info(f"Configuration:")
        self.logger.info(f"  - Position Size: ${self.config.POSITION_SIZE_DOLLARS:,.0f}")
        self.logger.info(f"  - Leverage: {self.config.LEVERAGE}x")
        self.logger.info(f"  - Entry Timeframe: {self.config.ENTRY_TIMEFRAME}")

        # Strategy-specific configuration display
        if self.strategy_name == 'SWING_SUPERTREND':
            self.logger.info(f"  - Exit Method: Swing Trailing Stop")
            self.logger.info(f"  - Stop Loss Buffer: {self.config.STOP_LOSS_BUFFER_PCT}%")
            self.logger.info(f"  - 288 EMA Filter: {'Enabled' if self.config.USE_288_EMA_FILTER else 'Disabled'}")
            tf_display = self.config.SUPERTREND_TIMEFRAME.upper()
            self.logger.info(f"  - {tf_display} SuperTrend Filter: {'Enabled' if self.config.USE_SUPERTREND_FILTER else 'Disabled'}")
            self.logger.info(f"  - Swing Lookback: {self.config.SWING_LOOKBACK_CANDLES} candles")
        else:
            # Marubozu strategy config
            self.logger.info(f"  - TP: {self.config.TAKE_PROFIT_PIPS} pips")
            self.logger.info(f"  - SL: {self.config.STOP_LOSS_PIPS} pips")
            self.logger.info(f"  - Trend Confirmation: {'Enabled' if hasattr(self.config, 'USE_TREND_CONFIRMATION') and self.config.USE_TREND_CONFIRMATION else 'Disabled'}")
            self.logger.info(f"  - ADX Filter: {'Enabled' if hasattr(self.config, 'USE_ADX_FILTER') and self.config.USE_ADX_FILTER else 'Disabled'}")

        self.logger.info("="*70)

        # Test connectivity
        try:
            self.logger.info("Testing Delta Exchange connectivity...")
            current_price = self.delta_client.get_current_price(self.config.TRADING_SYMBOL)
            self.logger.info(f"[OK] Connected! Current {self.config.TRADING_SYMBOL} price: ${current_price:,.2f}")
            self.logger.info("="*70)
            self.logger.info("[INFO] Monitoring market for entry signals")
            self.logger.info("[INFO] Fetching candles from Delta Exchange API")
            self.logger.info(f"[INFO] Entry timeframe: {self.config.ENTRY_TIMEFRAME} ({self.entry_minutes} minutes)")
            self.logger.info("="*70)

        except Exception as e:
            self.logger.error(f"[ERROR] Failed to connect: {e}")
            self.running = False
            return

        try:
            self._run_main_loop()
        except Exception as e:
            self.logger.error(f"Fatal error: {e}")
            self.logger.debug(traceback.format_exc())
        finally:
            self.shutdown()

    def _run_main_loop(self):
        """Main trading loop - Updates price every second, builds candles in real-time"""
        self.logger.info("Entering main trading loop...")
        self.logger.info("Price updates: Every 1 second (building candles)")
        self.logger.info("Entry/Exit Monitoring: Every 15 seconds")
        self.logger.info(f"{self.config.TRADING_SYMBOL} Price Display: Every 30 seconds")
        self.logger.info("Candle detection: Real-time (synchronized with Delta Exchange)")
        self.logger.info("="*70)

        retry_count = 0
        max_retries = 5
        loop_counter = 0
        price_display_counter = 0
        skip_first_candle = True  # Skip first partial candle on bot start

        while self.running and not self.shutdown_event.is_set():
            try:
                # Get current price for configured symbol
                current_price = self.delta_client.get_current_price(self.config.TRADING_SYMBOL)

                # Calculate when next candle closes (based on ENTRY_TIMEFRAME)
                current_time = datetime.now()
                current_second = current_time.second

                # Check for any missed candles (e.g., during error recovery)
                self._check_for_missed_candles(current_time)

                # Check if we're at a candle boundary for the configured ENTRY_TIMEFRAME
                # Calculate minutes elapsed since reference time (5:30 PM)
                reference_time = self._get_reference_time(current_time)
                time_diff = current_time - reference_time
                minutes_elapsed = time_diff.total_seconds() / 60

                # Check if current time aligns with candle boundary
                # For 3min: should trigger at 0, 3, 6, 9, 12, 15, 18, 21... minutes past reference
                # For 1min: should trigger at every minute
                # For 5min: should trigger at 0, 5, 10, 15, 20... minutes past reference
                minutes_remainder = minutes_elapsed % self.entry_minutes
                is_at_candle_boundary = current_second == 0 and minutes_remainder < 0.02

                # Only check for candles at proper timeframe boundaries
                if is_at_candle_boundary:
                    # We're exactly at candle close time for this timeframe
                    if not self.current_position:
                        # Fetch latest candles from API
                        df_entry_check = self.delta_client.get_historical_data(
                            symbol=self.config.TRADING_SYMBOL,
                            resolution=self.config.ENTRY_TIMEFRAME,
                            lookback_candles=5
                        )

                        if df_entry_check is not None and len(df_entry_check) > 0:
                            df_entry_check = df_entry_check.sort_values('timestamp').reset_index(drop=True)
                            latest_candle = df_entry_check.iloc[-1]
                            latest_candle_timestamp = latest_candle['timestamp']

                            # Skip first partial candle
                            if skip_first_candle:
                                skip_first_candle = False
                                self.logger.info("="*70)
                                self.logger.info(f"[BOT STARTED] Skipping partial candle, waiting for next complete candle...")
                                self.logger.info("="*70)
                                # Update last checked time even when skipping
                                self.last_checked_candle_time = current_time
                            else:
                                # Process the new candle
                                self.logger.info("="*70)
                                self.logger.info(f"[{self.config.ENTRY_TIMEFRAME.upper()} CANDLE CLOSED] at {current_time.strftime('%H:%M:%S')}")
                                self.logger.info(f"  OHLC: O:{latest_candle['open']:.2f} H:{latest_candle['high']:.2f} L:{latest_candle['low']:.2f} C:{latest_candle['close']:.2f}")
                                self._check_for_signal()
                                # Update last checked candle time after processing
                                self.last_checked_candle_time = current_time

                        # Sleep for 1 second to avoid multiple triggers at second=0
                        time.sleep(1)

                # Every 15 seconds: monitor for breakout/position
                loop_counter += 1
                if loop_counter >= 15:  # 15 seconds (since we sleep 1 second each loop)
                    loop_counter = 0

                    # Check real-time swing breakout (new entry logic)
                    if not self.current_position:
                        self._check_realtime_breakout(current_price)

                    # Monitor pending signal for breakout (old breakout logic - may be removed)
                    if self.pending_signal and not self.current_position:
                        self._monitor_breakout_entry(current_price)

                    # Monitor existing position
                    if self.current_position:
                        self._monitor_position(current_price)

                # Every 30 seconds: display current price
                price_display_counter += 1
                if price_display_counter >= 30:  # 30 seconds
                    price_display_counter = 0
                    self.logger.info(f"[{self.config.TRADING_SYMBOL} Price] ${current_price:,.2f}")

                # Sleep for 1 second
                time.sleep(1)

                # Reset retry count
                retry_count = 0

            except KeyboardInterrupt:
                self.logger.info("Keyboard interrupt received")
                break

            except Exception as e:
                retry_count += 1
                self.stats['error_count'] += 1
                self.stats['last_error'] = str(e)

                self.logger.error(f"Error in main loop (attempt {retry_count}/{max_retries}): {e}")
                self.logger.debug(traceback.format_exc())

                if retry_count >= max_retries:
                    self.logger.error(f"Max retries reached, shutting down")
                    break

                backoff_time = min(2 ** retry_count, 60)
                self.logger.info(f"Waiting {backoff_time}s before retry...")
                time.sleep(backoff_time)

    def _check_for_missed_candles(self, current_time):
        """Check if we missed any candle boundaries during errors and process them"""
        try:
            # If we haven't checked any candle yet, nothing to catch up
            if self.last_checked_candle_time is None:
                return

            # If we have a position, don't check for new signals
            if self.current_position:
                return

            # Calculate how many candle periods have passed since last check
            time_diff = current_time - self.last_checked_candle_time
            minutes_diff = time_diff.total_seconds() / 60

            # Check if we missed one or more candle boundaries
            candle_minutes = self.entry_minutes
            candles_missed = int(minutes_diff / candle_minutes)

            # If we missed at least one candle boundary
            if candles_missed >= 1:
                self.logger.warning(f"[MISSED CANDLE DETECTION] Detected {candles_missed} missed candle(s) during error recovery")

                # Fetch latest candles to process the most recent one
                df_entry_check = self.delta_client.get_historical_data(
                    symbol=self.config.TRADING_SYMBOL,
                    resolution=self.config.ENTRY_TIMEFRAME,
                    lookback_candles=5
                )

                if df_entry_check is not None and len(df_entry_check) > 0:
                    df_entry_check = df_entry_check.sort_values('timestamp').reset_index(drop=True)
                    latest_candle = df_entry_check.iloc[-1]

                    # Process the missed candle
                    self.logger.info("="*70)
                    self.logger.info(f"[{self.config.ENTRY_TIMEFRAME.upper()} CANDLE CLOSED - RECOVERED] at {current_time.strftime('%H:%M:%S')}")
                    self.logger.info(f"  OHLC: O:{latest_candle['open']:.2f} H:{latest_candle['high']:.2f} L:{latest_candle['low']:.2f} C:{latest_candle['close']:.2f}")
                    self._check_for_signal()

                    # Update last checked time to prevent re-processing
                    self.last_checked_candle_time = current_time
                    self.logger.info(f"[RECOVERY COMPLETE] Processed missed candle, resuming normal operation")
                    self.logger.info("="*70)

        except Exception as e:
            self.logger.error(f"Error in _check_for_missed_candles: {e}")
            # Don't propagate the error, just log it

    def _get_higher_tf_trend(self, df_30m, df_1h):
        """Get higher timeframe trend from SuperTrend based on configuration"""
        try:
            # Get latest 30m trend
            latest_30m = df_30m.iloc[-1]
            trend_30m = 'BULLISH' if latest_30m['st_direction'] == 1 else 'BEARISH'

            # Get latest 1h trend
            latest_1h = df_1h.iloc[-1]
            trend_1h = 'BULLISH' if latest_1h['st_direction'] == 1 else 'BEARISH'

            # Apply trend confirmation based on mode
            mode = self.config.TREND_CONFIRMATION_MODE

            if mode == '30min':
                # Only 30-min must confirm
                return trend_30m
            elif mode == '1h':
                # Only 1-hour must confirm
                return trend_1h
            elif mode == 'both':
                # Both must agree
                if trend_30m == trend_1h:
                    return trend_30m
                return None  # Disagreement = no trade
            elif mode == 'either':
                # Either one confirms (use 1h as primary, but allow 30m)
                return trend_1h
            else:
                # Default to 1h
                self.logger.warning(f"Unknown TREND_CONFIRMATION_MODE: {mode}, using 1h")
                return trend_1h

        except Exception as e:
            self.logger.error(f"Error getting HTF trend: {e}")
            return None

    def _check_for_signal(self):
        """Check for entry signal - branches based on active strategy"""
        try:
            # Branch based on active strategy
            if self.strategy_name == 'SWING_SUPERTREND':
                self._check_for_swing_signal()
                return

            # Otherwise, use original Marubozu strategy
            self._check_for_marubozu_signal()

        except Exception as e:
            self.logger.error(f"Error checking for signal: {e}")
            self.logger.debug(traceback.format_exc())

    def _check_for_marubozu_signal(self):
        """Check for Marubozu signal on the latest completed candle with trend confirmation"""
        try:
            # Get entry timeframe candles from Delta Exchange API
            # Fetch 100 candles (ADX needs ~50+ for stable values due to double exponential smoothing)
            df_entry = self.delta_client.get_historical_data(
                symbol=self.config.TRADING_SYMBOL,
                resolution=self.config.ENTRY_TIMEFRAME,
                lookback_candles=100
            )

            # Sort entry timeframe candles by timestamp (ascending order)
            if df_entry is not None:
                df_entry = df_entry.sort_values('timestamp').reset_index(drop=True)

            # Get higher timeframe candles from Delta Exchange API (for SuperTrend indicators)
            # Use cached candles and only fetch when new candles have closed
            current_time = datetime.now()

            # Fetch 30m candles only when needed (at X:00 and X:30)
            if self._should_fetch_higher_tf_candles(current_time, '30m'):
                self.logger.info("[FETCHING] New 30m candle closed, fetching from API...")
                self.df_30m_global = self.delta_client.get_historical_data(
                    symbol=self.config.TRADING_SYMBOL,
                    resolution=self.config.TREND_TIMEFRAME_1,  # '30min'
                    lookback_candles=50
                )
                if self.df_30m_global is not None:
                    # Sort and reset index
                    self.df_30m_global = self.df_30m_global.sort_values('timestamp').reset_index(drop=True)
                    latest_30m_candle = self.df_30m_global.iloc[-1]
                    # Convert UTC to IST (UTC + 5:30)
                    latest_time_utc = latest_30m_candle['timestamp']
                    latest_time_ist = latest_time_utc + timedelta(hours=5, minutes=30)
                    self.logger.info(f"  [30M] Latest candle fetched: {latest_time_ist.strftime('%Y-%m-%d %H:%M:%S')} IST")
                    self.last_30m_fetch_time = current_time
            else:
                if self.df_30m_global is not None:
                    self.logger.info("[USING STORED] 30m candles (no new candle closed yet)")

            # Fetch 1h candles only when needed (at X:30)
            if self._should_fetch_higher_tf_candles(current_time, '1h'):
                self.logger.info("[FETCHING] New 1h candle closed, fetching from API...")
                self.df_1h_global = self.delta_client.get_historical_data(
                    symbol=self.config.TRADING_SYMBOL,
                    resolution=self.config.TREND_TIMEFRAME_2,  # '1h'
                    lookback_candles=50
                )
                if self.df_1h_global is not None:
                    # Sort and reset index
                    self.df_1h_global = self.df_1h_global.sort_values('timestamp').reset_index(drop=True)
                    latest_1h_candle = self.df_1h_global.iloc[-1]
                    # Convert UTC to IST (UTC + 5:30)
                    latest_time_utc = latest_1h_candle['timestamp']
                    latest_time_ist = latest_time_utc + timedelta(hours=5, minutes=30)
                    self.logger.info(f"  [1H] Latest candle fetched: {latest_time_ist.strftime('%Y-%m-%d %H:%M:%S')} IST")
                    self.last_1h_fetch_time = current_time
            else:
                if self.df_1h_global is not None:
                    self.logger.info("[USING STORED] 1h candles (no new candle closed yet)")

            # Need sufficient candles for indicator calculations
            # ADX needs ~50+ candles for stable values (double exponential smoothing)
            # Require at least 60 candles to ensure ADX is valid on latest candle
            min_required_candles = 60
            if df_entry is None or len(df_entry) < min_required_candles:
                self.logger.warning(f"Not enough candle data yet ({len(df_entry) if df_entry is not None else 0}/{min_required_candles} candles)")
                # Clear any old pending signal
                if self.pending_signal:
                    self.logger.info("[SIGNAL INVALIDATED] Not enough candle data")
                    self.pending_signal = None
                return

            # Calculate indicators
            # Entry timeframe ADX (if enabled)
            if hasattr(self.config, 'USE_ADX_FILTER') and self.config.USE_ADX_FILTER:
                df_entry['adx'] = calculate_adx(df_entry, period=self.config.ADX_PERIOD)

            # Entry timeframe Volume Filter (if enabled)
            if hasattr(self.config, 'USE_VOLUME_FILTER') and self.config.USE_VOLUME_FILTER:
                df_entry = calculate_volume_filter(
                    df_entry,
                    threshold=self.config.VOLUME_THRESHOLD,
                    ma_period=self.config.VOLUME_MA_PERIOD
                )

            # Initialize trend text variables
            trend_30m_text = 'Unknown'
            trend_1h_text = 'Unknown'

            # 30-minute SuperTrend
            if self.df_30m_global is not None and len(self.df_30m_global) >= self.config.SUPERTREND_30M_PERIOD + 5:
                try:
                    # Calculate SuperTrend
                    st_30m, dir_30m = calculate_supertrend(
                        self.df_30m_global,
                        period=self.config.SUPERTREND_30M_PERIOD,
                        multiplier=self.config.SUPERTREND_30M_MULTIPLIER
                    )

                    # Assign columns
                    self.df_30m_global['supertrend'] = st_30m
                    self.df_30m_global['st_direction'] = dir_30m

                    # Log 30m SuperTrend with timestamp
                    latest_30m = self.df_30m_global.iloc[-1]
                    candle_time_30m = latest_30m['timestamp'].strftime('%H:%M:%S') if 'timestamp' in latest_30m else 'Unknown'
                    trend_30m_text = 'BULLISH' if latest_30m['st_direction'] == 1 else 'BEARISH'
                    self.logger.info(f"  [30M SuperTrend] ${latest_30m['supertrend']:,.2f} | Direction: {trend_30m_text} | Candle: {candle_time_30m} | (Period: {self.config.SUPERTREND_30M_PERIOD}, Multiplier: {self.config.SUPERTREND_30M_MULTIPLIER})")
                except Exception as e:
                    self.logger.error(f"[ERROR-30M] Exception during 30m SuperTrend: {e}")
                    self.logger.error(f"[ERROR-30M] df_30m_global state: shape={self.df_30m_global.shape if self.df_30m_global is not None else 'None'}, _is_copy={self.df_30m_global._is_copy if self.df_30m_global is not None else 'None'}")
                    import traceback
                    self.logger.error(f"[ERROR-30M] Traceback:\n{traceback.format_exc()}")
                    raise

            # 1-hour SuperTrend
            if self.df_1h_global is not None and len(self.df_1h_global) >= self.config.SUPERTREND_1H_PERIOD + 5:
                try:
                    # Calculate SuperTrend
                    st_1h, dir_1h = calculate_supertrend(
                        self.df_1h_global,
                        period=self.config.SUPERTREND_1H_PERIOD,
                        multiplier=self.config.SUPERTREND_1H_MULTIPLIER
                    )

                    # Assign columns
                    self.df_1h_global['supertrend'] = st_1h
                    self.df_1h_global['st_direction'] = dir_1h

                    # Log SuperTrend with timestamp (dynamic timeframe)
                    tf_name = self.config.SUPERTREND_TIMEFRAME.upper()
                    latest_1h = self.df_1h_global.iloc[-1]
                    candle_time_1h = latest_1h['timestamp'].strftime('%H:%M:%S') if 'timestamp' in latest_1h else 'Unknown'
                    trend_1h_text = 'BULLISH' if latest_1h['st_direction'] == 1 else 'BEARISH'
                    self.logger.info(f"  [{tf_name} SuperTrend] ${latest_1h['supertrend']:,.2f} | Direction: {trend_1h_text} | Candle: {candle_time_1h} | (Period: {self.config.SUPERTREND_PERIOD}, Multiplier: {self.config.SUPERTREND_MULTIPLIER})")
                except Exception as e:
                    tf_name = self.config.SUPERTREND_TIMEFRAME.upper()
                    self.logger.error(f"[ERROR-{tf_name}] Exception during {self.config.SUPERTREND_TIMEFRAME} SuperTrend: {e}")
                    self.logger.error(f"[ERROR-{tf_name}] df_1h_global state: shape={self.df_1h_global.shape if self.df_1h_global is not None else 'None'}, _is_copy={self.df_1h_global._is_copy if self.df_1h_global is not None else 'None'}")
                    import traceback
                    self.logger.error(f"[ERROR-{tf_name}] Traceback:\n{traceback.format_exc()}")
                    raise

            # Get latest COMPLETED candle
            latest_candle = df_entry.iloc[-1]

            self.logger.info(f"  Checking candle: O:{latest_candle['open']:.2f} H:{latest_candle['high']:.2f} L:{latest_candle['low']:.2f} C:{latest_candle['close']:.2f}")

            # Check for Marubozu
            body = abs(latest_candle['close'] - latest_candle['open'])
            total_range = latest_candle['high'] - latest_candle['low']

            if total_range <= 0:
                self.logger.info(f"  [X] No signal: Candle has no range")
                # Invalidate old signal - new candle is not valid
                if self.pending_signal:
                    self.logger.info("[SIGNAL INVALIDATED] Latest candle has no range")
                    self.pending_signal = None
                return

            body_pct = (body / total_range) * 100

            if body_pct < self.config.FIRST_CANDLE_MIN_BODY_PERCENTAGE:
                self.logger.info(f"  [X] No signal: Body {body_pct:.1f}% < required {self.config.FIRST_CANDLE_MIN_BODY_PERCENTAGE}%")
                # Invalidate old signal - new candle is not a Marubozu
                if self.pending_signal:
                    self.logger.info("[SIGNAL INVALIDATED] Latest candle is not a Marubozu")
                    self.pending_signal = None
                return

            self.logger.info(f"  [OK] Marubozu detected with {body_pct:.1f}% body")

            # Determine direction
            is_bullish = latest_candle['close'] > latest_candle['open']
            is_bearish = latest_candle['close'] < latest_candle['open']

            if is_bullish:
                direction = 'BULLISH'
                self.logger.info(f"  [OK] GREEN Marubozu - BULLISH signal")
            elif is_bearish:
                direction = 'BEARISH'
                self.logger.info(f"  [OK] RED Marubozu - BEARISH signal")
            else:
                self.logger.info(f"  [X] No signal: Doji candle")
                # Invalidate old signal - new candle is a Doji
                if self.pending_signal:
                    self.logger.info("[SIGNAL INVALIDATED] Latest candle is a Doji")
                    self.pending_signal = None
                return

            # Check higher timeframe trend alignment (if enabled)
            if hasattr(self.config, 'USE_TREND_CONFIRMATION') and self.config.USE_TREND_CONFIRMATION:
                if self.df_30m_global is not None and self.df_1h_global is not None:
                    if 'st_direction' in self.df_30m_global.columns and 'st_direction' in self.df_1h_global.columns:
                        trend_htf = self._get_higher_tf_trend(self.df_30m_global, self.df_1h_global)
                        if trend_htf is None or trend_htf != direction:
                            self.logger.info(f"  [X] No signal: Higher timeframe trend ({trend_htf}) doesn't match entry direction ({direction})")
                            # Invalidate old signal - trend doesn't confirm
                            if self.pending_signal:
                                self.logger.info("[SIGNAL INVALIDATED] Trend confirmation failed")
                                self.pending_signal = None
                            return
                        else:
                            self.logger.info(f"  [OK] Trend confirmation: {trend_htf} on higher timeframe(s)")
                    else:
                        self.logger.warning("  [WARN] SuperTrend not yet calculated, skipping trend confirmation")
                else:
                    self.logger.warning("  [WARN] Not enough higher timeframe data for trend confirmation")
            else:
                self.logger.info(f"  [INFO] Trend confirmation disabled")

            # Check ADX filter if enabled
            if hasattr(self.config, 'USE_ADX_FILTER') and self.config.USE_ADX_FILTER:
                if 'adx' in df_entry.columns:
                    current_adx = latest_candle['adx']

                    # Determine trend strength description
                    if current_adx < 20:
                        strength_desc = "Very Weak/No Trend"
                    elif current_adx < 25:
                        strength_desc = "Weak Trend"
                    elif current_adx < 50:
                        strength_desc = "Strong Trend"
                    elif current_adx < 75:
                        strength_desc = "Very Strong Trend"
                    else:
                        strength_desc = "Extremely Strong Trend"

                    self.logger.info(f"  [{self.config.ENTRY_TIMEFRAME.upper()} ADX] {current_adx:.1f} | {strength_desc} | (Threshold: {self.config.ADX_THRESHOLD}, Period: {self.config.ADX_PERIOD})")

                    if current_adx < self.config.ADX_THRESHOLD:
                        self.logger.info(f"  [X] No signal: ADX {current_adx:.1f} < required {self.config.ADX_THRESHOLD} - Trend too weak for entry")
                        # Invalidate old signal - ADX too weak
                        if self.pending_signal:
                            self.logger.info("[SIGNAL INVALIDATED] ADX filter failed")
                            self.pending_signal = None
                        return
                    else:
                        self.logger.info(f"  [OK] ADX filter passed: {current_adx:.1f} >= {self.config.ADX_THRESHOLD} - Trend strength sufficient")
                else:
                    self.logger.warning("  [WARN] ADX not yet calculated, skipping ADX filter")
            else:
                self.logger.info(f"  [INFO] ADX filter disabled")

            # Check Volume filter if enabled (First Candle)
            first_candle_volume_ratio = None
            if hasattr(self.config, 'USE_VOLUME_FILTER') and self.config.USE_VOLUME_FILTER:
                if 'volume_ratio' in df_entry.columns:
                    first_candle_volume_ratio = latest_candle['volume_ratio']
                    first_candle_volume = latest_candle['volume']
                    first_candle_volume_ma = latest_candle['volume_ma']

                    self.logger.info(f"  [{self.config.ENTRY_TIMEFRAME.upper()} VOLUME] {first_candle_volume:,.0f} | MA: {first_candle_volume_ma:,.0f} | Ratio: {first_candle_volume_ratio:.2f}x | (Threshold: {self.config.VOLUME_THRESHOLD}x)")

                    if first_candle_volume_ratio < self.config.VOLUME_THRESHOLD:
                        self.logger.info(f"  [X] No signal: Volume ratio {first_candle_volume_ratio:.2f}x < required {self.config.VOLUME_THRESHOLD}x - Volume too low for entry")
                        # Invalidate old signal - volume too low
                        if self.pending_signal:
                            self.logger.info("[SIGNAL INVALIDATED] Volume filter failed")
                            self.pending_signal = None
                        return
                    else:
                        self.logger.info(f"  [OK] Volume filter passed: {first_candle_volume_ratio:.2f}x >= {self.config.VOLUME_THRESHOLD}x - Strong volume confirmed")
                else:
                    self.logger.warning("  [WARN] Volume ratio not yet calculated, skipping volume filter")
            else:
                self.logger.info(f"  [INFO] Volume filter disabled")

            # Calculate ATR for this signal
            entry_atr_series = calculate_atr(df_entry, period=14)
            entry_atr = float(entry_atr_series.iloc[-1])  # Get latest ATR value as scalar

            # Get trend directions
            trend_30m = trend_30m_text if self.df_30m_global is not None else 'Unknown'
            trend_1h = trend_1h_text if self.df_1h_global is not None else 'Unknown'

            # Store NEW pending signal (replaces any old signal)
            if self.pending_signal:
                self.logger.info("[SIGNAL REPLACED] Previous signal invalidated by new Marubozu")

            self.pending_signal = {
                'direction': direction,
                'first_candle_high': latest_candle['high'],
                'first_candle_low': latest_candle['low'],
                'first_candle_body_pct': body_pct,
                'first_candle_range': total_range,
                'first_candle_adx': latest_candle['adx'] if 'adx' in df_entry.columns else None,
                'first_candle_volume': latest_candle['volume'],
                'first_candle_volume_ratio': first_candle_volume_ratio,
                'entry_atr': entry_atr,
                'trend_30m': trend_30m,
                'trend_1h': trend_1h
            }

            self.logger.info("="*70)
            self.logger.info(f"[SIGNAL DETECTED] {direction} Marubozu")
            self.logger.info(f"  Breakout Level - BULLISH: >${self.pending_signal['first_candle_high']:,.2f} | BEARISH: <${self.pending_signal['first_candle_low']:,.2f}")
            self.logger.info(f"  Monitoring for {direction} breakout...")
            self.logger.info("="*70)

        except Exception as e:
            self.logger.error(f"Error checking for Marubozu signal: {e}")
            self.logger.debug(traceback.format_exc())

    def _check_for_swing_signal(self):
        """Check for Swing SuperTrend entry signal"""
        try:
            # Fetch enough candles for 288 EMA calculation (need 300+ candles)
            df_entry = self.delta_client.get_historical_data(
                symbol=self.config.TRADING_SYMBOL,
                resolution=self.config.ENTRY_TIMEFRAME,
                lookback_candles=350  # Extra buffer for EMA calculation
            )

            if df_entry is None or len(df_entry) < 300:
                self.logger.warning(f"Not enough candle data yet ({len(df_entry) if df_entry is not None else 0}/300 candles)")
                if self.pending_signal:
                    self.logger.info("[SIGNAL INVALIDATED] Not enough candle data")
                    self.pending_signal = None
                return

            # Sort candles
            df_entry = df_entry.sort_values('timestamp').reset_index(drop=True)

            # Calculate 288 EMA (if enabled)
            if self.config.USE_288_EMA_FILTER:
                self.logger.info("  Calculating 288 EMA (24-hour trend filter)...")
                df_entry['ema_288'] = calculate_288_ema(df_entry)
            else:
                self.logger.info("  [SKIPPED] 288 EMA calculation (disabled in config)")
                df_entry['ema_288'] = None  # Add column but leave empty

            # Calculate ADX (if enabled)
            if self.config.USE_ADX_FILTER:
                self.logger.info(f"  Calculating ADX (period: {self.config.ADX_PERIOD}, threshold: {self.config.ADX_THRESHOLD})...")
                df_entry['adx'] = calculate_adx(df_entry, period=self.config.ADX_PERIOD)
            else:
                self.logger.info("  [SKIPPED] ADX calculation (disabled in config)")
                df_entry['adx'] = None

            # Log latest candle details
            latest_candle = df_entry.iloc[-1]

            # Convert UTC to IST (UTC+5:30)
            utc_time = pd.Timestamp(latest_candle['timestamp'])
            ist_time = utc_time + timedelta(hours=5, minutes=30)

            self.logger.info("="*70)
            self.logger.info(f"[LATEST {self.config.ENTRY_TIMEFRAME.upper()} CANDLE DETAILS]")
            self.logger.info(f"  Time (IST): {ist_time.strftime('%Y-%m-%d %H:%M:%S')} (UTC: {utc_time.strftime('%H:%M')})")
            self.logger.info(f"  Open:  ${latest_candle['open']:,.2f}")
            self.logger.info(f"  High:  ${latest_candle['high']:,.2f}")
            self.logger.info(f"  Low:   ${latest_candle['low']:,.2f}")
            self.logger.info(f"  Close: ${latest_candle['close']:,.2f}")

            # Calculate and show Marubozu details
            body = abs(latest_candle['close'] - latest_candle['open'])
            candle_range = latest_candle['high'] - latest_candle['low']
            body_pct = (body / candle_range * 100) if candle_range > 0 else 0
            candle_direction = 'BULLISH' if latest_candle['close'] > latest_candle['open'] else 'BEARISH'

            self.logger.info(f"  Body: ${body:,.2f} ({body_pct:.1f}% of range)")
            self.logger.info(f"  Range: ${candle_range:,.2f}")
            self.logger.info(f"  Direction: {candle_direction}")

            # Only show EMA if enabled
            if self.config.USE_288_EMA_FILTER and pd.notna(latest_candle['ema_288']):
                self.logger.info(f"  288 EMA: ${latest_candle['ema_288']:,.2f}")
                if latest_candle['close'] > latest_candle['ema_288']:
                    ema_distance = latest_candle['close'] - latest_candle['ema_288']
                    self.logger.info(f"  Price vs EMA: ${ema_distance:,.2f} ABOVE (Bullish)")
                else:
                    ema_distance = latest_candle['ema_288'] - latest_candle['close']
                    self.logger.info(f"  Price vs EMA: ${ema_distance:,.2f} BELOW (Bearish)")
            else:
                self.logger.info(f"  288 EMA: Disabled")

            self.logger.info("="*70)

            # Identify swing points
            self.logger.info(f"  Identifying swing points (lookback: {self.config.SWING_LOOKBACK_CANDLES} candles)...")
            df_entry = identify_swing_points(
                df_entry,
                lookback=self.config.SWING_LOOKBACK_CANDLES,
                confirmation=self.config.SWING_CONFIRMATION_CANDLES
            )

            # Log all identified swing points from last 20 candles
            recent_swings = df_entry.tail(20)
            swing_highs = recent_swings[recent_swings['swing_high'].notna()]
            swing_lows = recent_swings[recent_swings['swing_low'].notna()]

            self.logger.info("="*70)
            self.logger.info("[IDENTIFIED SWING POINTS - Last 20 Candles]")
            if len(swing_highs) > 0:
                self.logger.info(f"  Swing Highs Found: {len(swing_highs)}")
                for idx, row in swing_highs.iterrows():
                    # Convert to IST
                    swing_ist = pd.Timestamp(row['timestamp']) + timedelta(hours=5, minutes=30)
                    self.logger.info(f"    - {swing_ist.strftime('%Y-%m-%d %H:%M')} IST: ${row['swing_high']:,.2f}")
            else:
                self.logger.info("  Swing Highs Found: None")

            if len(swing_lows) > 0:
                self.logger.info(f"  Swing Lows Found: {len(swing_lows)}")
                for idx, row in swing_lows.iterrows():
                    # Convert to IST
                    swing_ist = pd.Timestamp(row['timestamp']) + timedelta(hours=5, minutes=30)
                    self.logger.info(f"    - {swing_ist.strftime('%Y-%m-%d %H:%M')} IST: ${row['swing_low']:,.2f}")
            else:
                self.logger.info("  Swing Lows Found: None")
            self.logger.info("="*70)

            # Fetch higher timeframe data for SuperTrend (if enabled)
            tf_name = self.config.SUPERTREND_TIMEFRAME.upper()
            if self.config.USE_SUPERTREND_FILTER:
                current_time = datetime.now()
                if self._should_fetch_higher_tf_candles(current_time, self.config.SUPERTREND_TIMEFRAME):
                    self.logger.info(f"[FETCHING] New {tf_name} candle closed, fetching from API...")
                    self.df_1h_global = self.delta_client.get_historical_data(
                        symbol=self.config.TRADING_SYMBOL,
                        resolution=self.config.SUPERTREND_TIMEFRAME,
                        lookback_candles=50
                    )
                    if self.df_1h_global is not None:
                        self.df_1h_global = self.df_1h_global.sort_values('timestamp').reset_index(drop=True)
                        self.last_1h_fetch_time = current_time
                else:
                    if self.df_1h_global is not None:
                        self.logger.info(f"[USING STORED] {tf_name} candles (no new candle closed yet)")

                # Calculate SuperTrend on configured timeframe
                if self.df_1h_global is not None and len(self.df_1h_global) >= self.config.SUPERTREND_PERIOD + 5:
                    st_1h, dir_1h = calculate_supertrend(
                        self.df_1h_global,
                        period=self.config.SUPERTREND_PERIOD,
                        multiplier=self.config.SUPERTREND_MULTIPLIER
                    )
                    self.df_1h_global['supertrend'] = st_1h
                    self.df_1h_global['st_direction'] = dir_1h

                    latest_1h = self.df_1h_global.iloc[-1]
                    trend_1h_text = 'BULLISH (+1)' if latest_1h['st_direction'] == 1 else 'BEARISH (-1)'

                    self.logger.info("="*70)
                    self.logger.info(f"[{tf_name} SUPERTREND FILTER]")
                    # Convert to IST
                    h1_ist = pd.Timestamp(latest_1h['timestamp']) + timedelta(hours=5, minutes=30)
                    self.logger.info(f"  Time (IST): {h1_ist.strftime('%Y-%m-%d %H:%M:%S')}")
                    self.logger.info(f"  Close: ${latest_1h['close']:,.2f}")
                    self.logger.info(f"  SuperTrend Level: ${latest_1h['supertrend']:,.2f}")
                    self.logger.info(f"  Direction: {trend_1h_text}")

                    if latest_1h['st_direction'] == 1:
                        self.logger.info(f"  Status: Price ${latest_1h['close']:,.2f} > ST ${latest_1h['supertrend']:,.2f} (BULLISH)")
                    else:
                        self.logger.info(f"  Status: Price ${latest_1h['close']:,.2f} < ST ${latest_1h['supertrend']:,.2f} (BEARISH)")
                    self.logger.info("="*70)
                else:
                    self.logger.warning(f"  [WARN] Not enough {tf_name} data for SuperTrend")
                    if self.pending_signal:
                        self.logger.info(f"[SIGNAL INVALIDATED] No {tf_name} SuperTrend data")
                        self.pending_signal = None
                    return
            else:
                self.logger.info("="*70)
                self.logger.info(f"[{tf_name} SUPERTREND FILTER: DISABLED]")
                self.logger.info("="*70)
                # Create empty dataframe to pass to strategy (pd already imported at top)
                if self.df_1h_global is None:
                    self.df_1h_global = pd.DataFrame(columns=['timestamp', 'open', 'high', 'low', 'close', 'st_direction', 'supertrend'])
                    # Add one dummy row so strategy doesn't error out
                    self.df_1h_global.loc[0] = [datetime.now(), 0, 0, 0, 0, 0, 0]

            # Check 10-minute cooldown period after last exit
            if self.last_exit_time is not None:
                time_since_exit = (datetime.now() - self.last_exit_time).total_seconds()
                cooldown_seconds = 600  # 10 minutes

                if time_since_exit < cooldown_seconds:
                    remaining = cooldown_seconds - time_since_exit
                    minutes_remaining = int(remaining / 60)
                    seconds_remaining = int(remaining % 60)

                    self.logger.info("="*70)
                    self.logger.info(f"[COOLDOWN ACTIVE] No new entries for {minutes_remaining}m {seconds_remaining}s")
                    self.logger.info(f"  Last Exit: {self.last_exit_time.strftime('%H:%M:%S')}")
                    self.logger.info(f"  Cooldown Ends: {(self.last_exit_time + timedelta(seconds=cooldown_seconds)).strftime('%H:%M:%S')}")
                    self.logger.info("="*70)

                    # Clear conditions during cooldown
                    self.long_conditions_met = False
                    self.short_conditions_met = False
                    self.swing_high_level = None
                    self.swing_low_level = None
                    return  # Skip signal detection during cooldown
                else:
                    # Cooldown expired
                    self.logger.info("="*70)
                    self.logger.info("[COOLDOWN EXPIRED] Resuming normal entry signal detection")
                    self.logger.info(f"  Cooldown Duration: 10 minutes")
                    self.logger.info(f"  Last Exit: {self.last_exit_time.strftime('%H:%M:%S')}")
                    self.logger.info("="*70)
                    self.last_exit_time = None  # Clear cooldown

            # Store swing levels and pre-flight conditions for real-time breakout monitoring
            self.logger.info("="*70)
            self.logger.info("[STORING PRE-FLIGHT CONDITIONS FOR REAL-TIME BREAKOUT MONITORING]")
            self.logger.info("="*70)

            # Get most recent swing points from identified swings
            from swing_supertrend_strategy import get_most_recent_swing
            latest_index = len(df_entry) - 1
            swing_high, swing_high_idx = get_most_recent_swing(df_entry, 'high', before_index=latest_index)
            swing_low, swing_low_idx = get_most_recent_swing(df_entry, 'low', before_index=latest_index)

            # Store swing levels
            self.swing_high_level = swing_high
            self.swing_low_level = swing_low

            # Get latest candle values for condition checking
            latest_candle = df_entry.iloc[-1]
            latest_close = latest_candle['close']

            # Store 288 EMA value
            if self.config.USE_288_EMA_FILTER and 'ema_288' in df_entry.columns:
                self.ema_288_value = latest_candle['ema_288']
            else:
                self.ema_288_value = None

            # Store SuperTrend direction (from configured timeframe)
            if self.config.USE_1H_SUPERTREND_FILTER and self.df_1h_global is not None and len(self.df_1h_global) > 0:
                if 'st_direction' in self.df_1h_global.columns:
                    latest_1h = self.df_1h_global.iloc[-1]
                    self.supertrend_1h_direction = latest_1h['st_direction']
                else:
                    self.supertrend_1h_direction = None
            else:
                self.supertrend_1h_direction = None

            # Store ADX value (if filter enabled)
            if self.config.USE_ADX_FILTER and 'adx' in df_entry.columns:
                self.adx_value = latest_candle['adx']
            else:
                self.adx_value = None

            # Check which direction conditions are met
            self.long_conditions_met = False
            self.short_conditions_met = False

            # LONG conditions check
            long_ema_ok = True
            long_st_ok = True
            long_adx_ok = True
            long_swing_ok = swing_high is not None

            if self.config.USE_288_EMA_FILTER:
                if self.ema_288_value is not None and pd.notna(self.ema_288_value):
                    long_ema_ok = latest_close > self.ema_288_value
                else:
                    long_ema_ok = False

            if self.config.USE_1H_SUPERTREND_FILTER:
                if self.supertrend_1h_direction is not None and pd.notna(self.supertrend_1h_direction):
                    long_st_ok = self.supertrend_1h_direction == 1
                else:
                    long_st_ok = False

            if self.config.USE_ADX_FILTER:
                if self.adx_value is not None and pd.notna(self.adx_value):
                    long_adx_ok = self.adx_value >= self.config.ADX_THRESHOLD
                else:
                    long_adx_ok = False

            self.long_conditions_met = long_ema_ok and long_st_ok and long_adx_ok and long_swing_ok

            # SHORT conditions check
            short_ema_ok = True
            short_st_ok = True
            short_adx_ok = True
            short_swing_ok = swing_low is not None

            if self.config.USE_288_EMA_FILTER:
                if self.ema_288_value is not None and pd.notna(self.ema_288_value):
                    short_ema_ok = latest_close < self.ema_288_value
                else:
                    short_ema_ok = False

            if self.config.USE_1H_SUPERTREND_FILTER:
                if self.supertrend_1h_direction is not None and pd.notna(self.supertrend_1h_direction):
                    short_st_ok = self.supertrend_1h_direction == -1
                else:
                    short_st_ok = False

            if self.config.USE_ADX_FILTER:
                if self.adx_value is not None and pd.notna(self.adx_value):
                    short_adx_ok = self.adx_value >= self.config.ADX_THRESHOLD
                else:
                    short_adx_ok = False

            self.short_conditions_met = short_ema_ok and short_st_ok and short_adx_ok and short_swing_ok

            # Log stored conditions (dynamic timeframe names)
            tf_name = self.config.SUPERTREND_TIMEFRAME.upper()
            self.logger.info(f"Swing High: ${swing_high:,.2f}" if swing_high else "Swing High: None")
            self.logger.info(f"Swing Low: ${swing_low:,.2f}" if swing_low else "Swing Low: None")
            self.logger.info(f"288 EMA: ${self.ema_288_value:,.2f}" if self.ema_288_value and pd.notna(self.ema_288_value) else "288 EMA: Disabled/Not Ready")
            self.logger.info(f"{tf_name} SuperTrend: {'BULLISH (+1)' if self.supertrend_1h_direction == 1 else 'BEARISH (-1)' if self.supertrend_1h_direction == -1 else 'Not Ready'}")
            self.logger.info(f"ADX: {self.adx_value:.1f} (Threshold: {self.config.ADX_THRESHOLD})" if self.adx_value and pd.notna(self.adx_value) else "ADX: Disabled/Not Ready")
            self.logger.info(f"Latest Close: ${latest_close:,.2f}")
            self.logger.info("")
            self.logger.info(f"LONG Entry Armed: {'YES' if self.long_conditions_met else 'NO'}")
            if self.long_conditions_met:
                breakout_price = swing_high + 0.02 if swing_high else 0
                self.logger.info(f"  → Waiting for price to break ${breakout_price:,.2f} (Swing High ${swing_high:,.2f} + 2 pips)")
                self.logger.info(f"  → 288 EMA: ${self.ema_288_value:,.2f}" if self.ema_288_value and pd.notna(self.ema_288_value) else "  → 288 EMA: Disabled")
                self.logger.info(f"  → {tf_name} SuperTrend: BULLISH (+1)")
                self.logger.info(f"  → ADX: {self.adx_value:.1f} >= {self.config.ADX_THRESHOLD} (Strong Trend)" if self.adx_value and pd.notna(self.adx_value) else "  → ADX: Disabled")
            else:
                if not long_ema_ok:
                    self.logger.info(f"  → Blocked: Close ${latest_close:,.2f} NOT > 288 EMA ${self.ema_288_value:,.2f}" if self.ema_288_value and pd.notna(self.ema_288_value) else "  → Blocked: 288 EMA not ready")
                if not long_st_ok:
                    self.logger.info(f"  → Blocked: {tf_name} SuperTrend NOT BULLISH")
                if not long_adx_ok:
                    self.logger.info(f"  → Blocked: ADX {self.adx_value:.1f} < {self.config.ADX_THRESHOLD} (Weak Trend)" if self.adx_value and pd.notna(self.adx_value) else "  → Blocked: ADX not ready")
                if not long_swing_ok:
                    self.logger.info(f"  → Blocked: No swing high identified")

            self.logger.info("")
            self.logger.info(f"SHORT Entry Armed: {'YES' if self.short_conditions_met else 'NO'}")
            if self.short_conditions_met:
                breakout_price = swing_low - 0.02 if swing_low else 0
                self.logger.info(f"  → Waiting for price to break ${breakout_price:,.2f} (Swing Low ${swing_low:,.2f} - 2 pips)")
                self.logger.info(f"  → 288 EMA: ${self.ema_288_value:,.2f}" if self.ema_288_value and pd.notna(self.ema_288_value) else "  → 288 EMA: Disabled")
                self.logger.info(f"  → {tf_name} SuperTrend: BEARISH (-1)")
                self.logger.info(f"  → ADX: {self.adx_value:.1f} >= {self.config.ADX_THRESHOLD} (Strong Trend)" if self.adx_value and pd.notna(self.adx_value) else "  → ADX: Disabled")
            else:
                if not short_ema_ok:
                    self.logger.info(f"  → Blocked: Close ${latest_close:,.2f} NOT < 288 EMA ${self.ema_288_value:,.2f}" if self.ema_288_value and pd.notna(self.ema_288_value) else "  → Blocked: 288 EMA not ready")
                if not short_st_ok:
                    self.logger.info(f"  → Blocked: {tf_name} SuperTrend NOT BEARISH")
                if not short_adx_ok:
                    self.logger.info(f"  → Blocked: ADX {self.adx_value:.1f} < {self.config.ADX_THRESHOLD} (Weak Trend)" if self.adx_value and pd.notna(self.adx_value) else "  → Blocked: ADX not ready")
                if not short_swing_ok:
                    self.logger.info(f"  → Blocked: No swing low identified")

            self.logger.info("="*70)
            self.logger.info("[REAL-TIME MONITORING ACTIVE - Will enter on breakout + 2 pips]")
            self.logger.info("="*70)

            # Mark when swing calculation was done
            self.last_swing_calculation_time = datetime.now()

        except Exception as e:
            self.logger.error(f"Error checking for swing signal: {e}")
            self.logger.debug(traceback.format_exc())

    def _check_realtime_breakout(self, current_price):
        """
        Check if current real-time price breaks swing levels (monitored every 15 seconds)
        Entry trigger: Price breaks swing high/low + 2 pips (0.02)
        """
        try:
            # Skip if no position allowed or already in position
            if self.current_position:
                return

            # Skip if conditions not ready
            if not self.long_conditions_met and not self.short_conditions_met:
                return

            # Check cooldown before allowing entry
            if self.last_exit_time is not None:
                time_since_exit = (datetime.now() - self.last_exit_time).total_seconds()
                if time_since_exit < 600:  # 10 minutes cooldown
                    # Still in cooldown, skip breakout checks
                    return

            # Check LONG breakout
            if self.long_conditions_met and self.swing_high_level is not None:
                breakout_price = self.swing_high_level + 0.02  # Swing high + 2 pips
                if current_price >= breakout_price:
                    self.logger.info("="*70)
                    self.logger.info(f"[!!! LONG BREAKOUT DETECTED !!!]")
                    self.logger.info(f"  Current Price: ${current_price:,.2f}")
                    self.logger.info(f"  Breakout Level: ${breakout_price:,.2f} (Swing High ${self.swing_high_level:,.2f} + 2 pips)")
                    self.logger.info("="*70)

                    # Create signal for entry
                    signal = {
                        'direction': 'LONG',
                        'entry_price': current_price,
                        'signal_time': datetime.now(),
                        'entry_swing_high': self.swing_high_level,
                        'entry_swing_low': self.swing_low_level,
                        'swing_break_price': self.swing_high_level,
                        'ema_288': self.ema_288_value,
                        'supertrend_1h': self.supertrend_1h_direction,
                        'marubozu_body_pct': 0  # Not used anymore
                    }

                    # Invalidate conditions so we don't re-enter on same swing
                    self.long_conditions_met = False
                    self.short_conditions_met = False
                    self.swing_high_level = None
                    self.swing_low_level = None

                    # Enter trade immediately
                    self._enter_swing_trade(signal)
                    return

            # Check SHORT breakout
            if self.short_conditions_met and self.swing_low_level is not None:
                breakout_price = self.swing_low_level - 0.02  # Swing low - 2 pips
                if current_price <= breakout_price:
                    self.logger.info("="*70)
                    self.logger.info(f"[!!! SHORT BREAKOUT DETECTED !!!]")
                    self.logger.info(f"  Current Price: ${current_price:,.2f}")
                    self.logger.info(f"  Breakout Level: ${breakout_price:,.2f} (Swing Low ${self.swing_low_level:,.2f} - 2 pips)")
                    self.logger.info("="*70)

                    # Create signal for entry
                    signal = {
                        'direction': 'SHORT',
                        'entry_price': current_price,
                        'signal_time': datetime.now(),
                        'entry_swing_high': self.swing_high_level,
                        'entry_swing_low': self.swing_low_level,
                        'swing_break_price': self.swing_low_level,
                        'ema_288': self.ema_288_value,
                        'supertrend_1h': self.supertrend_1h_direction,
                        'marubozu_body_pct': 0  # Not used anymore
                    }

                    # Invalidate conditions so we don't re-enter on same swing
                    self.long_conditions_met = False
                    self.short_conditions_met = False
                    self.swing_high_level = None
                    self.swing_low_level = None

                    # Enter trade immediately
                    self._enter_swing_trade(signal)
                    return

        except Exception as e:
            self.logger.error(f"Error checking real-time breakout: {e}")
            self.logger.debug(traceback.format_exc())

    def _enter_swing_trade(self, signal):
        """Enter swing trade immediately (no breakout monitoring)"""
        try:
            direction = signal['direction']
            entry_price = signal['entry_price']

            # Calculate initial stop loss from swing point
            stop_loss = calculate_initial_stop_loss(
                entry_price=entry_price,
                direction=direction,
                swing_high=signal['entry_swing_high'],
                swing_low=signal['entry_swing_low'],
                config=self.config
            )

            # NO take profit for swing strategy (set to None)
            take_profit = None

            self.logger.info(f"[ENTRY] {direction} Swing Trade at ${entry_price:,.2f}")
            self.logger.info(f"  Position Size: ${self.config.POSITION_SIZE_DOLLARS:,.0f} | Leverage: {self.config.LEVERAGE}x")
            self.logger.info(f"  Initial Stop Loss: ${stop_loss:,.2f} (from swing point + {self.config.STOP_LOSS_BUFFER_PCT}% buffer)")
            self.logger.info(f"  Take Profit: None (swing trailing only)")
            self.logger.info("="*70)

            # Place entry order via API
            try:
                order_result = self.order_manager.place_entry_order(
                    symbol=self.config.TRADING_SYMBOL,
                    side='buy' if direction == 'LONG' else 'sell',
                    size_usd=self.config.POSITION_SIZE_DOLLARS,
                    current_price=entry_price
                )

                actual_entry_price = order_result['fill_price']
                actual_base_quantity = order_result['filled_size']

                # CRITICAL: For options, actual_entry_price is the OPTION PRICE, not futures price
                # We need futures price for stop loss calculations, option price for P&L
                futures_entry_price = entry_price  # This is the signal's entry_price (futures spot)
                option_fill_price = actual_entry_price  # This is the option premium

                # Display order execution details - different for options vs futures
                if getattr(self.config, 'OPTION_SELLING', False):
                    # OPTIONS: Show option symbol and strike
                    option_symbol = order_result.get('symbol', 'Unknown')
                    option_position = self.order_manager.get_position(self.config.TRADING_SYMBOL)
                    if option_position:
                        option_type = 'PUT' if option_position.get('type') == 'put' else 'CALL'
                        strike = option_position.get('strike', 0)
                        lots_sold = order_result.get('lots', 0)

                        # Calculate actual premium received
                        # Delta API returns option price per X lots (BTC=1000, ETH=100)
                        # Get the correct divisor from order manager (which is DeltaOptionsManager)
                        option_divisor = self.order_manager.OPTION_PRICE_DIVISOR.get(self.config.TRADING_SYMBOL, 1000)
                        option_price_quoted = order_result.get('fill_price', 0)
                        option_premium_received = (option_price_quoted / option_divisor) * lots_sold

                        self.logger.info("="*70)
                        self.logger.info(f"[OPTION SOLD] {option_symbol}")
                        self.logger.info(f"  Type: {option_type} (Sold to {'OPEN LONG' if option_type == 'PUT' else 'OPEN SHORT'})")
                        self.logger.info(f"  Strike: ${strike:,}")
                        self.logger.info(f"  Option Price: ${option_price_quoted:,.2f} (per {option_divisor} lots)")
                        self.logger.info(f"  Premium Received: ${option_premium_received:,.2f} ({lots_sold} lots)")
                        self.logger.info(f"  Spot Price: ${actual_entry_price:,.2f}")
                        self.logger.info(f"  Lots: {lots_sold}")
                        self.logger.info(f"  Order ID: {order_result['order_id']}")
                        self.logger.info("="*70)
                    else:
                        self.logger.info(f"[ORDER EXECUTED] ID: {order_result['order_id']}, Lots: {order_result['lots']}")
                else:
                    # FUTURES: Show normal execution
                    self.logger.info(f"[ORDER EXECUTED] ID: {order_result['order_id']}, Lots: {order_result['lots']}")

            except Exception as e:
                self.logger.error(f"[ORDER FAILED] Entry order failed: {e}")
                return

            # Open position with swing data
            # CRITICAL: Always use FUTURES price for entry_price (for stop loss calculations)
            position_data = {
                'trade_id': self.stats['total_trades'] + 1,
                'direction': direction,
                'entry_price': futures_entry_price,  # MUST be futures price for stop loss logic
                'order_id': order_result['order_id'],
                'take_profit': None,  # No fixed TP for swing strategy
                'stop_loss': stop_loss,
                'initial_stop_loss': stop_loss,
                'entry_time': datetime.now(),
                'position_size': self.config.POSITION_SIZE_DOLLARS,
                'position_size_usd': self.config.POSITION_SIZE_DOLLARS,
                'position_size_base': actual_base_quantity,
                'remaining_size': self.config.POSITION_SIZE_DOLLARS,
                'leverage': self.config.LEVERAGE,
                'entry_swing_high': signal['entry_swing_high'],
                'entry_swing_low': signal['entry_swing_low'],
                'marubozu_body_pct': signal['marubozu_body_pct'],
                'ema_288': signal['ema_288'],
                'supertrend_1h': signal['supertrend_1h'],
                'highest_profit_pips': 0,
                'lowest_profit_pips': 0,
                'highest_price': futures_entry_price,  # Track futures price movement
                'lowest_price': futures_entry_price
            }

            # Add option-specific data if option selling mode
            if getattr(self.config, 'OPTION_SELLING', False):
                option_position = self.order_manager.get_position(self.config.TRADING_SYMBOL)
                if option_position:
                    position_data['option_symbol'] = option_position.get('symbol', 'N/A')
                    position_data['option_type'] = option_position.get('type', 'N/A')
                    position_data['strike_price'] = option_position.get('strike', 0)
                    position_data['option_entry_price'] = option_fill_price  # Store option premium separately
                    position_data['lots'] = order_result.get('lots', 0)

            self.current_position = position_data

            self.pending_signal = None
            self.stats['total_trades'] += 1

        except Exception as e:
            self.logger.error(f"Error entering swing trade: {e}")
            self.logger.debug(traceback.format_exc())

    def _monitor_breakout_entry(self, current_price):
        """Monitor for breakout entry (Marubozu strategy only)"""
        try:
            # Skip breakout monitoring for swing strategy (immediate entry)
            if self.strategy_name == 'SWING_SUPERTREND':
                return

            signal = self.pending_signal
            direction = signal['direction']

            # Log current monitoring status
            if direction == 'BULLISH':
                distance = current_price - signal['first_candle_high']
                breakout_level = signal['first_candle_high']
                condition = f"Price > ${breakout_level:,.2f}"
                self.logger.info(f"[Entry Monitor] Current: ${current_price:,.2f} | Entry Condition: {condition} | Distance: ${distance:,.2f}")
            else:  # BEARISH
                distance = signal['first_candle_low'] - current_price
                breakout_level = signal['first_candle_low']
                condition = f"Price < ${breakout_level:,.2f}"
                self.logger.info(f"[Entry Monitor] Current: ${current_price:,.2f} | Entry Condition: {condition} | Distance: ${distance:,.2f}")

            # SECOND CANDLE VALIDATION: Fetch current candle to validate momentum continuation
            # This validates conditions 6-8 from the strategy document
            try:
                df_current = self.delta_client.get_historical_data(
                    symbol=self.config.TRADING_SYMBOL,
                    resolution=self.config.ENTRY_TIMEFRAME,
                    lookback_candles=40  # Need enough for ADX calculation
                )

                if df_current is not None and len(df_current) >= 2:
                    df_current = df_current.sort_values('timestamp').reset_index(drop=True)

                    # Calculate indicators for second candle validation
                    if self.config.USE_ADX_FILTER:
                        df_current['adx'] = calculate_adx(df_current, period=self.config.ADX_PERIOD)

                    if self.config.USE_VOLUME_FILTER:
                        df_current = calculate_volume_filter(
                            df_current,
                            threshold=self.config.VOLUME_THRESHOLD,
                            ma_period=self.config.VOLUME_MA_PERIOD
                        )

                    second_candle = df_current.iloc[-1]  # Latest (second) candle

                    # CHECK 6: Second candle direction must match first candle
                    second_candle_is_bullish = second_candle['close'] > second_candle['open']
                    second_candle_is_bearish = second_candle['close'] < second_candle['open']

                    if direction == 'BULLISH' and not second_candle_is_bullish:
                        self.logger.info("  [X] 2nd candle validation failed: Direction changed (not bullish)")
                        self.logger.info("[SIGNAL INVALIDATED] Second candle direction doesn't match")
                        self.pending_signal = None
                        return
                    elif direction == 'BEARISH' and not second_candle_is_bearish:
                        self.logger.info("  [X] 2nd candle validation failed: Direction changed (not bearish)")
                        self.logger.info("[SIGNAL INVALIDATED] Second candle direction doesn't match")
                        self.pending_signal = None
                        return

                    # CHECK 7: ADX Momentum - ADX must be building (if enabled)
                    if self.config.CHECK_ADX_MOMENTUM and signal['first_candle_adx'] is not None:
                        if 'adx' in df_current.columns:
                            second_candle_adx = second_candle['adx']
                            first_candle_adx = signal['first_candle_adx']
                            required_adx = first_candle_adx * (1 + self.config.ADX_MOMENTUM_INCREASE_PCT / 100)

                            if second_candle_adx < required_adx:
                                self.logger.info(f"  [X] 2nd candle validation failed: ADX momentum not building")
                                self.logger.info(f"      ADX: {second_candle_adx:.1f} < Required: {required_adx:.1f} (need {self.config.ADX_MOMENTUM_INCREASE_PCT}% increase)")
                                self.logger.info("[SIGNAL INVALIDATED] ADX momentum check failed")
                                self.pending_signal = None
                                return
                            else:
                                self.logger.info(f"  [✓] 2nd candle ADX momentum: {second_candle_adx:.1f} >= {required_adx:.1f} (building)")

                    # CHECK 8: Volume Sustained - 2nd candle volume >= 1st candle volume (if enabled)
                    if self.config.VOLUME_INCREASING_REQUIRED:
                        second_candle_volume = second_candle['volume']
                        first_candle_volume = signal['first_candle_volume']

                        if second_candle_volume < first_candle_volume:
                            self.logger.info(f"  [X] 2nd candle validation failed: Volume not sustained")
                            self.logger.info(f"      Volume: {second_candle_volume:,.0f} < First Candle: {first_candle_volume:,.0f}")
                            self.logger.info("[SIGNAL INVALIDATED] Volume sustained check failed")
                            self.pending_signal = None
                            return
                        else:
                            self.logger.info(f"  [✓] 2nd candle volume sustained: {second_candle_volume:,.0f} >= {first_candle_volume:,.0f}")

            except Exception as e:
                self.logger.warning(f"Could not validate second candle: {e}. Proceeding with breakout check...")

            # Check for breakout
            breakout = False

            if direction == 'BULLISH':
                if current_price > signal['first_candle_high']:
                    breakout = True
                    self.logger.info("="*70)
                    self.logger.info(f"🚀 [BULLISH MARUBOZU BREAKOUT CONFIRMED!] 🚀")
                    self.logger.info("="*70)
                    self.logger.info(f"  Breakout: Price ${current_price:,.2f} > High ${signal['first_candle_high']:,.2f}")
                    self.logger.info(f"")
                    self.logger.info(f"  ✓ ALL ENTRY CONDITIONS MET:")
                    self.logger.info(f"  [1] Marubozu Pattern: {signal['first_candle_body_pct']:.1f}% body (>= {self.config.FIRST_CANDLE_MIN_BODY_PERCENTAGE}%)")
                    if signal.get('first_candle_volume_ratio'):
                        self.logger.info(f"  [2] Volume Spike: {signal['first_candle_volume_ratio']:.2f}x average (>= {self.config.VOLUME_THRESHOLD}x)")
                    if signal.get('first_candle_adx'):
                        self.logger.info(f"  [3] ADX Strength: {signal['first_candle_adx']:.1f} (>= {self.config.ADX_THRESHOLD})")
                    self.logger.info(f"  [4] 30m SuperTrend: {signal['trend_30m']}")
                    tf_display = self.config.SUPERTREND_TIMEFRAME.upper() if hasattr(self.config, 'SUPERTREND_TIMEFRAME') else '1H'
                    self.logger.info(f"  [5] {tf_display} SuperTrend: {signal['trend_1h']}")
                    self.logger.info(f"  [6] 2nd Candle Direction: BULLISH (confirmed)")
                    if self.config.CHECK_ADX_MOMENTUM:
                        self.logger.info(f"  [7] ADX Momentum: Building (+{self.config.ADX_MOMENTUM_INCREASE_PCT}%)")
                    if self.config.VOLUME_INCREASING_REQUIRED:
                        self.logger.info(f"  [8] Volume Sustained: Confirmed")
                    self.logger.info("="*70)
            else:  # BEARISH
                if current_price < signal['first_candle_low']:
                    breakout = True
                    self.logger.info("="*70)
                    self.logger.info(f"🔻 [BEARISH MARUBOZU BREAKOUT CONFIRMED!] 🔻")
                    self.logger.info("="*70)
                    self.logger.info(f"  Breakout: Price ${current_price:,.2f} < Low ${signal['first_candle_low']:,.2f}")
                    self.logger.info(f"")
                    self.logger.info(f"  ✓ ALL ENTRY CONDITIONS MET:")
                    self.logger.info(f"  [1] Marubozu Pattern: {signal['first_candle_body_pct']:.1f}% body (>= {self.config.FIRST_CANDLE_MIN_BODY_PERCENTAGE}%)")
                    if signal.get('first_candle_volume_ratio'):
                        self.logger.info(f"  [2] Volume Spike: {signal['first_candle_volume_ratio']:.2f}x average (>= {self.config.VOLUME_THRESHOLD}x)")
                    if signal.get('first_candle_adx'):
                        self.logger.info(f"  [3] ADX Strength: {signal['first_candle_adx']:.1f} (>= {self.config.ADX_THRESHOLD})")
                    self.logger.info(f"  [4] 30m SuperTrend: {signal['trend_30m']}")
                    tf_display = self.config.SUPERTREND_TIMEFRAME.upper() if hasattr(self.config, 'SUPERTREND_TIMEFRAME') else '1H'
                    self.logger.info(f"  [5] {tf_display} SuperTrend: {signal['trend_1h']}")
                    self.logger.info(f"  [6] 2nd Candle Direction: BEARISH (confirmed)")
                    if self.config.CHECK_ADX_MOMENTUM:
                        self.logger.info(f"  [7] ADX Momentum: Building (+{self.config.ADX_MOMENTUM_INCREASE_PCT}%)")
                    if self.config.VOLUME_INCREASING_REQUIRED:
                        self.logger.info(f"  [8] Volume Sustained: Confirmed")
                    self.logger.info("="*70)

            if breakout:
                # Calculate TP and SL
                pip_value = current_price / 10000
                if direction == 'BULLISH':
                    take_profit = current_price + (self.config.TAKE_PROFIT_PIPS * pip_value)
                    stop_loss = current_price - (self.config.STOP_LOSS_PIPS * pip_value)
                else:
                    take_profit = current_price - (self.config.TAKE_PROFIT_PIPS * pip_value)
                    stop_loss = current_price + (self.config.STOP_LOSS_PIPS * pip_value)

                # Calculate dollar values
                base_quantity = self.config.POSITION_SIZE_DOLLARS / current_price
                base_asset = self.config.TRADING_SYMBOL[:3]  # BTC, ETH, etc.
                tp_profit_dollars = (self.config.TAKE_PROFIT_PIPS / 10000) * self.config.POSITION_SIZE_DOLLARS
                sl_loss_dollars = (self.config.STOP_LOSS_PIPS / 10000) * self.config.POSITION_SIZE_DOLLARS
                tp_move_dollars = abs(take_profit - current_price)
                sl_move_dollars = abs(current_price - stop_loss)

                self.logger.info(f"[ENTRY] {direction} Trade at ${current_price:,.2f}")
                self.logger.info(f"  Position Size: ${self.config.POSITION_SIZE_DOLLARS:,.0f} | Quantity: {base_quantity:.6f} {base_asset} | Leverage: {self.config.LEVERAGE}x")
                self.logger.info(f"  Take Profit: ${take_profit:,.2f} ({self.config.TAKE_PROFIT_PIPS} pips = ${tp_move_dollars:,.2f} move)")
                self.logger.info(f"    → Potential Profit: ${tp_profit_dollars:,.2f}")
                self.logger.info(f"  Stop Loss: ${stop_loss:,.2f} ({self.config.STOP_LOSS_PIPS} pips = ${sl_move_dollars:,.2f} move)")
                self.logger.info(f"    → Risk Amount: ${sl_loss_dollars:,.2f}")
                self.logger.info(f"  Risk/Reward Ratio: 1:{tp_profit_dollars/sl_loss_dollars:.2f}")
                self.logger.info("="*70)

                # Place actual entry order via API
                try:
                    order_result = self.order_manager.place_entry_order(
                        symbol=self.config.TRADING_SYMBOL,
                        side='buy' if direction == 'BULLISH' else 'sell',
                        size_usd=self.config.POSITION_SIZE_DOLLARS,
                        current_price=current_price
                    )

                    # Use actual fill price and size from order
                    actual_entry_price = order_result['fill_price']
                    actual_base_quantity = order_result['filled_size']

                    # Display order execution details - different for options vs futures
                    if getattr(self.config, 'OPTION_SELLING', False):
                        # OPTIONS: Show option symbol and strike
                        option_symbol = order_result.get('symbol', 'Unknown')
                        option_position = self.order_manager.get_position(self.config.TRADING_SYMBOL)
                        if option_position:
                            option_type = 'PUT' if option_position.get('type') == 'put' else 'CALL'
                            strike = option_position.get('strike', 0)
                            lots_sold = order_result.get('lots', 0)

                            # Calculate actual premium received
                            # Delta API returns option price per X lots (BTC=1000, ETH=100)
                            # Get the correct divisor from order manager (which is DeltaOptionsManager)
                            option_divisor = self.order_manager.OPTION_PRICE_DIVISOR.get(self.config.TRADING_SYMBOL, 1000)
                            option_price_quoted = order_result.get('fill_price', 0)
                            option_premium_received = (option_price_quoted / option_divisor) * lots_sold

                            self.logger.info("="*70)
                            self.logger.info(f"[OPTION SOLD] {option_symbol}")
                            self.logger.info(f"  Type: {option_type} (Sold to {'OPEN LONG' if option_type == 'PUT' else 'OPEN SHORT'})")
                            self.logger.info(f"  Strike: ${strike:,}")
                            self.logger.info(f"  Option Price: ${option_price_quoted:,.2f} (per {option_divisor} lots)")
                            self.logger.info(f"  Premium Received: ${option_premium_received:,.2f} ({lots_sold} lots)")
                            self.logger.info(f"  Spot Price: ${actual_entry_price:,.2f}")
                            self.logger.info(f"  Lots: {lots_sold}")
                            self.logger.info(f"  Order ID: {order_result['order_id']}")
                            self.logger.info("="*70)
                        else:
                            self.logger.info(f"[ORDER EXECUTED] ID: {order_result['order_id']}, Lots: {order_result['lots']}")
                    else:
                        # FUTURES: Show normal execution
                        self.logger.info(f"[ORDER EXECUTED] ID: {order_result['order_id']}, Lots: {order_result['lots']}")

                except Exception as e:
                    self.logger.error(f"[ORDER FAILED] Entry order failed: {e}")
                    # Don't create position if order fails
                    return

                # Open position with actual order details
                self.current_position = {
                    'trade_id': self.stats['total_trades'] + 1,  # Assign before incrementing
                    'direction': direction,
                    'entry_price': actual_entry_price,  # Use actual fill price
                    'order_id': order_result['order_id'],  # Store order ID
                    'take_profit': take_profit,
                    'stop_loss': stop_loss,
                    'initial_stop_loss': stop_loss,  # Keep original SL for reference
                    'entry_time': datetime.now(),
                    'position_size': self.config.POSITION_SIZE_DOLLARS,
                    'position_size_usd': self.config.POSITION_SIZE_DOLLARS,
                    'position_size_base': actual_base_quantity,  # Use actual filled size
                    'remaining_size': self.config.POSITION_SIZE_DOLLARS,  # Track remaining after partial profits
                    'leverage': self.config.LEVERAGE,
                    'first_candle_body_pct': signal['first_candle_body_pct'],
                    'first_candle_range': signal['first_candle_range'],
                    'atr': signal['entry_atr'],
                    'trend_30m': signal['trend_30m'],
                    'trend_1h': signal['trend_1h'],
                    'trailing_activated': False,  # Track if trailing has started
                    'highest_profit_pips': 0,  # Track highest profit for trailing
                    'lowest_profit_pips': 0,  # Track lowest profit (for drawdown)
                    'highest_price': actual_entry_price,  # Track highest price seen
                    'lowest_price': actual_entry_price,  # Track lowest price seen
                    'partial_profits_taken': []  # Track which levels have been hit
                }
                self.pending_signal = None
                self.stats['total_trades'] += 1

        except Exception as e:
            self.logger.error(f"Error monitoring breakout: {e}")

    def _monitor_position(self, current_price):
        """Monitor open position - branches based on strategy"""
        try:
            if not self.current_position:
                return

            # Branch based on strategy
            if self.strategy_name == 'SWING_SUPERTREND':
                self._monitor_swing_position(current_price)
                return

            # Otherwise use Marubozu position monitoring
            position = self.current_position
            direction = position['direction']

            # Calculate current profit in pips
            if direction == 'BULLISH':
                profit_pips = ((current_price - position['entry_price']) / position['entry_price']) * 10000
            else:  # BEARISH
                profit_pips = ((position['entry_price'] - current_price) / position['entry_price']) * 10000

            # Update highest/lowest profit and prices seen
            if profit_pips > position['highest_profit_pips']:
                position['highest_profit_pips'] = profit_pips

            if profit_pips < position['lowest_profit_pips']:
                position['lowest_profit_pips'] = profit_pips

            if direction == 'BULLISH':
                if current_price > position['highest_price']:
                    position['highest_price'] = current_price
                if current_price < position['lowest_price']:
                    position['lowest_price'] = current_price
            else:  # BEARISH
                if current_price < position['lowest_price']:
                    position['lowest_price'] = current_price
                if current_price > position['highest_price']:
                    position['highest_price'] = current_price

            # === PARTIAL PROFIT TAKING ===
            if self.config.USE_PARTIAL_PROFITS:
                for level_pips, close_pct in self.config.PARTIAL_PROFIT_LEVELS:
                    if profit_pips >= level_pips and level_pips not in position['partial_profits_taken']:
                        # Calculate partial close amount
                        close_amount = position['position_size'] * (close_pct / 100)
                        close_base_qty = close_amount / current_price

                        # Execute partial exit order via API
                        try:
                            partial_result = self.order_manager.place_partial_exit(
                                symbol=self.config.TRADING_SYMBOL,
                                side='sell' if direction == 'BULLISH' else 'buy',
                                size_base=close_base_qty,
                                current_price=current_price,
                                percentage=close_pct
                            )

                            self.logger.info(f"[PARTIAL ORDER EXECUTED] ID: {partial_result['order_id']}")

                            # Update position after successful order
                            position['remaining_size'] -= close_amount
                            position['partial_profits_taken'].append(level_pips)

                            pnl_dollars = (level_pips / 10000) * close_amount
                            self.stats['total_pnl'] += pnl_dollars

                            self.logger.info("="*70)
                            self.logger.info(f"[PARTIAL PROFIT] Closed {close_pct}% at {level_pips} pips")
                            self.logger.info(f"  Closed: ${close_amount:,.0f} | Remaining: ${position['remaining_size']:,.0f}")
                            self.logger.info(f"  Profit: ${pnl_dollars:,.2f}")
                            self.logger.info("="*70)

                        except Exception as e:
                            self.logger.error(f"[PARTIAL ORDER FAILED] {e}")
                            # Continue monitoring even if partial fails

            # === TRAILING STOP LOGIC ===
            if self.config.USE_TRAILING_STOP and not position['trailing_activated']:
                # Activate trailing after reaching activation threshold
                if profit_pips >= self.config.TRAILING_ACTIVATION_PIPS:
                    position['trailing_activated'] = True
                    profit_dollars_at_activation = (profit_pips / 10000) * position['remaining_size']
                    self.logger.info("="*70)
                    self.logger.info(f"[TRAILING ACTIVATED] Profit: {profit_pips:.1f} pips (${profit_dollars_at_activation:,.2f}) >= {self.config.TRAILING_ACTIVATION_PIPS} pips")
                    self.logger.info(f"  Stop loss will now trail price automatically")
                    self.logger.info(f"  Risk eliminated - Downside now protected!")
                    self.logger.info("="*70)

            # Update trailing stop if activated
            if self.config.USE_TRAILING_STOP and position['trailing_activated']:
                # Calculate ATR from entry timeframe
                atr = self._calculate_atr(timeframe=self.config.ENTRY_TIMEFRAME, period=14)

                if atr is not None:
                    # Calculate new trailing stop
                    trail_distance = atr * self.config.TRAILING_ATR_MULTIPLIER

                    if direction == 'BULLISH':
                        new_stop = current_price - trail_distance
                        # Only move stop up, never down
                        if new_stop > position['stop_loss']:
                            old_stop = position['stop_loss']
                            position['stop_loss'] = new_stop

                            # Calculate profit protected at new stop
                            if direction == 'BULLISH':
                                protected_profit_pips = ((new_stop - position['entry_price']) / position['entry_price']) * 10000
                            else:
                                protected_profit_pips = ((position['entry_price'] - new_stop) / position['entry_price']) * 10000
                            protected_profit_dollars = (protected_profit_pips / 10000) * position['remaining_size']

                            self.logger.info(f"[TRAILING] Stop moved UP: ${old_stop:,.2f} -> ${new_stop:,.2f} (Trail: {trail_distance:,.2f}, ATR: ${atr:,.2f})")
                            self.logger.info(f"  → Profit now protected: {protected_profit_pips:+.1f} pips (${protected_profit_dollars:+,.2f})")
                    else:  # BEARISH
                        new_stop = current_price + trail_distance
                        # Only move stop down, never up
                        if new_stop < position['stop_loss']:
                            old_stop = position['stop_loss']
                            position['stop_loss'] = new_stop

                            # Calculate profit protected at new stop
                            if direction == 'BULLISH':
                                protected_profit_pips = ((new_stop - position['entry_price']) / position['entry_price']) * 10000
                            else:
                                protected_profit_pips = ((position['entry_price'] - new_stop) / position['entry_price']) * 10000
                            protected_profit_dollars = (protected_profit_pips / 10000) * position['remaining_size']

                            self.logger.info(f"[TRAILING] Stop moved DOWN: ${old_stop:,.2f} -> ${new_stop:,.2f} (Trail: {trail_distance:,.2f}, ATR: ${atr:,.2f})")
                            self.logger.info(f"  → Profit now protected: {protected_profit_pips:+.1f} pips (${protected_profit_dollars:+,.2f})")

            # Calculate dollar P&L
            pnl_dollars_current = (profit_pips / 10000) * position['remaining_size']

            # Log position status
            if direction == 'BULLISH':
                tp_condition = f"Price >= ${position['take_profit']:,.2f}"
                sl_condition = f"Price <= ${position['stop_loss']:,.2f}"
                tp_distance = position['take_profit'] - current_price
                sl_distance = current_price - position['stop_loss']
                tp_distance_dollars = (tp_distance / current_price) * position['remaining_size']
                sl_distance_dollars = (sl_distance / current_price) * position['remaining_size']
            else:  # BEARISH
                tp_condition = f"Price <= ${position['take_profit']:,.2f}"
                sl_condition = f"Price >= ${position['stop_loss']:,.2f}"
                tp_distance = current_price - position['take_profit']
                sl_distance = position['stop_loss'] - current_price
                tp_distance_dollars = (tp_distance / current_price) * position['remaining_size']
                sl_distance_dollars = (sl_distance / current_price) * position['remaining_size']

            trailing_status = "ACTIVE" if position['trailing_activated'] else "INACTIVE"
            self.logger.info(f"[Position Monitor] Price: ${current_price:,.2f} | P&L: {profit_pips:.1f} pips (${pnl_dollars_current:+,.2f}) | Remaining: ${position['remaining_size']:,.0f} | Trail: {trailing_status}")
            self.logger.info(f"  TP: {tp_condition} (${tp_distance:,.2f} away = ${tp_distance_dollars:,.2f} profit) | SL: {sl_condition} (${sl_distance:,.2f} away = ${sl_distance_dollars:,.2f} loss)")

            # === CHECK EXIT CONDITIONS ===
            exit_reason = None

            # Check take profit
            if direction == 'BULLISH':
                if current_price >= position['take_profit']:
                    exit_reason = 'Take Profit'
            else:
                if current_price <= position['take_profit']:
                    exit_reason = 'Take Profit'

            # Check stop loss (could be original or trailing)
            if direction == 'BULLISH':
                if current_price <= position['stop_loss']:
                    exit_reason = 'Trailing Stop' if position['trailing_activated'] else 'Stop Loss'
            else:
                if current_price >= position['stop_loss']:
                    exit_reason = 'Trailing Stop' if position['trailing_activated'] else 'Stop Loss'

            if exit_reason:
                # Execute exit order via API
                try:
                    exit_btc = position['remaining_size'] / current_price  # Convert USD to BTC

                    exit_result = self.order_manager.place_exit_order(
                        symbol=self.config.TRADING_SYMBOL,
                        side='sell' if direction == 'BULLISH' else 'buy',
                        size_base=exit_btc,
                        reason=exit_reason
                    )

                    self.logger.info(f"[EXIT ORDER EXECUTED] ID: {exit_result['order_id']}")

                    # Use actual exit price from order
                    actual_exit_price = exit_result['fill_price']

                    # Recalculate P&L with actual exit price
                    if direction == 'BULLISH':
                        final_profit_pips = ((actual_exit_price - position['entry_price']) / position['entry_price']) * 10000
                    else:
                        final_profit_pips = ((position['entry_price'] - actual_exit_price) / position['entry_price']) * 10000

                    pnl_dollars = (final_profit_pips / 10000) * position['remaining_size']

                except Exception as e:
                    self.logger.error(f"[EXIT ORDER FAILED] {e}")
                    # Still log the trade, but mark as failed
                    exit_reason = f"{exit_reason} (Order Failed)"
                    actual_exit_price = current_price
                    pnl_dollars = (profit_pips / 10000) * position['remaining_size']

                # Close remaining position
                self.stats['total_pnl'] += pnl_dollars

                self.logger.info("="*70)
                self.logger.info(f"[EXIT] {exit_reason} hit!")
                self.logger.info(f"  Entry: ${position['entry_price']:,.2f}")
                self.logger.info(f"  Exit: ${actual_exit_price:,.2f}")
                self.logger.info(f"  Final P&L: {final_profit_pips:.1f} pips")
                self.logger.info(f"  Remaining Size: ${position['remaining_size']:,.0f}")
                self.logger.info(f"  Final Profit: ${pnl_dollars:,.2f}")
                self.logger.info(f"  Partials Taken: {len(position['partial_profits_taken'])} times")
                self.logger.info(f"  Total Trade P&L: ${self.stats['total_pnl']:,.2f}")
                self.logger.info("="*70)

                # Update stats
                if pnl_dollars > 0:
                    self.stats['winning_trades'] += 1
                else:
                    self.stats['losing_trades'] += 1

                # Calculate trade metrics for CSV
                exit_time = datetime.now()
                hold_time = (exit_time - position['entry_time']).total_seconds() / 60  # minutes
                commission = 0.0  # TODO: Calculate actual commission
                gross_pnl = pnl_dollars
                net_pnl = gross_pnl - commission
                pnl_pct = (net_pnl / position['position_size_usd']) * 100

                # Prepare trade data for CSV
                trade_data = {
                    'trade_id': position['trade_id'],
                    'entry_time': position['entry_time'],
                    'exit_time': exit_time,
                    'direction': position['direction'],
                    'entry_price': position['entry_price'],
                    'exit_price': actual_exit_price,
                    'take_profit': position['take_profit'],
                    'stop_loss': position['stop_loss'],
                    'trailing_stop_final': position['stop_loss'],  # Current SL value (may have trailed)
                    'position_size_base': position['position_size_base'],
                    'position_size_usd': position['position_size_usd'],
                    'leverage': position['leverage'],
                    'first_candle_body_pct': position['first_candle_body_pct'],
                    'first_candle_range': position['first_candle_range'],
                    'entry_atr': position['atr'],
                    'trend_30m': position['trend_30m'],
                    'trend_1h': position['trend_1h'],
                    'partial_profits_taken': position['partial_profits_taken'],
                    'highest_price': position['highest_price'],
                    'lowest_price': position['lowest_price'],
                    'highest_profit_pips': position['highest_profit_pips'],
                    'lowest_profit_pips': position['lowest_profit_pips'],
                    'exit_reason': exit_reason,
                    'hold_time_minutes': hold_time,
                    'gross_pnl': gross_pnl,
                    'commission': commission,
                    'net_pnl': net_pnl,
                    'pnl_pct': pnl_pct,
                    'cumulative_pnl': self.stats['total_pnl']
                }

                # Add option-specific data if in options mode
                if getattr(self.config, 'OPTION_SELLING', False):
                    trade_data['option_symbol'] = position.get('option_symbol', 'N/A')
                    trade_data['option_type'] = position.get('option_type', 'N/A')
                    trade_data['strike_price'] = position.get('strike_price', 0)
                    trade_data['option_entry_price'] = position.get('option_entry_price', 0)
                    # Store the actual option exit premium (mark price), not spot price
                    trade_data['option_exit_price'] = option_mark_price_per_1000 if option_mark_price_per_1000 is not None else 0
                    trade_data['lots'] = position.get('lots', 0)

                # Write trade to CSV
                self._write_trade_to_csv(**trade_data)

                # Close position and activate cooldown
                self.current_position = None
                self.last_exit_time = datetime.now()

                self.logger.info("="*70)
                self.logger.info("[COOLDOWN ACTIVATED] 10-minute cooldown started")
                self.logger.info(f"  No new entries until: {(self.last_exit_time + timedelta(minutes=10)).strftime('%H:%M:%S')}")
                self.logger.info("="*70)

        except Exception as e:
            self.logger.error(f"Error monitoring position: {e}")

    def _monitor_swing_position(self, current_price):
        """Monitor swing position with dynamic swing trailing stop"""
        try:
            position = self.current_position
            direction = position['direction']

            # Calculate current profit in pips
            if direction == 'LONG':
                profit_pips = ((current_price - position['entry_price']) / position['entry_price']) * 10000
            else:  # SHORT
                profit_pips = ((position['entry_price'] - current_price) / position['entry_price']) * 10000

            # Update highest/lowest profit and prices
            if profit_pips > position['highest_profit_pips']:
                position['highest_profit_pips'] = profit_pips

            if profit_pips < position['lowest_profit_pips']:
                position['lowest_profit_pips'] = profit_pips

            if direction == 'LONG':
                if current_price > position['highest_price']:
                    position['highest_price'] = current_price
                if current_price < position['lowest_price']:
                    position['lowest_price'] = current_price
            else:  # SHORT
                if current_price < position['lowest_price']:
                    position['lowest_price'] = current_price
                if current_price > position['highest_price']:
                    position['highest_price'] = current_price

            # Fetch latest candles for swing point identification (only when new candle closes)
            current_time = datetime.now()

            # Check if we should fetch new candles (only when new candle closes)
            candle_just_closed = self._should_fetch_entry_tf_candles(current_time)
            if candle_just_closed:
                self.logger.info("═══════════════════════════════════════════════════════════")
                self.logger.info(f"[5-MIN CANDLE CLOSE] Fetching new data for swing analysis...")
                df_entry = self.delta_client.get_historical_data(
                    symbol=self.config.TRADING_SYMBOL,
                    resolution=self.config.ENTRY_TIMEFRAME,
                    lookback_candles=100  # Need more candles for ADX warm-up (ADX needs ~50+ for stable values)
                )

                if df_entry is not None and len(df_entry) >= 20:
                    self.df_entry_tf_global = df_entry  # Cache it
                    self.last_entry_tf_fetch_time = current_time
                else:
                    self.logger.warning(f"Failed to fetch {self.config.ENTRY_TIMEFRAME} candles, using cached data")
                    df_entry = self.df_entry_tf_global
            else:
                # Use cached candles
                df_entry = self.df_entry_tf_global

            if df_entry is not None and len(df_entry) >= 20:
                df_entry = df_entry.sort_values('timestamp').reset_index(drop=True)

                # Identify swing points
                df_entry = identify_swing_points(
                    df_entry,
                    lookback=self.config.SWING_LOOKBACK_CANDLES,
                    confirmation=self.config.SWING_CONFIRMATION_CANDLES
                )

                # Log current swing points for verification - ONLY on candle close
                recent_swings = df_entry.tail(10)
                latest_swing_high = recent_swings[recent_swings['swing_high'].notna()].tail(1)
                latest_swing_low = recent_swings[recent_swings['swing_low'].notna()].tail(1)

                if candle_just_closed:
                    self.logger.info("  [Swing Points Check]")
                    if len(latest_swing_high) > 0:
                        sh_row = latest_swing_high.iloc[0]
                        # Convert to IST
                        sh_ist = pd.Timestamp(sh_row['timestamp']) + timedelta(hours=5, minutes=30)
                        self.logger.info(f"    Latest Swing High: ${sh_row['swing_high']:,.2f} at {sh_ist.strftime('%Y-%m-%d %H:%M')} IST")
                    else:
                        self.logger.info(f"    Latest Swing High: None found")

                    if len(latest_swing_low) > 0:
                        sl_row = latest_swing_low.iloc[0]
                        # Convert to IST
                        sl_ist = pd.Timestamp(sl_row['timestamp']) + timedelta(hours=5, minutes=30)
                        self.logger.info(f"    Latest Swing Low: ${sl_row['swing_low']:,.2f} at {sl_ist.strftime('%Y-%m-%d %H:%M')} IST")
                    else:
                        self.logger.info(f"    Latest Swing Low: None found")

                # Update swing trailing stop
                old_stop = position['stop_loss']
                new_stop = update_swing_trailing_stop(position, df_entry, self.config)

                if new_stop != old_stop:
                    # Calculate locked profit
                    if direction == 'LONG':
                        locked_profit = new_stop - position['entry_price']
                    else:
                        locked_profit = position['entry_price'] - new_stop
                    locked_profit_dollars = locked_profit * position['remaining_size']

                    self.logger.info("  ═══════════════════════════════════════════════════════════")
                    self.logger.info("  ⚠️  TRAILING STOP UPDATED")
                    self.logger.info("  ═══════════════════════════════════════════════════════════")
                    self.logger.info(f"     OLD Stop: ${old_stop:,.2f}")
                    self.logger.info(f"     NEW Stop: ${new_stop:,.2f} ({'UP' if new_stop > old_stop else 'DOWN'} ${abs(new_stop - old_stop):,.2f})")
                    self.logger.info(f"     Locked Profit: ${locked_profit_dollars:+,.2f}")
                    self.logger.info("  ═══════════════════════════════════════════════════════════")
                    position['stop_loss'] = new_stop
                elif candle_just_closed:
                    self.logger.info(f"  [Stop Unchanged] ${old_stop:,.2f}")

            # Check exit conditions
            exit_triggered, exit_reason = check_swing_exit(position, current_price)

            # Calculate dollar P&L
            pnl_dollars = (profit_pips / 10000) * position['remaining_size']

            # Log position status - compact single line
            if direction == 'LONG':
                sl_distance = current_price - position['stop_loss']
            else:  # SHORT
                sl_distance = position['stop_loss'] - current_price

            sl_distance_pct = (sl_distance / current_price) * 100

            # Calculate time in trade
            time_in_trade = datetime.now() - position['entry_time']
            minutes = int(time_in_trade.total_seconds() / 60)
            hours = minutes // 60
            mins = minutes % 60

            # Display position differently for options vs futures
            if getattr(self.config, 'OPTION_SELLING', False):
                # OPTIONS DISPLAY: Show option symbol, mark price, and premium P&L
                option_position = self.order_manager.get_position(self.config.TRADING_SYMBOL)
                if option_position:
                    option_symbol = option_position.get('symbol', 'Unknown')
                    option_type = option_position.get('type', 'unknown').upper()
                    strike = option_position.get('strike', 0)
                    product_id = option_position.get('product_id')
                    lots_sold = position.get('lots', 0)

                    # Get entry premium (price when sold)
                    option_entry_price_per_1000 = position.get('option_entry_price', 0)

                    # Get option mark price (current premium value) from Delta Exchange
                    # ALWAYS fetches REAL mark price, even in paper trading mode
                    option_mark_price_per_1000 = None
                    option_pnl_usd = 0

                    try:
                        # Fetch actual mark price using get_ticker() - NO FALLBACKS
                        if hasattr(self.order_manager, 'client') and self.order_manager.client and product_id:
                            ticker_data = self.order_manager.client.get_ticker(product_id)

                            # Parse response
                            if isinstance(ticker_data, dict):
                                # Check if 'result' key exists (wrapped response)
                                if 'result' in ticker_data:
                                    mark_price_value = ticker_data['result'].get('mark_price')
                                else:
                                    # Direct response
                                    mark_price_value = ticker_data.get('mark_price')

                                if mark_price_value is not None:
                                    option_mark_price_per_1000 = float(mark_price_value)

                                    # Calculate option P&L
                                    # We SOLD the option, so profit when price goes DOWN
                                    # P&L = (entry_price - current_price) / divisor * lots
                                    option_divisor = self.order_manager.OPTION_PRICE_DIVISOR.get(self.config.TRADING_SYMBOL, 1000)
                                    option_pnl_usd = ((option_entry_price_per_1000 - option_mark_price_per_1000) / option_divisor) * lots_sold
                                else:
                                    self.logger.error(f"Mark price not found in ticker response for product {product_id}")
                            else:
                                self.logger.error(f"Invalid ticker response type for product {product_id}: {type(ticker_data)}")
                        else:
                            self.logger.error(f"Cannot fetch mark price: client not available or missing product_id")

                    except Exception as e:
                        self.logger.error(f"Error fetching option mark price for product {product_id}: {e}")

                    # Display with option P&L
                    if option_mark_price_per_1000 is not None and lots_sold > 0:
                        # Calculate premiums safely using correct divisor
                        option_divisor = self.order_manager.OPTION_PRICE_DIVISOR.get(self.config.TRADING_SYMBOL, 1000)
                        entry_premium = (option_entry_price_per_1000 / option_divisor) * lots_sold
                        current_premium = (option_mark_price_per_1000 / option_divisor) * lots_sold
                        pnl_sign = "+" if option_pnl_usd >= 0 else ""
                        self.logger.info(f"[Options Position] {option_symbol} ({option_type}) | Strike: ${strike:,} | Spot: ${current_price:,.2f}")
                        self.logger.info(f"  Entry Premium: ${entry_premium:,.2f} | Current Premium: ${current_premium:,.2f} | P&L: {pnl_sign}${option_pnl_usd:,.2f}")
                        self.logger.info(f"  SL: ${position['stop_loss']:,.2f} | Distance: ${sl_distance:,.2f} ({sl_distance_pct:.2f}%) | Time: {hours}h {mins}m")
                    else:
                        # Fallback display if mark price fetch failed or lots is 0
                        error_reason = "Mark price unavailable" if option_mark_price_per_1000 is None else "Invalid lot size"
                        self.logger.info(f"[Options Position] {option_symbol} ({option_type}) | Strike: ${strike:,} | Spot: ${current_price:,.2f} | Error: {error_reason} | SL: ${position['stop_loss']:,.2f} | Distance: ${sl_distance:,.2f} ({sl_distance_pct:.2f}%) | Time: {hours}h {mins}m")
                else:
                    self.logger.info(f"[Options Position] {direction} @ ${current_price:,.2f} | SL: ${position['stop_loss']:,.2f} | Time: {hours}h {mins}m")
            else:
                # FUTURES DISPLAY: Show normal P&L in pips
                self.logger.info(f"[Position] {direction} @ ${current_price:,.2f} | Entry: ${position['entry_price']:,.2f} | P&L: {profit_pips:+.1f} pips (${pnl_dollars:+,.2f}) | SL: ${position['stop_loss']:,.2f} | Distance: ${sl_distance:,.2f} ({sl_distance_pct:.2f}%) | Time: {hours}h {mins}m")

            # Exit if triggered
            if exit_triggered:
                # Execute exit order
                try:
                    # Use exact base quantity from entry (don't recalculate!)
                    exit_base_qty = position['position_size_base']

                    exit_result = self.order_manager.place_exit_order(
                        symbol=self.config.TRADING_SYMBOL,
                        side='sell' if direction == 'LONG' else 'buy',
                        size_base=exit_base_qty,
                        current_price=current_price,
                        reason=exit_reason
                    )

                    self.logger.info(f"[EXIT ORDER EXECUTED] ID: {exit_result['order_id']}")

                    actual_exit_price = exit_result['fill_price']

                    # FOR OPTIONS: Use actual option P&L calculated from mark prices
                    if getattr(self.config, 'OPTION_SELLING', False) and option_pnl_usd is not None:
                        # Use the option P&L that was already calculated from mark prices
                        pnl_dollars = option_pnl_usd
                        # Calculate equivalent pips for display (based on spot movement)
                        if direction == 'LONG':
                            final_profit_pips = ((actual_exit_price - position['entry_price']) / position['entry_price']) * 10000
                        else:
                            final_profit_pips = ((position['entry_price'] - actual_exit_price) / position['entry_price']) * 10000
                    else:
                        # FOR FUTURES: Use normal spot-based P&L calculation
                        if direction == 'LONG':
                            final_profit_pips = ((actual_exit_price - position['entry_price']) / position['entry_price']) * 10000
                        else:
                            final_profit_pips = ((position['entry_price'] - actual_exit_price) / position['entry_price']) * 10000

                        pnl_dollars = (final_profit_pips / 10000) * position['remaining_size']

                except Exception as e:
                    self.logger.error(f"[EXIT ORDER FAILED] {e}")
                    exit_reason = f"{exit_reason} (Order Failed)"
                    actual_exit_price = current_price
                    final_profit_pips = profit_pips
                    # Use option P&L if available, otherwise calculate from spot
                    if getattr(self.config, 'OPTION_SELLING', False) and option_pnl_usd is not None:
                        pnl_dollars = option_pnl_usd
                    else:
                        pnl_dollars = (profit_pips / 10000) * position['remaining_size']

                # Close position and activate cooldown
                self.stats['total_pnl'] += pnl_dollars
                self.current_position = None
                self.last_exit_time = datetime.now()

                self.logger.info("="*70)
                self.logger.info("[COOLDOWN ACTIVATED] 10-minute cooldown started")
                self.logger.info(f"  No new entries until: {(self.last_exit_time + timedelta(minutes=10)).strftime('%H:%M:%S')}")
                self.logger.info("="*70)

                self.logger.info("="*70)
                self.logger.info(f"[EXIT] {exit_reason}")
                # For options: show premium prices; for futures: show spot prices
                if getattr(self.config, 'OPTION_SELLING', False) and option_mark_price_per_1000 is not None:
                    option_divisor = self.order_manager.OPTION_PRICE_DIVISOR.get(self.config.TRADING_SYMBOL, 1000)
                    entry_premium_total = (position.get('option_entry_price', 0) / option_divisor) * position.get('lots', 0)
                    exit_premium_total = (option_mark_price_per_1000 / option_divisor) * position.get('lots', 0)
                    self.logger.info(f"  Entry Premium: ${entry_premium_total:,.2f}")
                    self.logger.info(f"  Exit Premium: ${exit_premium_total:,.2f}")
                    self.logger.info(f"  Spot Entry: ${position['entry_price']:,.2f} | Spot Exit: ${actual_exit_price:,.2f}")
                else:
                    self.logger.info(f"  Entry: ${position['entry_price']:,.2f}")
                    self.logger.info(f"  Exit: ${actual_exit_price:,.2f}")
                self.logger.info(f"  Final P&L: {final_profit_pips:.1f} pips (${pnl_dollars:,.2f})")
                self.logger.info(f"  Total P&L: ${self.stats['total_pnl']:,.2f}")
                self.logger.info("="*70)

                # Update stats
                if pnl_dollars > 0:
                    self.stats['winning_trades'] += 1
                else:
                    self.stats['losing_trades'] += 1

                # Calculate trade metrics
                exit_time = datetime.now()
                hold_time = (exit_time - position['entry_time']).total_seconds() / 60
                commission = 0.0  # TODO: Calculate actual commission
                gross_pnl = pnl_dollars
                net_pnl = gross_pnl - commission
                pnl_pct = (net_pnl / position['position_size_usd']) * 100

                # Prepare trade data dictionary
                trade_data = {
                    'trade_id': position['trade_id'],
                    'entry_time': position['entry_time'],
                    'exit_time': exit_time,
                    'direction': position['direction'],
                    'entry_price': position['entry_price'],
                    'exit_price': actual_exit_price,
                    'stop_loss': position['stop_loss'],
                    'trailing_stop_final': position['stop_loss'],
                    'position_size_base': position.get('position_size_base', 0),
                    'position_size_usd': position['position_size_usd'],
                    'leverage': position.get('leverage', 1),
                    'first_candle_body_pct': position.get('marubozu_body_pct', 0),
                    'first_candle_range': 0,
                    'entry_atr': 0,
                    'trend_30m': 'N/A',
                    'trend_1h': position.get('supertrend_1h', 'Unknown'),
                    'partial_profits_taken': [],
                    'highest_price': position['highest_price'],
                    'lowest_price': position['lowest_price'],
                    'highest_profit_pips': position.get('highest_profit_pips', 0),
                    'lowest_profit_pips': position.get('lowest_profit_pips', 0),
                    'exit_reason': exit_reason,
                    'hold_time_minutes': hold_time,
                    'gross_pnl': gross_pnl,
                    'commission': commission,
                    'net_pnl': net_pnl,
                    'pnl_pct': pnl_pct,
                    'cumulative_pnl': self.stats['total_pnl']
                }

                # Add option-specific data if in options mode
                if getattr(self.config, 'OPTION_SELLING', False):
                    trade_data['option_symbol'] = position.get('option_symbol', 'N/A')
                    trade_data['option_type'] = position.get('option_type', 'N/A')
                    trade_data['strike_price'] = position.get('strike_price', 0)
                    trade_data['option_entry_price'] = position.get('option_entry_price', 0)
                    # Store the actual option exit premium (mark price), not spot price
                    trade_data['option_exit_price'] = option_mark_price_per_1000 if option_mark_price_per_1000 is not None else 0
                    trade_data['lots'] = position.get('lots', 0)

                # Write trade to CSV
                self._write_trade_to_csv(**trade_data)

                # Close position
                self.current_position = None

        except Exception as e:
            self.logger.error(f"Error monitoring swing position: {e}")
            self.logger.debug(traceback.format_exc())

    def _write_trade_to_csv(self, **trade_data):
        """Write trade data to CSV file"""
        try:
            # Format times as IST timezone strings
            entry_time = trade_data['entry_time'].strftime('%Y-%m-%d %H:%M:%S')
            exit_time = trade_data['exit_time'].strftime('%Y-%m-%d %H:%M:%S')

            option_selling = getattr(self.config, 'OPTION_SELLING', False)

            if option_selling:
                # OPTIONS FORMAT
                row = [
                    trade_data['trade_id'],
                    entry_time,
                    exit_time,
                    trade_data['direction'],
                    trade_data.get('option_symbol', 'N/A'),
                    trade_data.get('option_type', 'N/A'),
                    f"{trade_data.get('strike_price', 0):.2f}",
                    f"{trade_data['entry_price']:.2f}",  # spot_entry_price
                    f"{trade_data['exit_price']:.2f}",   # spot_exit_price
                    f"{trade_data.get('option_entry_price', 0):.2f}",
                    f"{trade_data.get('option_exit_price', 0):.2f}",
                    f"{trade_data['stop_loss']:.2f}",
                    f"{trade_data['trailing_stop_final']:.2f}",
                    f"{trade_data['position_size_usd']:.2f}",
                    trade_data.get('lots', 0),
                    f"{trade_data['first_candle_body_pct']:.2f}",
                    f"{trade_data['first_candle_range']:.2f}",
                    f"{trade_data['entry_atr']:.2f}",
                    trade_data['trend_30m'],
                    trade_data['trend_1h'],
                    f"{trade_data['highest_price']:.2f}",  # highest_spot_price
                    f"{trade_data['lowest_price']:.2f}",   # lowest_spot_price
                    trade_data['exit_reason'],
                    f"{trade_data['hold_time_minutes']:.2f}",
                    f"{trade_data['gross_pnl']:.2f}",
                    f"{trade_data['commission']:.2f}",
                    f"{trade_data['net_pnl']:.2f}",
                    f"{trade_data['pnl_pct']:.2f}",
                    f"{trade_data['cumulative_pnl']:.2f}"
                ]
            else:
                # FUTURES FORMAT (original)
                # Format partial profits as string
                partial_profits = ','.join([str(p) for p in trade_data['partial_profits_taken']]) if trade_data['partial_profits_taken'] else 'None'

                row = [
                    trade_data['trade_id'],
                    entry_time,
                    exit_time,
                    trade_data['direction'],
                    f"{trade_data['entry_price']:.2f}",
                    f"{trade_data['exit_price']:.2f}",
                    f"{trade_data['take_profit']:.2f}" if trade_data['take_profit'] is not None else 'N/A',
                    f"{trade_data['stop_loss']:.2f}",
                    f"{trade_data['trailing_stop_final']:.2f}",
                    f"{trade_data['position_size_base']:.6f}",
                    f"{trade_data['position_size_usd']:.2f}",
                    trade_data['leverage'],
                    f"{trade_data['first_candle_body_pct']:.2f}",
                    f"{trade_data['first_candle_range']:.2f}",
                    f"{trade_data['entry_atr']:.2f}",
                    trade_data['trend_30m'],
                    trade_data['trend_1h'],
                    partial_profits,
                    f"{trade_data['highest_price']:.2f}",
                    f"{trade_data['lowest_price']:.2f}",
                    f"{trade_data['highest_profit_pips']:.2f}",
                    f"{trade_data['lowest_profit_pips']:.2f}",
                    trade_data['exit_reason'],
                    f"{trade_data['hold_time_minutes']:.2f}",
                    f"{trade_data['gross_pnl']:.2f}",
                    f"{trade_data['commission']:.2f}",
                    f"{trade_data['net_pnl']:.2f}",
                    f"{trade_data['pnl_pct']:.2f}",
                    f"{trade_data['cumulative_pnl']:.2f}"
                ]

            with open(self.trades_csv_file, 'a', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(row)

            self.logger.info(f"Trade #{trade_data['trade_id']} written to CSV: {self.trades_csv_file}")

        except Exception as e:
            self.logger.error(f"Error writing trade to CSV: {e}")

    def shutdown(self):
        """Graceful shutdown"""
        if not self.running:
            return

        self.logger.info("="*70)
        self.logger.info("SHUTTING DOWN...")
        self.logger.info(f"Total Trades: {self.stats['total_trades']}")
        self.logger.info(f"Total P&L: ${self.stats['total_pnl']:,.2f}")
        self.logger.info("="*70)

        self.running = False
        self.shutdown_event.set()

        # Restore original stdout
        if hasattr(self, 'original_stdout'):
            sys.stdout = self.original_stdout


def main():
    """Main entry point"""
    print("\n" + "="*70)
    print("BTC FUTURES SCALPING BOT - REAL-TIME CANDLES")
    print("="*70)
    print("Mode: PAPER TRADING")
    print("Press Ctrl+C to stop")
    print("="*70 + "\n")

    # API keys
    api_key = 'GQkBVk4mVnazOzOib2Jm11V3XDz1Nk'
    api_secret = '4TFECpYeoR3DY1xxyEHj1mpY7WlWSSAcRQHKL7WgL1rwDFkGwlbHB9SH8Tdh'

    # Initialize bot
    bot = LiveTradingBotRealtime(
        api_key=api_key,
        api_secret=api_secret,
        paper_trading=True
    )

    try:
        bot.start()
    except KeyboardInterrupt:
        print("\nShutdown requested by user")
    except Exception as e:
        print(f"\nFatal error: {e}")
        traceback.print_exc()
    finally:
        bot.shutdown()


if __name__ == "__main__":
    main()
