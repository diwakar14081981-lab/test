"""
Swing SuperTrend Strategy - Core Logic Module

This module contains all the swing trading strategy logic:
- Swing point identification
- 288 EMA calculation
- Entry signal detection
- Swing trailing stop management
- Exit signal detection

Strategy Overview:
1. Entry: 60% Marubozu + 288 EMA + 1H SuperTrend + Swing Break
2. Exit: Swing point trailing (dynamic stop loss)
3. NO fixed take profit, NO ADX filter, NO volume filter

Tested Performance (7 months Apr-Oct 2025):
- Ethereum: 130 trades, 62% WR, PF 6.88, +410% return
- Bitcoin: 138 trades, 56% WR, PF 1.53, +105% return
"""

import pandas as pd
import numpy as np
import logging
from datetime import datetime

logger = logging.getLogger(__name__)


# =============================================================================
# SWING POINT IDENTIFICATION
# =============================================================================

def identify_swing_points(df, lookback=4, confirmation=3):
    """
    Identify swing highs and lows with confirmation

    Args:
        df: DataFrame with OHLC data
        lookback: Number of candles to look left and right (default: 4)
        confirmation: Number of candles after swing to confirm (default: 3)

    Returns:
        DataFrame with 'swing_high' and 'swing_low' columns added

    Logic:
        Swing High: high >= max(left 'lookback' highs) AND max(right 'lookback' highs)
        Swing Low: low <= min(left 'lookback' lows) AND min(right 'lookback' lows)
        Only confirmed swings are marked (after 'confirmation' candles pass)
    """
    df = df.copy()

    # Initialize swing columns
    df['swing_high'] = None
    df['swing_low'] = None

    # Need enough candles for swing detection
    if len(df) < lookback * 2 + confirmation:
        logger.warning(f"Not enough candles for swing detection. Need {lookback * 2 + confirmation}, have {len(df)}")
        return df

    # Identify swing points (need lookback candles on both sides)
    for i in range(lookback, len(df) - lookback):
        # Get current candle values
        current_high = df.loc[df.index[i], 'high']
        current_low = df.loc[df.index[i], 'low']

        # Get left and right candles for comparison
        left_highs = df.loc[df.index[i-lookback:i], 'high']
        right_highs = df.loc[df.index[i+1:i+1+lookback], 'high']
        left_lows = df.loc[df.index[i-lookback:i], 'low']
        right_lows = df.loc[df.index[i+1:i+1+lookback], 'low']

        # Check if current candle is a swing high
        if (current_high >= left_highs.max()) and (current_high >= right_highs.max()):
            df.loc[df.index[i], 'swing_high'] = current_high

        # Check if current candle is a swing low
        if (current_low <= left_lows.min()) and (current_low <= right_lows.min()):
            df.loc[df.index[i], 'swing_low'] = current_low

    return df


def get_most_recent_swing(df, direction='high', before_index=None):
    """
    Get the most recent confirmed swing high or low

    Args:
        df: DataFrame with swing_high and swing_low columns
        direction: 'high' or 'low'
        before_index: Only look for swings before this index (optional)

    Returns:
        tuple: (swing_value, swing_index) or (None, None) if not found
    """
    if before_index is None:
        before_index = len(df) - 1

    # Search backwards from before_index
    for i in range(before_index, -1, -1):
        if direction == 'high':
            swing_value = df.loc[df.index[i], 'swing_high']
            if pd.notna(swing_value):
                return swing_value, i
        elif direction == 'low':
            swing_value = df.loc[df.index[i], 'swing_low']
            if pd.notna(swing_value):
                return swing_value, i

    return None, None


# =============================================================================
# 288 EMA CALCULATION
# =============================================================================

def calculate_288_ema(df):
    """
    Calculate 288-period Exponential Moving Average

    On 5-minute chart: 288 periods = 24 hours

    Args:
        df: DataFrame with 'close' column

    Returns:
        Series with EMA values
    """
    return df['close'].ewm(span=288, adjust=False).mean()


# =============================================================================
# ENTRY SIGNAL DETECTION
# =============================================================================

def detect_swing_entry_signal(df_5min, df_1h, config):
    """
    Detect entry signal for swing strategy

    Entry Requirements (ALL must be TRUE):
    1. 60%+ Marubozu candle on latest 5-min candle
    2. Price above/below 288 EMA (LONG: above, SHORT: below)
    3. 1H SuperTrend aligned (LONG: +1, SHORT: -1)
    4. Marubozu breaks most recent confirmed swing point
    5. Swing has confirmation (3 candles passed)

    Args:
        df_5min: DataFrame with 5-minute OHLC data (with swing points and 288 EMA)
        df_1h: DataFrame with 1-hour data (with SuperTrend direction)
        config: Configuration object

    Returns:
        dict with signal info if signal detected, None otherwise

        Signal dict contains:
        {
            'direction': 'LONG' or 'SHORT',
            'signal_time': timestamp,
            'entry_price': current price,
            'marubozu_body_pct': percentage,
            'marubozu_range': candle range,
            'ema_288': EMA value,
            'supertrend_1h': 1H SuperTrend direction,
            'entry_swing_high': most recent swing high,
            'entry_swing_low': most recent swing low,
            'swing_break_price': price that broke swing
        }
    """
    try:
        # Check if we have enough data
        if len(df_5min) < 300:  # Need 288 for EMA + some buffer
            logger.info("  [DATA CHECK FAILED] Not enough 5-min data for entry detection (need 300+ candles)")
            return None

        if df_1h is None or len(df_1h) == 0:
            logger.info("  [DATA CHECK FAILED] No 1H data available for SuperTrend filter")
            return None

        # Get latest candle from 5-min chart
        latest_candle = df_5min.iloc[-1]

        # CHECK 1: Marubozu Detection (OPTIONAL - based on config)
        body = abs(latest_candle['close'] - latest_candle['open'])
        candle_range = latest_candle['high'] - latest_candle['low']
        body_pct = 0  # Initialize for later logging

        # Determine candle direction first
        is_bullish = latest_candle['close'] > latest_candle['open']
        is_bearish = latest_candle['close'] < latest_candle['open']

        if not is_bullish and not is_bearish:
            logger.info(f"  [CHECK 1 FAILED] Doji candle (no direction)")
            return None

        direction = 'LONG' if is_bullish else 'SHORT'
        logger.info(f"  Candle Direction: {direction}")

        # Apply Marubozu filter if enabled
        if config.USE_MARUBOZU_FILTER:
            if candle_range <= 0:
                logger.info(f"  [CHECK 1 FAILED] Candle has no range (doji or error)")
                return None

            body_pct = (body / candle_range) * 100
            min_body_pct = config.FIRST_CANDLE_MIN_BODY_PERCENTAGE

            if body_pct < min_body_pct:
                logger.info(f"  [CHECK 1 FAILED] Marubozu: Body {body_pct:.1f}% < Required {min_body_pct}%")
                return None

            logger.info(f"  [CHECK 1 PASSED] Marubozu: {body_pct:.1f}% body >= {min_body_pct}%")
        else:
            # Calculate body_pct for logging even when filter disabled
            if candle_range > 0:
                body_pct = (body / candle_range) * 100
            logger.info(f"  [CHECK 1 SKIPPED] Marubozu filter disabled (Body: {body_pct:.1f}%)")

        # Initialize variables that may be used later in signal dict
        ema_288 = None
        supertrend_1h = None

        # CHECK 2: 288 EMA Filter (OPTIONAL - based on config)
        if config.USE_288_EMA_FILTER:
            if 'ema_288' not in df_5min.columns:
                logger.info(f"  [CHECK 2 FAILED] 288 EMA not calculated")
                return None

            ema_288 = latest_candle['ema_288']

            if pd.isna(ema_288):
                logger.info(f"  [CHECK 2 FAILED] 288 EMA not ready yet")
                return None

            if direction == 'LONG' and latest_candle['close'] < ema_288:
                logger.info(f"  [CHECK 2 FAILED] LONG: Close ${latest_candle['close']:.2f} < 288 EMA ${ema_288:.2f}")
                return None

            if direction == 'SHORT' and latest_candle['close'] > ema_288:
                logger.info(f"  [CHECK 2 FAILED] SHORT: Close ${latest_candle['close']:.2f} > 288 EMA ${ema_288:.2f}")
                return None

            logger.info(f"  [CHECK 2 PASSED] Price ${latest_candle['close']:.2f} {'>' if direction=='LONG' else '<'} 288 EMA ${ema_288:.2f}")
        else:
            logger.info(f"  [CHECK 2 SKIPPED] 288 EMA Filter disabled in config")

        # CHECK 3: 1H SuperTrend Filter (OPTIONAL - based on config)
        if config.USE_1H_SUPERTREND_FILTER:
            if 'st_direction' not in df_1h.columns:
                logger.info(f"  [CHECK 3 FAILED] 1H SuperTrend not calculated")
                return None

            latest_1h = df_1h.iloc[-1]
            supertrend_1h = latest_1h['st_direction']

            if pd.isna(supertrend_1h):
                logger.info(f"  [CHECK 3 FAILED] 1H SuperTrend not ready")
                return None

            if direction == 'LONG' and supertrend_1h != 1:
                st_text = 'BEARISH (-1)' if supertrend_1h == -1 else f'{supertrend_1h}'
                logger.info(f"  [CHECK 3 FAILED] LONG signal but 1H SuperTrend is {st_text}")
                return None

            if direction == 'SHORT' and supertrend_1h != -1:
                st_text = 'BULLISH (+1)' if supertrend_1h == 1 else f'{supertrend_1h}'
                logger.info(f"  [CHECK 3 FAILED] SHORT signal but 1H SuperTrend is {st_text}")
                return None

            st_text = 'BULLISH (+1)' if supertrend_1h == 1 else 'BEARISH (-1)'
            logger.info(f"  [CHECK 3 PASSED] 1H SuperTrend: {st_text} (matches {direction})")
        else:
            logger.info(f"  [CHECK 3 SKIPPED] 1H SuperTrend Filter disabled in config")

        # CHECK 4: Swing Break Requirement
        if 'swing_high' not in df_5min.columns or 'swing_low' not in df_5min.columns:
            logger.info(f"  [CHECK 4 FAILED] Swing points not identified")
            return None

        # Get most recent swing points (look before latest candle)
        latest_index = len(df_5min) - 1
        swing_high, swing_high_idx = get_most_recent_swing(df_5min, 'high', before_index=latest_index-1)
        swing_low, swing_low_idx = get_most_recent_swing(df_5min, 'low', before_index=latest_index-1)

        # CHECK 5: Swing Confirmation (3 candles must have passed since swing)
        confirmation_candles = config.SWING_CONFIRMATION_CANDLES

        if direction == 'LONG':
            if swing_low is None or swing_low_idx is None:
                logger.info(f"  [CHECK 4 FAILED] No swing low found for LONG entry")
                return None

            # Check if enough candles passed for confirmation
            candles_since_swing = latest_index - swing_low_idx
            if candles_since_swing < confirmation_candles:
                logger.info(f"  [CHECK 5 FAILED] Swing low not confirmed yet ({candles_since_swing}/{confirmation_candles} candles)")
                return None

            # Check if Marubozu breaks above swing low (for LONG, we actually want to break swing LOW to reverse)
            # Actually, for LONG we should break recent swing HIGH
            if swing_high is None or swing_high_idx is None:
                logger.info(f"  [CHECK 4 FAILED] No swing high found for LONG breakout")
                return None

            # Check confirmation for swing high
            candles_since_swing_high = latest_index - swing_high_idx
            if candles_since_swing_high < confirmation_candles:
                logger.info(f"  [CHECK 5 FAILED] Swing high not confirmed yet ({candles_since_swing_high}/{confirmation_candles} candles)")
                return None

            # Must break above swing high for LONG
            if latest_candle['high'] <= swing_high:
                logger.info(f"  [CHECK 4 FAILED] LONG: High ${latest_candle['high']:.2f} did not break swing high ${swing_high:.2f}")
                return None

            logger.info(f"  [CHECK 4 PASSED] LONG: High ${latest_candle['high']:.2f} broke swing high ${swing_high:.2f}")
            logger.info(f"  [CHECK 5 PASSED] Swing points confirmed (≥{confirmation_candles} candles)")

            swing_break_price = swing_high

        else:  # SHORT
            if swing_high is None or swing_high_idx is None:
                logger.info(f"  [CHECK 4 FAILED] No swing high found for SHORT entry")
                return None

            # Check if enough candles passed for confirmation
            candles_since_swing = latest_index - swing_high_idx
            if candles_since_swing < confirmation_candles:
                logger.info(f"  [CHECK 5 FAILED] Swing high not confirmed yet ({candles_since_swing}/{confirmation_candles} candles)")
                return None

            # For SHORT, we should break recent swing LOW
            if swing_low is None or swing_low_idx is None:
                logger.info(f"  [CHECK 4 FAILED] No swing low found for SHORT breakout")
                return None

            # Check confirmation for swing low
            candles_since_swing_low = latest_index - swing_low_idx
            if candles_since_swing_low < confirmation_candles:
                logger.info(f"  [CHECK 5 FAILED] Swing low not confirmed yet ({candles_since_swing_low}/{confirmation_candles} candles)")
                return None

            # Must break below swing low for SHORT
            if latest_candle['low'] >= swing_low:
                logger.info(f"  [CHECK 4 FAILED] SHORT: Low ${latest_candle['low']:.2f} did not break swing low ${swing_low:.2f}")
                return None

            logger.info(f"  [CHECK 4 PASSED] SHORT: Low ${latest_candle['low']:.2f} broke swing low ${swing_low:.2f}")
            logger.info(f"  [CHECK 5 PASSED] Swing points confirmed (≥{confirmation_candles} candles)")

            swing_break_price = swing_low

        # ALL CHECKS PASSED - Generate entry signal
        signal = {
            'direction': direction,
            'signal_time': latest_candle['timestamp'] if 'timestamp' in latest_candle else datetime.now(),
            'entry_price': latest_candle['close'],
            'marubozu_body_pct': body_pct,
            'marubozu_range': candle_range,
            'ema_288': ema_288,
            'supertrend_1h': supertrend_1h,
            'entry_swing_high': swing_high,
            'entry_swing_low': swing_low,
            'swing_break_price': swing_break_price
        }

        logger.info(f"[SWING ENTRY SIGNAL] {direction} detected!")
        logger.info(f"  Marubozu: {body_pct:.1f}% body, Range: ${candle_range:.2f}")

        # Only show EMA if enabled
        if ema_288 is not None:
            logger.info(f"  288 EMA: ${ema_288:.2f}, Price: ${latest_candle['close']:.2f}")
        else:
            logger.info(f"  288 EMA: Disabled, Price: ${latest_candle['close']:.2f}")

        # Only show SuperTrend if enabled
        if supertrend_1h is not None:
            logger.info(f"  1H SuperTrend: {'Bullish' if supertrend_1h == 1 else 'Bearish'}")
        else:
            logger.info(f"  1H SuperTrend: Disabled")

        logger.info(f"  Swing Break: ${swing_break_price:.2f}")

        return signal

    except Exception as e:
        logger.error(f"Error detecting swing entry signal: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return None


# =============================================================================
# SWING TRAILING STOP MANAGEMENT
# =============================================================================

def update_swing_trailing_stop(position, df_5min, config):
    """
    Update trailing stop based on new swing points

    Logic:
        LONG: Trail UP to higher swing lows (never down)
        SHORT: Trail DOWN to lower swing highs (never up)
        Add STOP_LOSS_BUFFER_PIPS to swing level

    Args:
        position: Current position dict with 'direction' and 'stop_loss'
        df_5min: DataFrame with swing points identified
        config: Configuration object

    Returns:
        float: Updated stop loss price (or current if no update)
    """
    try:
        direction = position['direction']
        current_stop = position['stop_loss']

        # Get buffer as percentage of price
        buffer_pct = config.STOP_LOSS_BUFFER_PCT
        current_price = df_5min.iloc[-1]['close']
        buffer_price = current_price * (buffer_pct / 100)

        # Get max risk cap
        entry_price = position['entry_price']
        max_stop_distance = entry_price * (config.MAX_STOP_LOSS_PCT / 100)

        # Get most recent swing
        latest_index = len(df_5min) - 1

        if direction == 'LONG':
            # For LONG, trail stop UP to higher swing lows
            swing_low, swing_idx = get_most_recent_swing(df_5min, 'low', before_index=latest_index)

            if swing_low is None:
                return current_stop  # No swing found, keep current stop

            # Calculate new stop (swing low - buffer)
            new_stop = swing_low - buffer_price

            # Apply max risk cap (don't let stop go below min_allowed_stop)
            min_allowed_stop = entry_price - max_stop_distance
            if new_stop < min_allowed_stop:
                new_stop = min_allowed_stop
                logger.info(f"[RISK CAP APPLIED] Stop capped at ${new_stop:.2f} (Max risk: {config.MAX_STOP_LOSS_PCT}%)")

            # Only move stop UP (never down)
            if new_stop > current_stop:
                logger.info(f"[SWING TRAIL UP] ${current_stop:.2f} -> ${new_stop:.2f} (Swing Low: ${swing_low:.2f})")
                return new_stop
            else:
                return current_stop

        else:  # SHORT
            # For SHORT, trail stop DOWN to lower swing highs
            swing_high, swing_idx = get_most_recent_swing(df_5min, 'high', before_index=latest_index)

            if swing_high is None:
                return current_stop  # No swing found, keep current stop

            # Calculate new stop (swing high + buffer)
            new_stop = swing_high + buffer_price

            # Apply max risk cap (don't let stop go above max_allowed_stop)
            max_allowed_stop = entry_price + max_stop_distance
            if new_stop > max_allowed_stop:
                new_stop = max_allowed_stop
                logger.info(f"[RISK CAP APPLIED] Stop capped at ${new_stop:.2f} (Max risk: {config.MAX_STOP_LOSS_PCT}%)")

            # Only move stop DOWN (never up)
            if new_stop < current_stop:
                logger.info(f"[SWING TRAIL DOWN] ${current_stop:.2f} -> ${new_stop:.2f} (Swing High: ${swing_high:.2f})")
                return new_stop
            else:
                return current_stop

    except Exception as e:
        logger.error(f"Error updating swing trailing stop: {e}")
        return position['stop_loss']  # Return current stop on error


# =============================================================================
# EXIT SIGNAL DETECTION
# =============================================================================

def check_swing_exit(position, current_price):
    """
    Check if swing trailing stop is hit

    Args:
        position: Current position dict with 'direction' and 'stop_loss'
        current_price: Current market price

    Returns:
        tuple: (exit_triggered: bool, exit_reason: str or None)
    """
    direction = position['direction']
    stop_loss = position['stop_loss']

    if direction == 'LONG':
        if current_price <= stop_loss:
            return True, 'Swing Stop (LONG)'
    else:  # SHORT
        if current_price >= stop_loss:
            return True, 'Swing Stop (SHORT)'

    return False, None


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def calculate_initial_stop_loss(entry_price, direction, swing_high, swing_low, config):
    """
    Calculate initial stop loss based on entry swing point

    Args:
        entry_price: Entry price of the trade
        direction: 'LONG' or 'SHORT'
        swing_high: Entry swing high value
        swing_low: Entry swing low value
        config: Configuration object

    Returns:
        float: Initial stop loss price
    """
    # Use percentage-based buffer
    buffer_pct = config.STOP_LOSS_BUFFER_PCT
    buffer_price = entry_price * (buffer_pct / 100)

    # Calculate max risk cap
    max_stop_distance = entry_price * (config.MAX_STOP_LOSS_PCT / 100)

    if direction == 'LONG':
        # LONG: Stop below swing low
        if swing_low is None:
            logger.warning("No swing low for LONG stop loss, using max risk cap")
            stop_loss = entry_price - max_stop_distance
        else:
            stop_loss = swing_low - buffer_price

            # Apply max risk cap (don't let stop go below min_allowed_stop)
            min_allowed_stop = entry_price - max_stop_distance
            if stop_loss < min_allowed_stop:
                stop_loss = min_allowed_stop
                logger.info(f"[INITIAL STOP CAPPED] Stop set to ${stop_loss:.2f} (Max risk: {config.MAX_STOP_LOSS_PCT}%)")

    else:  # SHORT
        # SHORT: Stop above swing high
        if swing_high is None:
            logger.warning("No swing high for SHORT stop loss, using max risk cap")
            stop_loss = entry_price + max_stop_distance
        else:
            stop_loss = swing_high + buffer_price

            # Apply max risk cap (don't let stop go above max_allowed_stop)
            max_allowed_stop = entry_price + max_stop_distance
            if stop_loss > max_allowed_stop:
                stop_loss = max_allowed_stop
                logger.info(f"[INITIAL STOP CAPPED] Stop set to ${stop_loss:.2f} (Max risk: {config.MAX_STOP_LOSS_PCT}%)")

    return stop_loss
