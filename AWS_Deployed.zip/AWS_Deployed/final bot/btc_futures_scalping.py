"""
BTC Futures Scalping - Indicator and Filter Functions
Required by btc_futures_scalping_advanced.py
"""

import pandas as pd
import numpy as np


def calculate_atr(df, period=14):
    """
    Calculate Average True Range (ATR) - OFFICIAL Wilder's Method
    Based on J. Welles Wilder's original formula (New Concepts in Technical Trading Systems)
    Uses RMA (Relative Moving Average) = Wilder's Smoothing

    This is the default method used by TradingView.

    Returns: ATR values
    """
    high = df['high'].copy()
    low = df['low'].copy()
    close = df['close'].copy()

    # Step 1: Calculate True Range (TR)
    # TR = max(high-low, |high-prevClose|, |low-prevClose|)
    tr1 = high - low
    tr2 = abs(high - close.shift())
    tr3 = abs(low - close.shift())
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)

    # Step 2: Calculate ATR using Wilder's Smoothing (RMA)
    # Use numpy array for calculations, convert to Series at the end
    atr_values = np.full(len(df), np.nan)

    # First ATR = Simple average of first 'period' TR values
    atr_values[period-1] = tr.iloc[:period].mean()

    # Subsequent ATR values use Wilder's smoothing formula:
    # ATR[t] = (ATR[t-1] * (period-1) + TR[t]) / period
    # This is equivalent to: ATR[t] = ATR[t-1] - (ATR[t-1]/period) + (TR[t]/period)
    for i in range(period, len(df)):
        atr_values[i] = (atr_values[i-1] * (period - 1) + tr.iloc[i]) / period

    # Convert to Series at the end
    atr = pd.Series(atr_values, index=df.index)
    return atr


def calculate_supertrend(df, period=10, multiplier=3.0):
    """
    Calculate SuperTrend indicator - OFFICIAL TradingView Implementation
    Based on: https://www.tradingview.com/support/solutions/43000634738-supertrend/

    Returns: (supertrend_values, direction)
    direction: 1 = uptrend (bullish), -1 = downtrend (bearish)
    """
    high = df['high'].copy()
    low = df['low'].copy()
    close = df['close'].copy()

    # Calculate ATR
    atr = calculate_atr(df, period)

    # Step 1: Calculate basic bands
    hl2 = (high + low) / 2
    basic_upper_band = hl2 + (multiplier * atr)
    basic_lower_band = hl2 - (multiplier * atr)

    # Initialize final bands and trend - use numpy arrays
    final_upper_band_values = np.full(len(df), np.nan)
    final_lower_band_values = np.full(len(df), np.nan)
    supertrend_values = np.full(len(df), np.nan)
    direction_values = np.full(len(df), np.nan)

    # First row initialization
    final_upper_band_values[0] = basic_upper_band.iloc[0]
    final_lower_band_values[0] = basic_lower_band.iloc[0]
    supertrend_values[0] = basic_lower_band.iloc[0]
    direction_values[0] = 1  # Start with uptrend

    # Step 2 & 3: Calculate for each subsequent row
    for i in range(1, len(df)):
        # Step 2: Band refinement (official TradingView logic)
        # Upper band: use basic if it's lower OR if previous close broke above previous upper
        if pd.notna(basic_upper_band.iloc[i]) and pd.notna(final_upper_band_values[i-1]):
            if basic_upper_band.iloc[i] < final_upper_band_values[i-1] or close.iloc[i-1] > final_upper_band_values[i-1]:
                final_upper_band_values[i] = basic_upper_band.iloc[i]
            else:
                final_upper_band_values[i] = final_upper_band_values[i-1]
        else:
            final_upper_band_values[i] = basic_upper_band.iloc[i]

        # Lower band: use basic if it's higher OR if previous close broke below previous lower
        if pd.notna(basic_lower_band.iloc[i]) and pd.notna(final_lower_band_values[i-1]):
            if basic_lower_band.iloc[i] > final_lower_band_values[i-1] or close.iloc[i-1] < final_lower_band_values[i-1]:
                final_lower_band_values[i] = basic_lower_band.iloc[i]
            else:
                final_lower_band_values[i] = final_lower_band_values[i-1]
        else:
            final_lower_band_values[i] = basic_lower_band.iloc[i]

        # Step 3: Trend direction determination (official TradingView logic)
        if pd.notna(atr.iloc[i]):
            # If previous supertrend was upper band (downtrend)
            if supertrend_values[i-1] == final_upper_band_values[i-1]:
                # Check if close broke above upper band -> flip to uptrend
                if close.iloc[i] > final_upper_band_values[i]:
                    direction_values[i] = 1  # uptrend
                else:
                    direction_values[i] = -1  # stay downtrend
            # If previous supertrend was lower band (uptrend)
            else:
                # Check if close broke below lower band -> flip to downtrend
                if close.iloc[i] < final_lower_band_values[i]:
                    direction_values[i] = -1  # downtrend
                else:
                    direction_values[i] = 1  # stay uptrend
        else:
            # Default to downtrend when ATR not ready
            direction_values[i] = -1

        # Step 4: Set supertrend based on direction
        if direction_values[i] == 1:
            supertrend_values[i] = final_lower_band_values[i]
        else:
            supertrend_values[i] = final_upper_band_values[i]

    # Convert to Series at the end
    supertrend = pd.Series(supertrend_values, index=df.index)
    direction = pd.Series(direction_values, index=df.index)
    return supertrend, direction


def calculate_adx(df, period=14):
    """
    Calculate Average Directional Index (ADX) - OFFICIAL Wilder's Method
    Based on Welles Wilder's original formula with Wilder's smoothing

    Returns: ADX values
    """
    high = df['high'].copy()
    low = df['low'].copy()
    close = df['close'].copy()

    # Step 1: Calculate +DM and -DM (Directional Movement)
    up_move = high.diff()
    down_move = -low.diff()

    plus_dm = pd.Series(0.0, index=df.index)
    minus_dm = pd.Series(0.0, index=df.index)

    # Apply Wilder's rules for +DM and -DM
    for i in range(1, len(df)):
        if up_move.iloc[i] > down_move.iloc[i] and up_move.iloc[i] > 0:
            plus_dm.iloc[i] = up_move.iloc[i]
        if down_move.iloc[i] > up_move.iloc[i] and down_move.iloc[i] > 0:
            minus_dm.iloc[i] = down_move.iloc[i]

    # Step 2: Calculate True Range
    tr1 = high - low
    tr2 = abs(high - close.shift())
    tr3 = abs(low - close.shift())
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)

    # Step 3: Apply Wilder's smoothing to TR, +DM, -DM - use numpy arrays
    smoothed_tr_values = np.full(len(df), np.nan)
    smoothed_plus_dm_values = np.full(len(df), np.nan)
    smoothed_minus_dm_values = np.full(len(df), np.nan)

    # First smoothed value = sum of first 'period' values
    smoothed_tr_values[period-1] = tr.iloc[:period].sum()
    smoothed_plus_dm_values[period-1] = plus_dm.iloc[:period].sum()
    smoothed_minus_dm_values[period-1] = minus_dm.iloc[:period].sum()

    # Subsequent values use Wilder's smoothing formula:
    # Smoothed[i] = Smoothed[i-1] - (Smoothed[i-1]/period) + Current[i]
    for i in range(period, len(df)):
        smoothed_tr_values[i] = smoothed_tr_values[i-1] - (smoothed_tr_values[i-1] / period) + tr.iloc[i]
        smoothed_plus_dm_values[i] = smoothed_plus_dm_values[i-1] - (smoothed_plus_dm_values[i-1] / period) + plus_dm.iloc[i]
        smoothed_minus_dm_values[i] = smoothed_minus_dm_values[i-1] - (smoothed_minus_dm_values[i-1] / period) + minus_dm.iloc[i]

    # Convert to Series for division operations
    smoothed_tr = pd.Series(smoothed_tr_values, index=df.index)
    smoothed_plus_dm = pd.Series(smoothed_plus_dm_values, index=df.index)
    smoothed_minus_dm = pd.Series(smoothed_minus_dm_values, index=df.index)

    # Step 4: Calculate +DI and -DI
    plus_di = 100 * (smoothed_plus_dm / smoothed_tr)
    minus_di = 100 * (smoothed_minus_dm / smoothed_tr)

    # Step 5: Calculate DX (Directional Index)
    dx = 100 * abs(plus_di - minus_di) / (plus_di + minus_di)
    dx = dx.replace([np.inf, -np.inf], 0)  # Handle division by zero

    # Step 6: Calculate ADX using Wilder's smoothing on DX - use numpy array
    adx_values = np.full(len(df), np.nan)

    # First ADX = average of first 'period' DX values
    first_adx_idx = period + (period - 1)  # Need 'period' more bars after first DI calculation
    if first_adx_idx < len(df):
        adx_values[first_adx_idx] = dx.iloc[period:first_adx_idx+1].mean()

        # Subsequent ADX values use Wilder's smoothing:
        # ADX[i] = ((ADX[i-1] * (period-1)) + DX[i]) / period
        for i in range(first_adx_idx + 1, len(df)):
            if pd.notna(dx.iloc[i]):
                adx_values[i] = ((adx_values[i-1] * (period - 1)) + dx.iloc[i]) / period

    # Convert to Series at the end
    adx = pd.Series(adx_values, index=df.index)
    return adx


def calculate_volume_filter(df, threshold=1.5, ma_period=20):
    """
    Calculate volume moving average and volume ratio for filtering

    Used to identify volume spikes indicating institutional participation.

    Parameters:
    - df: DataFrame with 'volume' column
    - threshold: Minimum volume ratio (e.g., 1.5 = 1.5× average)
    - ma_period: Period for volume moving average (default: 20)

    Returns: DataFrame with additional columns:
    - volume_ma: Simple moving average of volume
    - volume_ratio: Current volume / volume_ma
    - volume_spike: Boolean, True if volume_ratio >= threshold
    """
    # Calculate volume moving average
    df['volume_ma'] = df['volume'].rolling(window=ma_period).mean()

    # Calculate volume ratio
    df['volume_ratio'] = df['volume'] / df['volume_ma']

    # Mark volume spikes
    df['volume_spike'] = df['volume_ratio'] >= threshold

    return df


class PriceActionFilters:
    """Price action filter methods"""

    @staticmethod
    def check_candle_body_strength(candle, min_body_pct):
        """Check if candle has strong body (minimal wicks)"""
        body = abs(candle['close'] - candle['open'])
        total_range = candle['high'] - candle['low']

        if total_range == 0:
            return False

        body_pct = (body / total_range) * 100
        return body_pct >= min_body_pct

    @staticmethod
    def check_momentum_consistency(df, idx, direction, min_move_pct):
        """Check if price moves consistently in same direction"""
        if idx == 0:
            return False

        current = df.iloc[idx]
        previous = df.iloc[idx - 1]

        move_pct = abs((current['close'] - previous['close']) / previous['close']) * 100

        return move_pct >= min_move_pct

    @staticmethod
    def check_atr_expansion(df, idx, lookback, min_expansion_pct):
        """Check if ATR is expanding (volatility breakout)"""
        if idx < lookback:
            return False

        if 'atr' not in df.columns:
            return False

        current_atr = df.iloc[idx]['atr']
        recent_atrs = df.iloc[idx - lookback:idx]['atr']
        avg_atr = recent_atrs.mean()

        if pd.isna(current_atr) or pd.isna(avg_atr) or avg_atr == 0:
            return False

        return current_atr >= avg_atr * (1 + min_expansion_pct / 100)

    @staticmethod
    def check_wick_ratio(candle, max_wick_ratio):
        """Check if wick is not too long compared to body"""
        body = abs(candle['close'] - candle['open'])

        if body == 0:
            return False

        upper_wick = candle['high'] - max(candle['open'], candle['close'])
        lower_wick = min(candle['open'], candle['close']) - candle['low']
        max_wick = max(upper_wick, lower_wick)

        wick_ratio = max_wick / body

        return wick_ratio <= max_wick_ratio

    @staticmethod
    def check_acceleration(df, idx, lookback):
        """Check if price movement is accelerating"""
        if idx < lookback:
            return False

        # Get recent candles
        candles = []
        for i in range(lookback):
            candle_idx = idx - lookback + i + 1
            if candle_idx >= 0:
                candle = df.iloc[candle_idx]
                body_size = abs(candle['close'] - candle['open'])
                candles.append(body_size)

        if len(candles) < lookback:
            return False

        # Check if bodies are generally increasing
        increasing = sum(1 for i in range(len(candles) - 1) if candles[i+1] >= candles[i])

        return increasing >= (lookback - 1) / 2
