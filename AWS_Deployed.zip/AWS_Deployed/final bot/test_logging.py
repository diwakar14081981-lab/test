#!/usr/bin/env python3
"""
Test script to verify console and file logging
"""
import sys
import os
import time
from datetime import datetime

# Add parent directory to path
sys.path.insert(0, os.path.dirname(__file__))

print("="*70)
print("TESTING LOGGING FUNCTIONALITY")
print("="*70)
print()

try:
    # Import after modifying path
    from live_trading_bot_realtime import LiveTradingBotRealtime

    print("[1/5] Initializing bot (this sets up logging)...")

    # Create bot instance (this will set up logging)
    bot = LiveTradingBotRealtime(
        api_key="TEST_KEY",
        api_secret="TEST_SECRET",
        paper_trading=True
    )

    print("[2/5] Bot initialized successfully!")
    print()

    print("[3/5] Testing print() statements (should go to console AND log file)...")
    print("    This is a test print statement #1")
    print("    This is a test print statement #2")
    print("    Banner test: " + "="*40)
    print()

    print("[4/5] Testing logger.info() calls (should also go to console AND log file)...")
    bot.logger.info("This is a test logger.info() call #1")
    bot.logger.info("This is a test logger.info() call #2")
    bot.logger.warning("This is a test WARNING message")
    print()

    print("[5/5] Checking if log file was created...")
    logs_dir = os.path.join(os.path.dirname(__file__), 'logs')
    log_filename = f"trading_bot_{datetime.now().strftime('%Y-%m-%d')}.log"
    log_filepath = os.path.join(logs_dir, log_filename)

    time.sleep(0.5)  # Give it a moment to write to disk

    if os.path.exists(log_filepath):
        print(f"✓ Log file created: {log_filepath}")

        # Read and display last few lines
        with open(log_filepath, 'r') as f:
            lines = f.readlines()
            print(f"✓ Log file contains {len(lines)} lines")
            print()
            print("Last 10 lines from log file:")
            print("-"*70)
            for line in lines[-10:]:
                print(f"  {line.rstrip()}")
            print("-"*70)
    else:
        print(f"✗ Log file NOT found: {log_filepath}")

    print()
    print("="*70)
    print("TEST COMPLETE!")
    print("="*70)
    print()
    print("Summary:")
    print("  - All print() statements should appear above")
    print("  - All print() statements should also be in the log file")
    print("  - All logger.info() calls should appear above")
    print("  - All logger.info() calls should also be in the log file")
    print()
    print(f"Check the log file at: {log_filepath}")
    print()

except Exception as e:
    print(f"✗ Error during test: {e}")
    import traceback
    traceback.print_exc()
