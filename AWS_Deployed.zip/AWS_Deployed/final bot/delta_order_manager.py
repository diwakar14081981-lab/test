#!/usr/bin/env python3
"""
Delta Exchange Order Manager - Using Official Delta REST Client
Handles all order placement, modification, and closure for Delta Exchange
Supports both paper trading (simulation) and live trading modes
"""

import time
import logging
from datetime import datetime
from typing import Dict, Optional

try:
    from delta_rest_client import DeltaRestClient
except ImportError:
    raise ImportError("delta-rest-client not installed. Run: pip install delta-rest-client")


class DeltaOrderManager:
    """
    Order execution manager for Delta Exchange using official REST client

    Supports:
    - Market order entry (long/short)
    - Position closure (full/partial)
    - Paper trading simulation
    - Automatic lot size calculation
    """

    # Product ID mapping for Delta Exchange
    PRODUCT_IDS = {
        'BTCUSD': 27,
        'ETHUSD': 3136
    }

    # Contract specifications (lot size in base currency)
    CONTRACT_SPECS = {
        'BTCUSD': 0.001,  # 1 lot = 0.001 BTC
        'ETHUSD': 0.001   # 1 lot = 0.001 ETH
    }

    def __init__(self, api_key: str, api_secret: str, paper_trading: bool = True):
        """
        Initialize Delta Exchange Order Manager

        Args:
            api_key: Delta Exchange API key
            api_secret: Delta Exchange API secret
            paper_trading: If True, simulate orders. If False, place real orders.
        """
        self.api_key = api_key
        self.api_secret = api_secret
        self.paper_trading = paper_trading

        # Setup logging
        self.logger = logging.getLogger(__name__)
        if not self.logger.handlers:
            handler = logging.StreamHandler()
            handler.setFormatter(logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            ))
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)

        mode = "PAPER TRADING (SIMULATION)" if paper_trading else "LIVE TRADING"
        self.logger.info(f"DeltaOrderManager initialized - Mode: {mode}")

        # Initialize official Delta REST client
        if not paper_trading:
            self.client = DeltaRestClient(
                base_url='https://api.india.delta.exchange',
                api_key=api_key,
                api_secret=api_secret
            )
            self.logger.info("Official Delta REST Client initialized")

    def _calculate_lots(self, size_usd: float, current_price: float, symbol: str) -> int:
        """
        Calculate number of lots based on USD position size

        Args:
            size_usd: Position size in USD
            current_price: Current market price
            symbol: Trading symbol (e.g., 'BTCUSD')

        Returns:
            Number of lots (minimum 1)
        """
        contract_size = self.CONTRACT_SPECS.get(symbol, 0.001)

        # Calculate base currency needed
        base_currency_needed = size_usd / current_price

        # Calculate lots
        lots = base_currency_needed / contract_size

        # Round to nearest integer, minimum 1
        lots = max(1, round(lots))

        self.logger.debug(f"Lot calculation: ${size_usd} / ${current_price} / {contract_size} = {lots} lots")

        return lots

    def _get_product_id(self, symbol: str) -> int:
        """Get product ID for a symbol"""
        if symbol in self.PRODUCT_IDS:
            return self.PRODUCT_IDS[symbol]
        else:
            raise Exception(f"Unknown symbol: {symbol}. Supported: {list(self.PRODUCT_IDS.keys())}")

    def _get_current_price(self, symbol: str) -> float:
        """Get current market price for a symbol"""
        try:
            product_id = self._get_product_id(symbol)
            ticker = self.client.get_ticker(product_id)
            price = float(ticker.get('mark_price', 0))

            if price <= 0:
                raise Exception("Invalid price received from ticker")

            return price

        except Exception as e:
            self.logger.error(f"Error fetching price for {symbol}: {e}")
            raise

    def place_entry_order(self, symbol: str, side: str, size_usd: float,
                         current_price: Optional[float] = None) -> Dict:
        """
        Place market order to enter a position

        Args:
            symbol: Trading symbol (e.g., 'BTCUSD', 'ETHUSD')
            side: 'buy' or 'sell'
            size_usd: Position size in USD (notional value)
            current_price: Current market price (fetched if None)

        Returns:
            dict: {
                'order_id': str,
                'fill_price': float,
                'filled_size': float (in BTC/ETH),
                'lots': int,
                'status': str,
                'timestamp': int,
                'symbol': str,
                'side': str
            }
        """
        try:
            # Get current price if not provided
            if current_price is None:
                if self.paper_trading:
                    # For paper trading, we need a price estimate
                    raise Exception("current_price required for paper trading mode")
                current_price = self._get_current_price(symbol)

            # Calculate lots
            lots = self._calculate_lots(size_usd, current_price, symbol)
            contract_size = self.CONTRACT_SPECS.get(symbol, 0.001)
            size_base = lots * contract_size

            self.logger.info(f"{'[PAPER TRADE]' if self.paper_trading else '[LIVE ORDER]'} Entry Order:")
            self.logger.info(f"  Symbol: {symbol}")
            self.logger.info(f"  Side: {side.upper()}")
            self.logger.info(f"  Target Size: ${size_usd:.2f} USD")
            self.logger.info(f"  Lots: {lots} (= {size_base:.6f} {symbol[:3]})")
            self.logger.info(f"  Price: ${current_price:,.2f}")

            # PAPER TRADING MODE - Simulate order
            if self.paper_trading:
                # Simulate small slippage
                slippage_factor = 1.001 if side.lower() == 'buy' else 0.999
                simulated_fill_price = current_price * slippage_factor

                order_result = {
                    'order_id': f'paper_{int(time.time())}_{symbol}_{side}',
                    'fill_price': simulated_fill_price,
                    'filled_size': size_base,
                    'lots': lots,
                    'status': 'filled',
                    'timestamp': int(time.time()),
                    'symbol': symbol,
                    'side': side.lower()
                }

                self.logger.info(f"[PAPER TRADE] Order simulated successfully")
                self.logger.info(f"  Order ID: {order_result['order_id']}")
                self.logger.info(f"  Fill Price: ${order_result['fill_price']:,.2f}")
                self.logger.info(f"  Filled: {order_result['lots']} lots")

                return order_result

            # LIVE TRADING MODE - Place real order using official client
            else:
                product_id = self._get_product_id(symbol)

                # Calculate limit price for guaranteed fill
                # Buy: slightly above market, Sell: slightly below market
                if side.lower() == 'buy':
                    limit_price = int(current_price * 1.001)  # 0.1% above
                else:
                    limit_price = int(current_price * 0.999)  # 0.1% below

                self.logger.info(f"[LIVE ORDER] Placing order...")
                self.logger.info(f"  Product ID: {product_id}")
                self.logger.info(f"  Lots: {lots}")
                self.logger.info(f"  Limit Price: ${limit_price:,}")

                # Place order via official client
                order_response = self.client.place_order(
                    product_id=product_id,
                    size=lots,
                    side=side.lower(),
                    limit_price=str(limit_price)
                )

                # Extract order details
                fill_price = float(order_response.get('average_fill_price', limit_price))

                order_result = {
                    'order_id': str(order_response.get('id', '')),
                    'fill_price': fill_price,
                    'filled_size': size_base,
                    'lots': lots,
                    'status': order_response.get('state', 'unknown'),
                    'timestamp': int(time.time()),
                    'symbol': symbol,
                    'side': side.lower()
                }

                self.logger.info(f"[LIVE ORDER] Order placed successfully!")
                self.logger.info(f"  Order ID: {order_result['order_id']}")
                self.logger.info(f"  Fill Price: ${order_result['fill_price']:,.2f}")
                self.logger.info(f"  Filled: {order_result['lots']} lots")
                self.logger.info(f"  Status: {order_result['status']}")

                return order_result

        except Exception as e:
            self.logger.error(f"Error placing entry order: {e}")
            raise Exception(f"Entry order failed for {symbol}: {e}")

    def place_exit_order(self, symbol: str, side: str, size_base: float,
                        current_price: Optional[float] = None,
                        reason: str = "Manual Exit") -> Dict:
        """
        Place market order to exit (close) a position

        Args:
            symbol: Trading symbol (e.g., 'BTCUSD', 'ETHUSD')
            side: 'buy' or 'sell' (opposite of entry side)
            size_base: Position size in base currency (BTC/ETH)
            current_price: Current market price (fetched if None)
            reason: Reason for exit (for logging)

        Returns:
            dict: Same format as place_entry_order
        """
        try:
            # Get current price if not provided (SAME AS ENTRY)
            if current_price is None:
                if self.paper_trading:
                    raise Exception("current_price required for paper trading mode")
                current_price = self._get_current_price(symbol)

            # Calculate lots from base currency size
            contract_size = self.CONTRACT_SPECS.get(symbol, 0.001)
            lots = max(1, round(size_base / contract_size))

            self.logger.info(f"{'[PAPER TRADE]' if self.paper_trading else '[LIVE ORDER]'} Exit Order ({reason}):")
            self.logger.info(f"  Symbol: {symbol}")
            self.logger.info(f"  Side: {side.upper()}")
            self.logger.info(f"  Size: {size_base:.6f} {symbol[:3]} = {lots} lots")
            self.logger.info(f"  Price: ${current_price:,.2f}")

            # PAPER TRADING MODE - Simulate order
            if self.paper_trading:
                # Simulate small slippage
                slippage_factor = 1.001 if side.lower() == 'buy' else 0.999
                simulated_fill_price = current_price * slippage_factor

                order_result = {
                    'order_id': f'paper_exit_{int(time.time())}_{symbol}_{side}',
                    'fill_price': simulated_fill_price,
                    'filled_size': size_base,
                    'lots': lots,
                    'status': 'filled',
                    'timestamp': int(time.time()),
                    'symbol': symbol,
                    'side': side.lower()
                }

                self.logger.info(f"[PAPER TRADE] Exit order simulated successfully")
                self.logger.info(f"  Order ID: {order_result['order_id']}")
                self.logger.info(f"  Fill Price: ${order_result['fill_price']:,.2f}")

                return order_result

            # LIVE TRADING MODE - Place real order
            else:
                product_id = self._get_product_id(symbol)

                # Calculate limit price for guaranteed fill
                if side.lower() == 'buy':
                    limit_price = int(current_price * 1.001)
                else:
                    limit_price = int(current_price * 0.999)

                self.logger.info(f"[LIVE ORDER] Placing exit order...")

                # Place order via official client
                order_response = self.client.place_order(
                    product_id=product_id,
                    size=lots,
                    side=side.lower(),
                    limit_price=str(limit_price)
                )

                # Extract order details
                fill_price = float(order_response.get('average_fill_price', limit_price))

                order_result = {
                    'order_id': str(order_response.get('id', '')),
                    'fill_price': fill_price,
                    'filled_size': size_base,
                    'lots': lots,
                    'status': order_response.get('state', 'unknown'),
                    'timestamp': int(time.time()),
                    'symbol': symbol,
                    'side': side.lower()
                }

                self.logger.info(f"[LIVE ORDER] Exit order placed successfully!")
                self.logger.info(f"  Order ID: {order_result['order_id']}")
                self.logger.info(f"  Fill Price: ${order_result['fill_price']:,.2f}")
                self.logger.info(f"  Status: {order_result['status']}")

                return order_result

        except Exception as e:
            self.logger.error(f"Error placing exit order: {e}")
            raise Exception(f"Exit order failed for {symbol}: {e}")

    def place_partial_exit(self, symbol: str, side: str, size_base: float,
                          percentage: int) -> Dict:
        """
        Place market order to partially close a position

        Args:
            symbol: Trading symbol
            side: 'buy' or 'sell' (opposite of entry side)
            size_base: Partial position size to close (in BTC/ETH)
            percentage: Percentage of position being closed (for logging)

        Returns:
            dict: Same format as place_entry_order
        """
        reason = f"Partial Exit ({percentage}%)"
        self.logger.info(f"Executing partial profit taking: {percentage}% of position")

        return self.place_exit_order(symbol, side, size_base, reason)


# Example usage and testing
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)

    print("="*70)
    print("Delta Order Manager - Using Official Delta REST Client")
    print("="*70)
    print("\nNOTE: This requires valid API credentials")
    print("Replace API_KEY and API_SECRET with your Delta Exchange credentials\n")

    # Example initialization
    API_KEY = "your_api_key_here"
    API_SECRET = "your_api_secret_here"

    # Paper trading example
    print("\n--- Paper Trading Example ---")
    manager = DeltaOrderManager(
        api_key=API_KEY,
        api_secret=API_SECRET,
        paper_trading=True
    )

    # Test entry order (paper trading)
    try:
        result = manager.place_entry_order(
            symbol='BTCUSD',
            side='buy',
            size_usd=10000.0,
            current_price=100000.0
        )
        print(f"\nPaper trade result: {result}")
    except Exception as e:
        print(f"Error: {e}")

    print("\n" + "="*70)
    print("Example completed!")
    print("="*70)
