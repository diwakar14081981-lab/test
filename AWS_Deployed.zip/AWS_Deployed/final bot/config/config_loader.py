"""
Strategy Configuration Loader
Easily switch between different trading strategies
"""

from .scalping_config import ScalpingConfig
from .swing_supertrend_config import SwingSupertrendConfig

# =============================================================================
# ACTIVE STRATEGY SELECTION
# =============================================================================

# Change this to switch strategies:
# - 'MARUBOZU' = Original Marubozu breakout strategy
# - 'SWING_SUPERTREND' = New swing supertrend strategy (recommended for ETH)

ACTIVE_STRATEGY = 'SWING_SUPERTREND'  # <-- CHANGE THIS TO SWITCH STRATEGIES

# =============================================================================
# Config Loader Function
# =============================================================================

def load_config():
    """
    Load the active strategy configuration

    Returns:
        Config class instance for the selected strategy
    """
    if ACTIVE_STRATEGY == 'MARUBOZU':
        print("="*70)
        print("Loading MARUBOZU BREAKOUT STRATEGY Configuration...")
        print("="*70)
        return ScalpingConfig()
    elif ACTIVE_STRATEGY == 'SWING_SUPERTREND':
        print("="*70)
        print("Loading SWING SUPERTREND STRATEGY Configuration...")
        print("="*70)
        return SwingSupertrendConfig()
    else:
        raise ValueError(f"Unknown strategy: {ACTIVE_STRATEGY}. Must be 'MARUBOZU' or 'SWING_SUPERTREND'")


def get_active_strategy_name():
    """Get the name of the currently active strategy"""
    return ACTIVE_STRATEGY


# =============================================================================
# Strategy Information
# =============================================================================

STRATEGY_INFO = {
    'MARUBOZU': {
        'name': 'Marubozu Breakout Strategy',
        'description': 'Original strategy with ADX, Volume, 30m+1h SuperTrend filters',
        'asset': 'BTCUSD',
        'best_for': 'BTC in trending markets',
        'timeframes': '5-min entry, 30-min + 1-hour trend confirmation',
        'entry_filters': 'Marubozu 60% + ADX >=25 + Volume 1.5x + Both SuperTrends',
        'exit': 'Fixed TP (300 pips) / SL (50 pips) with ATR trailing',
        'tested_period': '3 months (Aug-Oct 2025)',
        'tested_performance': '39 trades, 64% WR, PF 1.64, +5.85% return',
        'features': [
            '[+] 2-candle confirmation with momentum buildup',
            '[+] Breakout entry during 2nd candle',
            '[+] ADX momentum filter (5% increase required)',
            '[+] Volume sustained check',
            '[+] Partial profits (optional)',
            '[+] ATR-based trailing stop'
        ]
    },
    'SWING_SUPERTREND': {
        'name': 'Swing SuperTrend Strategy',
        'description': '288 EMA + 1H SuperTrend + Swing Point Trailing',
        'asset': 'ETHUSD (recommended) or BTCUSD',
        'best_for': 'ETH in trending markets (especially bearish)',
        'timeframes': '5-min entry, 1-hour SuperTrend confirmation',
        'entry_filters': 'Marubozu 60% + 288 EMA + 1H SuperTrend + Swing Break',
        'exit': 'Swing point trailing (dynamic, no fixed TP)',
        'tested_period': '7 months (Apr-Oct 2025)',
        'tested_performance_eth': 'ETH: 130 trades, 62% WR, PF 6.88, +410% return ***',
        'tested_performance_btc': 'BTC: 138 trades, 56% WR, PF 1.53, +105% return',
        'features': [
            '[+] 4-candle swing identification with 3-candle confirmation',
            '[+] Immediate entry (no 2nd candle wait)',
            '[+] NO ADX filter (simplicity)',
            '[+] NO volume filter (simplicity)',
            '[+] NO fixed take profit (let winners run)',
            '[+] Dynamic swing trailing (locks profits)',
            '[+] 4x more profitable than BTC strategy on ETH'
        ]
    }
}


def print_strategy_info():
    """Print detailed information about the active strategy"""
    info = STRATEGY_INFO.get(ACTIVE_STRATEGY)
    if info:
        print("")
        print("="*70)
        print(f"ACTIVE STRATEGY: {info['name']}")
        print("="*70)
        print(f"Description:     {info['description']}")
        print(f"Best For:        {info['best_for']}")
        print(f"Asset:           {info['asset']}")
        print(f"Timeframes:      {info['timeframes']}")
        print(f"Entry Filters:   {info['entry_filters']}")
        print(f"Exit Method:     {info['exit']}")
        print("-"*70)
        print(f"Tested Period:   {info['tested_period']}")

        if ACTIVE_STRATEGY == 'SWING_SUPERTREND':
            print(f"Performance:")
            print(f"  {info['tested_performance_eth']}")
            print(f"  {info['tested_performance_btc']}")
        else:
            print(f"Performance:     {info['tested_performance']}")

        print("-"*70)
        print("Features:")
        for feature in info['features']:
            print(f"  {feature}")
        print("="*70)
        print("")
    else:
        print(f"No information available for strategy: {ACTIVE_STRATEGY}")


def validate_config(config):
    """
    Validate that the loaded config has all required attributes

    Args:
        config: Config class instance

    Raises:
        AttributeError: If required attributes are missing
    """
    required_attrs = [
        'TRADING_SYMBOL',
        'EXCHANGE',
        'ENTRY_TIMEFRAME',
        'POSITION_SIZE_DOLLARS',
        'LEVERAGE'
    ]

    missing_attrs = []
    for attr in required_attrs:
        if not hasattr(config, attr):
            missing_attrs.append(attr)

    if missing_attrs:
        raise AttributeError(
            f"Config missing required attributes: {', '.join(missing_attrs)}"
        )

    print(f"[OK] Config validation passed")
    print(f"  Trading Symbol: {config.TRADING_SYMBOL}")
    print(f"  Exchange: {config.EXCHANGE}")
    print(f"  Entry Timeframe: {config.ENTRY_TIMEFRAME}")
    print(f"  Position Size: ${config.POSITION_SIZE_DOLLARS:,.0f}")
    print(f"  Leverage: {config.LEVERAGE}x")
    print("")


# =============================================================================
# Strategy Comparison Helper
# =============================================================================

def compare_strategies():
    """Print a comparison table of all available strategies"""
    print("")
    print("="*70)
    print("STRATEGY COMPARISON")
    print("="*70)
    print("")
    print(f"{'Aspect':<20} | {'MARUBOZU':<25} | {'SWING_SUPERTREND':<25}")
    print("-"*70)

    comparisons = [
        ("Asset", "BTCUSD", "ETHUSD (recommended)"),
        ("Entry Timeframe", "5-min", "5-min"),
        ("Trend Filter 1", "30-min SuperTrend", "288 EMA (24-hour)"),
        ("Trend Filter 2", "1-hour SuperTrend", "1-hour SuperTrend"),
        ("ADX Filter", "Yes (>=25 + 5% inc)", "No"),
        ("Volume Filter", "Yes (1.5x + sustained)", "No"),
        ("Entry Method", "Breakout (2nd candle)", "Immediate"),
        ("Exit Method", "Fixed TP/SL + Trail", "Swing Trailing"),
        ("Take Profit", "300 pips (3%)", "None (dynamic)"),
        ("Stop Loss", "50 pips (0.5%)", "Swing-based + 10 pips"),
        ("Partial Profits", "Optional", "No"),
        ("", "", ""),
        ("Tested Period", "3 months", "7 months"),
        ("Total Trades", "39 trades", "130 (ETH) / 138 (BTC)"),
        ("Win Rate", "64%", "62% (ETH) / 56% (BTC)"),
        ("Profit Factor", "1.64", "6.88 (ETH) / 1.53 (BTC)"),
        ("Total Return", "+5.85%", "+410% (ETH) / +105% (BTC)"),
        ("", "", ""),
        ("Complexity", "High (7 filters)", "Low (3 filters)"),
        ("Best Market", "Trending", "Trending (esp. bearish)"),
        ("Recommendation", "BTC Conservative", "ETH Aggressive ***"),
    ]

    for row in comparisons:
        if len(row) == 3:
            print(f"{row[0]:<20} | {row[1]:<25} | {row[2]:<25}")
        else:
            print(f"{row[0]:<20} | {'':<25} | {'':<25}")

    print("="*70)
    print("")
    print("RECOMMENDATION:")
    print("  - Use SWING_SUPERTREND for Ethereum (4x more profitable)")
    print("  - Use MARUBOZU for Bitcoin (more conservative)")
    print("  - Start with paper trading to validate performance")
    print("")
    print("="*70)
    print("")


# =============================================================================
# Quick Switch Helper
# =============================================================================

def switch_to_marubozu():
    """Quick helper to switch to Marubozu strategy (for documentation)"""
    print("To switch to MARUBOZU strategy:")
    print("  1. Open config_loader.py")
    print("  2. Change ACTIVE_STRATEGY = 'SWING_SUPERTREND'")
    print("     to     ACTIVE_STRATEGY = 'MARUBOZU'")
    print("  3. Restart the bot")
    print("")


def switch_to_swing_supertrend():
    """Quick helper to switch to Swing SuperTrend strategy (for documentation)"""
    print("To switch to SWING_SUPERTREND strategy:")
    print("  1. Open config_loader.py")
    print("  2. Change ACTIVE_STRATEGY = 'MARUBOZU'")
    print("     to     ACTIVE_STRATEGY = 'SWING_SUPERTREND'")
    print("  3. Restart the bot")
    print("")


# =============================================================================
# Main Entry Point (for testing)
# =============================================================================

if __name__ == "__main__":
    """Test the config loader"""
    print("\n" + "="*70)
    print("CONFIG LOADER TEST")
    print("="*70 + "\n")

    # Load and validate config
    try:
        config = load_config()
        print_strategy_info()
        validate_config(config)

        print("\n[OK] Config loaded successfully!")
        print(f"  Strategy: {ACTIVE_STRATEGY}")
        print(f"  Symbol: {config.TRADING_SYMBOL}")

        # Print strategy comparison
        print("\n")
        compare_strategies()

    except Exception as e:
        print(f"\n[ERROR] Error loading config: {e}")
        import traceback
        traceback.print_exc()
