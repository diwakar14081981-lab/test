# Config Folder

This folder contains all trading strategy configurations.

## Files:

### `config_loader.py`
- Main configuration loader
- Switch between strategies by changing `ACTIVE_STRATEGY` variable
- Options: `'MARUBOZU'` or `'SWING_SUPERTREND'`

### `scalping_config.py`
- Original Marubozu Breakout Strategy configuration
- 7 filters: Marubozu + 30m/1h SuperTrend + ADX + Volume
- Fixed TP/SL with ATR trailing stop
- Tested on BTCUSD: 64% WR, PF 1.64, +5.85% return

### `swing_supertrend_config.py`
- New Swing SuperTrend Strategy configuration
- 3 filters: Marubozu + 288 EMA + 1H SuperTrend
- Swing-based trailing stop (no fixed TP)
- Tested on ETHUSD: 62% WR, PF 6.88, +410% return

## How to Switch Strategies:

1. Open `config_loader.py`
2. Change line 17:
   ```python
   ACTIVE_STRATEGY = 'SWING_SUPERTREND'  # or 'MARUBOZU'
   ```
3. Restart the bot

## How to Modify Settings:

- For Marubozu strategy: Edit `scalping_config.py`
- For Swing SuperTrend strategy: Edit `swing_supertrend_config.py`
