# =============================================================================
# BTC PERPETUAL FUTURES SCALPING STRATEGY CONFIGURATION
# =============================================================================

class ScalpingConfig:
    """
    Configuration for Crypto Perpetual Futures Scalping Strategy

    STRATEGY OVERVIEW (OPTIMIZED VERSION):
    - Entry Timeframe: 5-minute candles
    - Trend Confirmation: Both 30-minute AND 1-hour SuperTrend
    - Volume Filter: 1.5× average volume with momentum sustained
    - ADX Filter: ≥25 with momentum building (+5%)
    - Marubozu: 60% body percentage
    - Take Profit: 300 pips (3.0%)
    - Stop Loss: 50 pips (0.5%)
    - Trailing Stop: 2.0× ATR (activates at 75 pips)
    - Partial Profits: DISABLED (let winners run)
    """

    # =============================================================================
    # TRADING ASSET CONFIGURATION
    # =============================================================================

    TRADING_SYMBOL = 'SOLUSD'             # Trading pair symbol
                                          # Options: 'BTCUSDT', 'ETHUSDT', 'SOLUSDT', etc.
                                          # For Delta Exchange: 'BTCUSD', 'ETHUSD'

    EXCHANGE = 'DELTA'                    # Exchange name (for logging only)
                                          # Options: 'BINANCE', 'DELTA', 'BYBIT', etc.

    # =============================================================================
    # TIMEFRAME SETTINGS
    # =============================================================================

    ENTRY_TIMEFRAME = '5min'          # Primary timeframe for entry signals
                                      # Options: '1min', '3min', '5min', '15min'

    TREND_TIMEFRAME_1 = '30min'       # First higher timeframe for trend confirmation
                                      # Options: '15min', '30min', '1h'

    TREND_TIMEFRAME_2 = '1h'          # Second higher timeframe for trend confirmation
                                      # Options: '30min', '1h', '4h'

    USE_TREND_CONFIRMATION = True     # Enable trend confirmation filter?
                                      # True = Use higher timeframes for confirmation
                                      # False = No trend filter (only entry timeframe)

    TREND_CONFIRMATION_MODE = 'both'  # Which timeframe(s) to use for trend confirmation
                                      # Options:
                                      # '30min' = Only 30-min SuperTrend must confirm
                                      # '1h' = Only 1-hour SuperTrend must confirm
                                      # 'both' = Both 30-min AND 1-hour must agree
                                      # 'either' = Either 30-min OR 1-hour confirms

    # =============================================================================
    # SUPERTREND INDICATOR SETTINGS
    # =============================================================================

    # SuperTrend for 30-minute timeframe
    SUPERTREND_30M_PERIOD = 10        # ATR period for SuperTrend calculation
    SUPERTREND_30M_MULTIPLIER = 3.0   # ATR multiplier for SuperTrend bands
                                      # Higher = wider bands, less sensitive
                                      # Try: 2.0, 3.0, 4.0, 5.0

    # SuperTrend for 1-hour timeframe
    SUPERTREND_1H_PERIOD = 10         # ATR period for SuperTrend calculation
    SUPERTREND_1H_MULTIPLIER = 3.0    # ATR multiplier for SuperTrend bands
                                      # Higher = wider bands, less sensitive
                                      # Try: 2.0, 3.0, 4.0, 5.0


    # =============================================================================
    # ADX FILTER (Trend Strength + Momentum Buildup)
    # =============================================================================

    USE_ADX_FILTER = True              # Require strong trend on entry timeframe?
    ADX_THRESHOLD = 25                # Min ADX for entry
                                      # 25 = moderate trend
                                      # 30 = strong trend
                                      # Try: 20, 25, 30, 35
    ADX_PERIOD = 14                   # Period for ADX calculation

    CHECK_ADX_MOMENTUM = True         # Require ADX to be building (not fading)?
    ADX_MOMENTUM_INCREASE_PCT = 5     # Required ADX increase from 1st to 2nd candle (%)
                                      # 5 = ADX must increase by at least 5%
                                      # Try: 3, 5, 10

    # =============================================================================
    # VOLUME FILTER (Institutional Participation)
    # =============================================================================

    USE_VOLUME_FILTER = True          # Require volume spike on entry?
    VOLUME_THRESHOLD = 1.5            # Min volume ratio (vs MA)
                                      # 1.5 = Volume must be 1.5× 20-period average
                                      # Try: 1.2, 1.5, 2.0
    VOLUME_MA_PERIOD = 20             # Period for volume moving average
    VOLUME_INCREASING_REQUIRED = True # Require 2nd candle volume ≥ 1st candle?
                                      # True = Sustained volume required
                                      # False = Only check 1st candle


    # =============================================================================
    # ENTRY REQUIREMENTS
    # =============================================================================

    DIRECTION_CANDLES = 2             # Number of consecutive candles same direction
                                      # on entry timeframe (5-min)
                                      # Try: 2, 3, 4, 5

    # =============================================================================
    # BREAKOUT ENTRY LOGIC (Marubozu + Breakout Strategy)
    # =============================================================================

    # First Candle Requirements (Marubozu-like candle)
    FIRST_CANDLE_MIN_BODY_PERCENTAGE = 60  # Min body % for first candle
                                           # 60 = Moderate marubozu-like candle
                                           # Try: 60, 70, 75, 80, 85

    # Breakout Entry Settings
    USE_BREAKOUT_ENTRY = True              # Enter on breakout during 2nd candle?
                                           # True = tick-by-tick breakout entry
                                           # False = wait for 2nd candle close

    # =============================================================================
    # EXIT SETTINGS (Take Profit & Stop Loss)
    # =============================================================================

    TAKE_PROFIT_PIPS = 300            # Take profit in pips (0.01%)
                                      # 300 pips = 3.0% move
                                      # For $100k BTC = $3,000 move
                                      # Try: 200, 250, 300, 350

    STOP_LOSS_PIPS = 50               # Initial stop loss in pips (0.01%)
                                      # 75 pips = 0.75% move
                                      # For $100k BTC = $750 move
                                      # Try: 50, 75, 100, 150

    # =============================================================================
    # ADVANCED TRAILING STOP CONFIGURATION
    # =============================================================================

    USE_TRAILING_STOP = True          # Enable trailing stop?

    TRAILING_ACTIVATION_PIPS = 75     # Start trailing after X pips profit
                                      # 0 = trail immediately
                                      # Try: 0, 50, 75, 100

    # ATR-Based Trailing Stop Settings
    TRAILING_ATR_MULTIPLIER = 2.0     # Trail by X * ATR
                                      # 2.0 = trail 2.0 ATRs behind price
                                      # Try: 1.5, 2.0, 2.5, 3.0

    # Partial Profit Taking (DISABLED for optimized strategy)
    USE_PARTIAL_PROFITS = False       # Take partial profits at milestones?
    PARTIAL_PROFIT_LEVELS = []        # List of (pips, percentage_to_close)
                                      # DISABLED - Let winners run with trailing stop
                                      # Testing showed partials reduce overall profit


    # =============================================================================
    # POSITION SIZING
    # =============================================================================

    POSITION_SIZE_DOLLARS = 10       # Dollar amount per trade (REDUCED FOR TESTING)
                                      # This is the notional value of the futures contract
                                      # Try: 1000, 5000, 10000, 20000

    LEVERAGE = 1                      # Leverage for perpetual futures
                                      # 5x = $10k position needs $2k margin
                                      # WARNING: Higher leverage = higher risk
                                      # Try: 1, 3, 5, 10
                                      # Recommended: 3-5x for scalping

    # =============================================================================
    # RISK MANAGEMENT
    # =============================================================================

    MAX_DAILY_LOSS = 500              # Max loss per day (in dollars)
                                      # Stop trading after hitting this
                                      # 0 = disabled

    MAX_DAILY_TRADES = 10             # Max trades per day
                                      # Prevent overtrading
                                      # 0 = unlimited

    MAX_CONCURRENT_TRADES = 1         # Max open positions at once
                                      # 1 = one trade at a time (recommended)

    # =============================================================================
    # BACKTESTING SETTINGS
    # =============================================================================

    COMMISSION_RATE = 0.0005          # 0.05% per trade (maker/taker avg)
                                      # Delta Exchange: 0.05% maker, 0.05% taker
                                      # Try: 0.0002 (maker) to 0.0006 (aggressive)

    SLIPPAGE_PIPS = 5                 # Assume 5 pips slippage per trade
                                      # More realistic backtesting
                                      # Try: 0, 3, 5, 10
