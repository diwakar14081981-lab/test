"""
Live Trading Credentials for Delta Exchange
IMPORTANT: Keep this file secure and never commit to version control

Instructions:
1. Replace the placeholder values below with your actual Delta Exchange API credentials
2. Ensure this file is listed in .gitignore
3. Keep your API secret secure - never share it
"""

# Delta Exchange API Credentials
# Get these from: https://www.delta.exchange/app/account/api-keys
LIVE_API_KEY = ""
LIVE_API_SECRET = "vC4PxTdhh2dq6QiU203wKJJCGcPimatTnFc9Gp2oNuiZ0km9ueQa5Dgr3w0d"

# Optional: Testnet credentials (if using testnet)
TESTNET_API_KEY = "testnet_key_here"
TESTNET_API_SECRET = "testnet_secret_here"

# Safety reminder
print("WARNING: LIVE TRADING CREDENTIALS LOADED")
print("WARNING: Make sure you understand the risks before enabling live trading!")
