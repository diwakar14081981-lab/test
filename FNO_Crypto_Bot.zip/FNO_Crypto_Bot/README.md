# Live Trading Bot - Production Deployment

## Strategy: Swing SuperTrend (Ethereum)

**Performance (August 2025 Backtest):**
- Return: +41.84%
- Profit Factor: 2.18
- Win Rate: 41.75%
- Trades: 103
- Asset: ETHUSD (Ethereum Perpetual Futures)

---

## Files Included

### Core Trading Files
- `live_trading_bot_realtime.py` - Main trading bot orchestrator
- `swing_supertrend_strategy.py` - Swing SuperTrend strategy logic
- `delta_exchange_client.py` - Delta Exchange API wrapper
- `delta_order_manager.py` - Order execution manager
- `btc_futures_scalping.py` - Technical indicator calculations
- `run_bot.py` - Simple launcher script

### Configuration
- `config/` - Strategy configuration folder
  - `config_loader.py` - Config loader (ACTIVE_STRATEGY = 'SWING_SUPERTREND')
  - `swing_supertrend_config.py` - Strategy parameters
  - `scalping_config.py` - Alternative strategy (not used)

### Credentials
- `live_trading_credentials.py` - API credentials (UPDATE BEFORE DEPLOYING)

---

## Strategy Configuration (Updated)

**Entry Filters:**
- 288 EMA trend filter (24-hour trend)
- 1-hour SuperTrend alignment
- Swing point breakout
- NO Marubozu requirement (removed for better performance)

**Exit Method:**
- Dynamic swing trailing stops
- 0.15% buffer (15 pips)
- 1.5% maximum risk cap per trade

**Position Sizing:**
- $10,000 per trade (configurable)
- 1x leverage (no leverage, safest)
- Max 1 concurrent position

---

## AWS Deployment Instructions

### 1. Prerequisites
- AWS EC2 instance (Ubuntu 20.04 or later recommended)
- Python 3.8 or higher
- Delta Exchange account with API access

### 2. Upload Files
```bash
# Copy entire folder to AWS EC2
scp -r "final bot" ubuntu@<your-ec2-ip>:~/trading-bot/
```

### 3. Install Dependencies
```bash
cd ~/trading-bot/final\ bot/
python3 -m pip install -r requirements.txt
```

### 4. Configure API Credentials

**CRITICAL: Update `live_trading_credentials.py`**
```python
# Replace with your actual Delta Exchange API credentials
LIVE_API_KEY = "your_actual_api_key_here"
LIVE_API_SECRET = "your_actual_api_secret_here"
```

**To get API credentials:**
1. Log in to Delta Exchange India (https://app.india.delta.exchange)
2. Go to Settings → API Keys
3. Create new API key with trading permissions
4. Copy API Key and Secret

### 5. Test in Paper Trading Mode

**ALWAYS test first with paper trading:**
```bash
python3 run_bot.py
```

The bot will start in **PAPER TRADING** mode by default (no real money).

**Check logs:**
- Look for: `[PAPER TRADING MODE]` in logs
- Verify strategy loads: `Loading SWING SUPERTREND STRATEGY Configuration...`
- Confirm asset: `Trading Symbol: ETHUSD`

### 6. Enable Live Trading (Only After Testing)

**Edit `run_bot.py` to enable live trading:**
```python
# Change this line:
bot = LiveTradingBotRealtime(paper_trading=False)  # Live mode
```

**⚠️ WARNING:** Only enable live trading after:
1. Verifying paper trading works correctly
2. Confirming 20+ successful paper trades
3. Understanding the risk and having appropriate capital

---

## Running the Bot

### Option 1: Foreground (for testing)
```bash
python3 run_bot.py
```
Press `Ctrl+C` to stop gracefully.

### Option 2: Background (for production)
```bash
nohup python3 run_bot.py > bot.log 2>&1 &
```

**Monitor logs:**
```bash
tail -f bot.log
```

**Stop bot:**
```bash
pkill -f run_bot.py
```

### Option 3: Using screen (recommended)
```bash
screen -S trading-bot
python3 run_bot.py
# Press Ctrl+A then D to detach
```

**Reattach:**
```bash
screen -r trading-bot
```

---

## Monitoring

### Trade Logs
Bot creates CSV files in `trades/` folder:
- Format: `live_trades_YYYYMMDD_HHMMSS.csv`
- Contains: Entry/exit times, prices, P&L, reasons

### Key Metrics to Monitor
- Entry frequency: ~3-5 trades per week (normal)
- Win rate: Should be around 40-45%
- Average wins: ~$180
- Average losses: ~$60
- Profit factor: Should stay above 2.0

---

## Configuration Files

### Change Strategy
Edit `config/config_loader.py`:
```python
ACTIVE_STRATEGY = 'SWING_SUPERTREND'  # Current
# ACTIVE_STRATEGY = 'MARUBOZU'  # Alternative
```

### Adjust Position Size
Edit `config/swing_supertrend_config.py`:
```python
POSITION_SIZE_DOLLARS = 10000  # Change this
LEVERAGE = 1                   # 1x = safest
```

### Risk Limits
```python
MAX_DAILY_LOSS = 500      # Stop if daily loss exceeds this
MAX_DAILY_TRADES = 10     # Maximum trades per day
MAX_CONCURRENT_TRADES = 1 # Maximum open positions
```

---

## Safety Features

✅ **Graceful Shutdown** - Press Ctrl+C to exit safely
✅ **Risk Caps** - 1.5% max risk per trade
✅ **Daily Limits** - Max loss and trade limits
✅ **Paper Trading** - Test without real money
✅ **CSV Logging** - All trades recorded
✅ **Swing Trailing** - Dynamic risk management

---

## Troubleshooting

### Bot won't start
```bash
# Check Python version (need 3.8+)
python3 --version

# Reinstall dependencies
python3 -m pip install --upgrade -r requirements.txt
```

### API Connection errors
- Verify API credentials in `live_trading_credentials.py`
- Check Delta Exchange is accessible
- Ensure API key has trading permissions

### No trades executing
- Check if in paper trading mode (expected)
- Verify strategy is loaded (check logs)
- Confirm market conditions meet entry filters
- Normal: 3-5 trades per week (strategy is selective)

### Import errors
```bash
# Ensure all files are in same directory
ls -la
# Should see all .py files and config/ folder
```

---

## Support

**Strategy Configuration:** `config/swing_supertrend_config.py`
**Main Bot Code:** `live_trading_bot_realtime.py`
**Strategy Logic:** `swing_supertrend_strategy.py`

---

## Disclaimer

⚠️ **RISK WARNING:**
- Trading crypto futures involves substantial risk
- Past performance does not guarantee future results
- Only trade with capital you can afford to lose
- Start with paper trading and small position sizes
- Monitor the bot regularly
- This bot is provided as-is with no guarantees

**Backtest results (August 2025: +41.84%) are historical and may not reflect future performance.**

---

## Quick Start Checklist

- [ ] Upload folder to AWS EC2
- [ ] Install Python 3.8+
- [ ] Install dependencies: `pip install -r requirements.txt`
- [ ] Update `live_trading_credentials.py` with real API keys
- [ ] Test in paper trading mode
- [ ] Verify 20+ successful paper trades
- [ ] Review strategy config in `config/swing_supertrend_config.py`
- [ ] (Optional) Switch to live trading in `run_bot.py`
- [ ] Run bot: `python3 run_bot.py`
- [ ] Monitor logs and trades

---

**Current Configuration:**
- Asset: ETHUSD (Ethereum)
- Strategy: Swing SuperTrend
- Marubozu Filter: Disabled (for better performance)
- Buffer: 0.15% (15 pips)
- Max Risk: 1.5% per trade
- Position Size: $10,000
- Leverage: 1x

**Ready to deploy!** 🚀
