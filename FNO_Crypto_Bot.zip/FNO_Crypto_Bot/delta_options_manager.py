#!/usr/bin/env python3
"""
Delta Exchange Options Manager
Handles options order placement for selling ATM weekly options
Same interface as DeltaOrderManager but executes via options instead of futures
"""

import time
import logging
from datetime import datetime, timedelta
from typing import Dict, Optional, List

try:
    from delta_rest_client import DeltaRestClient, OrderType
except ImportError:
    raise ImportError("delta-rest-client not installed. Run: pip install delta-rest-client")


class DeltaOptionsManager:
    """
    Options execution manager for Delta Exchange

    Sells ATM next-day options based on strategy signals:
    - LONG signal → Sell ATM PUT (expiry: current date + 1 day)
    - SHORT signal → Sell ATM CALL (expiry: current date + 1 day)
    - EXIT signal → Buy back option
    """

    # Contract specifications (lot size in base currency)
    CONTRACT_SPECS = {
        'BTCUSD': 0.001,  # 1 lot = 0.001 BTC (1000 lots = 1 BTC)
        'ETHUSD': 0.01,   # 1 lot = 0.01 ETH (100 lots = 1 ETH)
        'SOLUSD': 1       # 1 lot = 1 SOL
    }

    # Option price divisor (Delta Exchange option price convention)
    # Option prices are quoted per X lots
    OPTION_PRICE_DIVISOR = {
        'BTCUSD': 1000,  # BTC option price is per 1000 lots
        'ETHUSD': 100,   # ETH option price is per 100 lots
        'SOLUSD': 1      # SOL option price is per 1 lot
    }

    # Strike intervals
    # NOTE: Delta Exchange strike intervals vary by asset
    STRIKE_INTERVALS = {
        'BTCUSD': 200,   # BTC strikes in $200 increments (e.g., 91000, 91200, 91400)
        'ETHUSD': 20,    # ETH strikes in $20 increments (e.g., 3980, 4000, 4020)
        'SOLUSD': 5      # SOL strikes in $5 increments
    }

    def __init__(self, api_key: str, api_secret: str, paper_trading: bool = True):
        """
        Initialize Delta Exchange Options Manager

        Args:
            api_key: Delta Exchange API key
            api_secret: Delta Exchange API secret
            paper_trading: If True, simulate orders. If False, place real orders.
        """
        self.api_key = api_key
        self.api_secret = api_secret
        self.paper_trading = paper_trading

        # Track current option position
        self.current_position = None

        # Setup logging
        self.logger = logging.getLogger(__name__)
        if not self.logger.handlers:
            handler = logging.StreamHandler()
            handler.setFormatter(logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            ))
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)

        mode = "PAPER TRADING (SIMULATION)" if paper_trading else "LIVE TRADING"
        self.logger.info(f"DeltaOptionsManager initialized - Mode: {mode}")

        # Initialize official Delta REST client
        # Even in paper trading, we need client to fetch real market prices
        # Note: Delta Exchange has a single global API endpoint
        self.client = DeltaRestClient(
            base_url='https://api.delta.exchange',
            api_key=api_key,
            api_secret=api_secret
        )
        self.logger.info(f"Official Delta REST Client initialized for OPTIONS ({'Read-only' if paper_trading else 'Full trading'})")

    def _calculate_lots(self, size_usd: float, current_price: float, symbol: str) -> int:
        """
        Calculate number of lots based on USD position size
        Same calculation as futures

        Args:
            size_usd: Position size in USD
            current_price: Current market price
            symbol: Trading symbol (e.g., 'BTCUSD')

        Returns:
            Number of lots (minimum 1)
        """
        contract_size = self.CONTRACT_SPECS.get(symbol, 0.001)

        # Calculate base currency needed
        base_currency_needed = size_usd / current_price

        # Calculate lots
        lots = base_currency_needed / contract_size

        # Round to nearest integer, minimum 1
        lots = max(1, round(lots))

        self.logger.info(f"Position size calculation: ${size_usd} @ ${current_price} = {lots} lots")

        return lots

    def _find_atm_strike(self, spot_price: float, symbol: str) -> int:
        """
        Find ATM (At The Money) strike price

        Args:
            spot_price: Current spot price
            symbol: Trading symbol

        Returns:
            ATM strike price
        """
        interval = self.STRIKE_INTERVALS.get(symbol, 500)
        atm_strike = round(spot_price / interval) * interval

        self.logger.info(f"ATM strike for {symbol} @ ${spot_price}: ${atm_strike}")

        return atm_strike

    def _get_next_day_expiry(self) -> datetime:
        """
        Get optimal expiry date based on current time to maximize decay

        Logic:
        - 12:01 AM to 3:00 PM IST: Use CURRENT DATE (maximize decay on expiry day)
        - After 3:00 PM IST: Use NEXT DAY (avoid selling too close to expiry)

        Returns:
            Expiry datetime in IST
        """
        now_utc = datetime.utcnow()
        now_ist = now_utc + timedelta(hours=5, minutes=30)

        # Determine expiry date based on current time
        current_hour = now_ist.hour
        current_minute = now_ist.minute

        # If time is between 12:01 AM and 3:00 PM (15:00), use current date
        # Otherwise use next day
        if current_hour < 15:  # Before 3:00 PM
            expiry_date = now_ist.date()  # Current date
            self.logger.info(f"Time is {now_ist.strftime('%H:%M')} IST (before 3 PM) - Using CURRENT DATE expiry for maximum decay")
        else:  # 3:00 PM or later
            expiry_date = now_ist.date() + timedelta(days=1)  # Next day
            self.logger.info(f"Time is {now_ist.strftime('%H:%M')} IST (after 3 PM) - Using NEXT DAY expiry to avoid late expiry risk")

        # Set expiry time to 5:30 PM IST
        expiry_datetime = datetime.combine(
            expiry_date,
            datetime.strptime('17:30', '%H:%M').time()
        )

        self.logger.info(f"Selected expiry: {expiry_datetime.strftime('%Y-%m-%d %H:%M')} IST")

        return expiry_datetime

    def _get_btc_options(self, symbol: str = 'BTCUSD') -> List[dict]:
        """
        Fetch available options from Delta Exchange for a given symbol
        ALWAYS fetches REAL data from API, even in paper trading mode
        Retries up to 3 times on failure

        Args:
            symbol: Trading symbol (e.g., 'BTCUSD', 'ETHUSD')

        Returns:
            List of option products
        """
        max_retries = 3
        retry_delay = 1  # seconds

        # Extract base asset from symbol (e.g., 'BTCUSD' -> 'BTC', 'ETHUSD' -> 'ETH')
        base_asset = symbol.replace('USD', '')

        for attempt in range(max_retries):
            try:
                # Use request() method to fetch products
                response = self.client.request('GET', '/v2/products')
                data = response.json()

                if data and 'result' in data:
                    products = data['result']

                    # Filter for options of the specified asset
                    asset_options = [
                        p for p in products
                        if base_asset in p.get('symbol', '')
                        and p.get('contract_type') in ['call_options', 'put_options']
                        and p.get('state') == 'live'
                    ]

                    mode = "PAPER" if self.paper_trading else "LIVE"
                    self.logger.info(f"[{mode}] Found {len(asset_options)} live {base_asset} options from Delta Exchange")
                    return asset_options

                return []

            except Exception as e:
                if attempt < max_retries - 1:
                    self.logger.warning(f"Error fetching {base_asset} options (attempt {attempt + 1}/{max_retries}): {e}")
                    self.logger.info(f"Retrying in {retry_delay} second(s)...")
                    import time
                    time.sleep(retry_delay)
                else:
                    self.logger.error(f"Error fetching {base_asset} options after {max_retries} attempts: {e}")
                    import traceback
                    self.logger.error(traceback.format_exc())
                    return []

        return []

    def _find_option_product(self, strike: int, option_type: str, expiry_date: datetime, symbol: str = 'BTCUSD') -> Optional[dict]:
        """
        Find specific option product by strike, type, and expiry
        ALWAYS fetches REAL option data from Delta Exchange API

        Args:
            strike: Strike price
            option_type: 'call' or 'put'
            expiry_date: Expiry date
            symbol: Trading symbol (e.g., 'BTCUSD', 'ETHUSD')

        Returns:
            Option product dict or None (REAL product from Delta Exchange)
        """
        # Fetch REAL options from Delta Exchange (even in paper trading)
        options = self._get_btc_options(symbol)

        # Filter by strike, type, and expiry
        expiry_str = expiry_date.strftime('%Y-%m-%d')

        for opt in options:
            opt_strike = opt.get('strike_price')
            opt_type = opt.get('contract_type')
            opt_expiry = opt.get('settlement_time', '')[:10]  # Get date part

            # Convert both strikes to int for comparison
            try:
                opt_strike_int = int(opt_strike)
            except (ValueError, TypeError):
                continue

            # Match: strike (int comparison), type (substring match), expiry (exact match)
            if (opt_strike_int == strike and
                option_type in opt_type and
                expiry_str == opt_expiry):

                self.logger.info(f"Found option: {opt.get('symbol')} (ID: {opt.get('id')})")
                return opt

        self.logger.warning(f"Option not found: {option_type} strike ${strike} expiry {expiry_str}")
        self.logger.debug(f"Search criteria: strike={strike} (int), type contains '{option_type}', expiry={expiry_str}")
        return None

    def enter_long(self, symbol: str, size_usd: float, current_price: float) -> Dict:
        """
        Enter LONG position by selling ATM PUT option

        Args:
            symbol: Trading symbol (e.g., 'BTCUSD')
            size_usd: Position size in USD
            current_price: Current market price

        Returns:
            Order result dict
        """
        self.logger.info(f"ENTER LONG signal received → Selling ATM PUT option")

        # Calculate position size
        lots = self._calculate_lots(size_usd, current_price, symbol)

        # Find ATM strike
        strike = self._find_atm_strike(current_price, symbol)

        # Get expiry (next day)
        expiry = self._get_next_day_expiry()

        # Find option product
        option = self._find_option_product(strike, 'put', expiry, symbol)

        if not option:
            self.logger.error("Could not find suitable PUT option")
            return {'success': False, 'error': 'Option not found'}

        # Paper trading simulation
        if self.paper_trading:
            self.logger.info(f"[PAPER] SELL {lots} lots of {option['symbol']} (ATM PUT)")

            contract_size = self.CONTRACT_SPECS.get(symbol, 0.001)
            size_base = lots * contract_size

            # Fetch REAL option mark price from Delta Exchange (even in paper trading)
            option_mark_price = 0
            try:
                # Use delta-rest-client's get_ticker method (same as monitoring section)
                ticker_data = self.client.get_ticker(option['id'])

                if ticker_data and isinstance(ticker_data, dict):
                    # Handle both wrapped and direct responses
                    if 'result' in ticker_data:
                        mark_price_value = ticker_data['result'].get('mark_price')
                    else:
                        mark_price_value = ticker_data.get('mark_price')

                    if mark_price_value is not None:
                        option_mark_price = float(mark_price_value)
                        self.logger.info(f"[PAPER] Option mark price fetched: ${option_mark_price:.2f} for {option['symbol']}")
                    else:
                        self.logger.error(f"[PAPER] Mark price not found in ticker response for {option['symbol']}")
                        self.logger.debug(f"[PAPER] Ticker data: {ticker_data}")
                else:
                    self.logger.error(f"[PAPER] Invalid ticker response for {option['symbol']}")
                    self.logger.debug(f"[PAPER] Ticker data: {ticker_data}")
            except Exception as e:
                self.logger.error(f"[PAPER] Error fetching option mark price for {option['symbol']} (product_id: {option['id']}): {e}")
                import traceback
                self.logger.debug(traceback.format_exc())
                option_mark_price = 0

            self.current_position = {
                'type': 'put',
                'symbol': option['symbol'],
                'base_symbol': symbol,  # Store base trading pair (e.g., 'ETHUSD', 'BTCUSD')
                'product_id': option['id'],
                'strike': strike,
                'lots': lots,
                'entry_price': current_price,
                'entry_time': datetime.now(),
                'expiry': expiry
            }

            return {
                'order_id': 'PAPER_' + str(int(time.time())),
                'fill_price': option_mark_price,  # Use REAL option mark price, not spot price
                'filled_size': size_base,
                'lots': lots,
                'status': 'filled',
                'timestamp': int(time.time()),
                'symbol': option['symbol'],
                'side': 'sell'
            }

        # Real order placement with retry logic
        max_retries = 3
        retry_delay = 2  # seconds

        for attempt in range(max_retries):
            try:
                # First, check if order already exists (in case of retry after API failure)
                if attempt > 0:
                    self.logger.info(f"Retry attempt {attempt}/{max_retries-1} - Checking for existing position...")

                    # Check if we already have a position for this option
                    try:
                        positions = self.client.get_positions()
                        for pos in positions:
                            if (pos.get('product_symbol') == option['symbol'] and
                                abs(float(pos.get('size', 0))) > 0):
                                self.logger.info(f"✓ Found existing position for {option['symbol']} - Order was already filled")

                                contract_size = self.CONTRACT_SPECS.get(symbol, 0.001)
                                size_base = lots * contract_size

                                # Fetch current mark price for fill price
                                fill_price = current_price
                                try:
                                    ticker_data = self.client.request('GET', f"/v2/tickers/{option['symbol']}")
                                    if ticker_data and 'result' in ticker_data:
                                        fill_price = float(ticker_data['result'].get('mark_price', current_price))
                                except:
                                    pass

                                self.current_position = {
                                    'type': 'put',
                                    'symbol': option['symbol'],
                                    'base_symbol': symbol,  # Store base trading pair (e.g., 'ETHUSD', 'BTCUSD')
                                    'product_id': option['id'],
                                    'strike': strike,
                                    'lots': lots,
                                    'entry_price': fill_price,
                                    'entry_time': datetime.now(),
                                    'expiry': expiry,
                                    'order_id': 'RECOVERED'
                                }

                                return {
                                    'order_id': 'RECOVERED',
                                    'fill_price': fill_price,
                                    'filled_size': size_base,
                                    'lots': lots,
                                    'status': 'filled',
                                    'timestamp': int(time.time()),
                                    'symbol': option['symbol'],
                                    'side': 'sell'
                                }
                    except Exception as check_error:
                        self.logger.warning(f"Could not check existing positions: {check_error}")

                # Place the order
                self.logger.info(f"Placing order (attempt {attempt + 1}/{max_retries})...")
                order_response = self.client.place_order(
                    product_id=option['id'],
                    size=lots,
                    side='sell',
                    order_type=OrderType.MARKET,
                    limit_price=None
                )

                if order_response and order_response.get('success'):
                    self.logger.info(f"✓ SOLD {lots} lots of {option['symbol']} (PUT)")

                    contract_size = self.CONTRACT_SPECS.get(symbol, 0.001)
                    size_base = lots * contract_size

                    # Extract fill price from response
                    avg_fill = order_response.get('result', {}).get('average_fill_price')
                    fill_price = float(avg_fill) if avg_fill is not None else current_price

                    self.current_position = {
                        'type': 'put',
                        'symbol': option['symbol'],
                        'base_symbol': symbol,  # Store base trading pair (e.g., 'ETHUSD', 'BTCUSD')
                        'product_id': option['id'],
                        'strike': strike,
                        'lots': lots,
                        'entry_price': fill_price,
                        'entry_time': datetime.now(),
                        'expiry': expiry,
                        'order_id': order_response.get('result', {}).get('id')
                    }

                    return {
                        'order_id': str(order_response.get('result', {}).get('id', '')),
                        'fill_price': fill_price,
                        'filled_size': size_base,
                        'lots': lots,
                        'status': order_response.get('result', {}).get('state', 'filled'),
                        'timestamp': int(time.time()),
                        'symbol': option['symbol'],
                        'side': 'sell'
                    }
                else:
                    error_msg = order_response.get('error', {}).get('message', 'Unknown error') if isinstance(order_response, dict) else str(order_response)
                    self.logger.error(f"Order failed (attempt {attempt + 1}/{max_retries}): {error_msg}")

                    if attempt < max_retries - 1:
                        self.logger.info(f"Retrying in {retry_delay} seconds...")
                        time.sleep(retry_delay)
                    else:
                        return {'success': False, 'error': error_msg}

            except Exception as e:
                self.logger.error(f"Error placing option order (attempt {attempt + 1}/{max_retries}): {e}")

                if attempt < max_retries - 1:
                    self.logger.info(f"Retrying in {retry_delay} seconds...")
                    time.sleep(retry_delay)
                else:
                    return {'success': False, 'error': str(e)}

        return {'success': False, 'error': 'Max retries exceeded'}

    def enter_short(self, symbol: str, size_usd: float, current_price: float) -> Dict:
        """
        Enter SHORT position by selling ATM CALL option

        Args:
            symbol: Trading symbol (e.g., 'BTCUSD')
            size_usd: Position size in USD
            current_price: Current market price

        Returns:
            Order result dict
        """
        self.logger.info(f"ENTER SHORT signal received → Selling ATM CALL option")

        # Calculate position size
        lots = self._calculate_lots(size_usd, current_price, symbol)

        # Find ATM strike
        strike = self._find_atm_strike(current_price, symbol)

        # Get expiry (next day)
        expiry = self._get_next_day_expiry()

        # Find option product
        option = self._find_option_product(strike, 'call', expiry, symbol)

        if not option:
            self.logger.error("Could not find suitable CALL option")
            return {'success': False, 'error': 'Option not found'}

        # Paper trading simulation
        if self.paper_trading:
            self.logger.info(f"[PAPER] SELL {lots} lots of {option['symbol']} (ATM CALL)")

            contract_size = self.CONTRACT_SPECS.get(symbol, 0.001)
            size_base = lots * contract_size

            # Fetch REAL option mark price from Delta Exchange (even in paper trading)
            option_mark_price = 0
            try:
                # Use delta-rest-client's get_ticker method (same as monitoring section)
                ticker_data = self.client.get_ticker(option['id'])

                if ticker_data and isinstance(ticker_data, dict):
                    # Handle both wrapped and direct responses
                    if 'result' in ticker_data:
                        mark_price_value = ticker_data['result'].get('mark_price')
                    else:
                        mark_price_value = ticker_data.get('mark_price')

                    if mark_price_value is not None:
                        option_mark_price = float(mark_price_value)
                        self.logger.info(f"[PAPER] Option mark price fetched: ${option_mark_price:.2f} for {option['symbol']}")
                    else:
                        self.logger.error(f"[PAPER] Mark price not found in ticker response for {option['symbol']}")
                        self.logger.debug(f"[PAPER] Ticker data: {ticker_data}")
                else:
                    self.logger.error(f"[PAPER] Invalid ticker response for {option['symbol']}")
                    self.logger.debug(f"[PAPER] Ticker data: {ticker_data}")
            except Exception as e:
                self.logger.error(f"[PAPER] Error fetching option mark price for {option['symbol']} (product_id: {option['id']}): {e}")
                import traceback
                self.logger.debug(traceback.format_exc())
                option_mark_price = 0

            self.current_position = {
                'type': 'call',
                'symbol': option['symbol'],
                'base_symbol': symbol,  # Store base trading pair (e.g., 'ETHUSD', 'BTCUSD')
                'product_id': option['id'],
                'strike': strike,
                'lots': lots,
                'entry_price': current_price,
                'entry_time': datetime.now(),
                'expiry': expiry
            }

            return {
                'order_id': 'PAPER_' + str(int(time.time())),
                'fill_price': option_mark_price,  # Use REAL option mark price, not spot price
                'filled_size': size_base,
                'lots': lots,
                'status': 'filled',
                'timestamp': int(time.time()),
                'symbol': option['symbol'],
                'side': 'sell'
            }

        # Real order placement with retry logic
        max_retries = 3
        retry_delay = 2  # seconds

        for attempt in range(max_retries):
            try:
                # First, check if order already exists (in case of retry after API failure)
                if attempt > 0:
                    self.logger.info(f"Retry attempt {attempt}/{max_retries-1} - Checking for existing position...")

                    # Check if we already have a position for this option
                    try:
                        positions = self.client.get_positions()
                        for pos in positions:
                            if (pos.get('product_symbol') == option['symbol'] and
                                abs(float(pos.get('size', 0))) > 0):
                                self.logger.info(f"✓ Found existing position for {option['symbol']} - Order was already filled")

                                contract_size = self.CONTRACT_SPECS.get(symbol, 0.001)
                                size_base = lots * contract_size

                                # Fetch current mark price for fill price
                                fill_price = current_price
                                try:
                                    ticker_data = self.client.request('GET', f"/v2/tickers/{option['symbol']}")
                                    if ticker_data and 'result' in ticker_data:
                                        fill_price = float(ticker_data['result'].get('mark_price', current_price))
                                except:
                                    pass

                                self.current_position = {
                                    'type': 'call',
                                    'symbol': option['symbol'],
                                    'base_symbol': symbol,  # Store base trading pair (e.g., 'ETHUSD', 'BTCUSD')
                                    'product_id': option['id'],
                                    'strike': strike,
                                    'lots': lots,
                                    'entry_price': fill_price,
                                    'entry_time': datetime.now(),
                                    'expiry': expiry,
                                    'order_id': 'RECOVERED'
                                }

                                return {
                                    'order_id': 'RECOVERED',
                                    'fill_price': fill_price,
                                    'filled_size': size_base,
                                    'lots': lots,
                                    'status': 'filled',
                                    'timestamp': int(time.time()),
                                    'symbol': option['symbol'],
                                    'side': 'sell'
                                }
                    except Exception as check_error:
                        self.logger.warning(f"Could not check existing positions: {check_error}")

                # Place the order
                self.logger.info(f"Placing order (attempt {attempt + 1}/{max_retries})...")
                order_response = self.client.place_order(
                    product_id=option['id'],
                    size=lots,
                    side='sell',
                    order_type=OrderType.MARKET,
                    limit_price=None
                )

                if order_response and order_response.get('success'):
                    self.logger.info(f"✓ SOLD {lots} lots of {option['symbol']} (CALL)")

                    contract_size = self.CONTRACT_SPECS.get(symbol, 0.001)
                    size_base = lots * contract_size

                    # Extract fill price from response
                    avg_fill = order_response.get('result', {}).get('average_fill_price')
                    fill_price = float(avg_fill) if avg_fill is not None else current_price

                    self.current_position = {
                        'type': 'call',
                        'symbol': option['symbol'],
                        'base_symbol': symbol,  # Store base trading pair (e.g., 'ETHUSD', 'BTCUSD')
                        'product_id': option['id'],
                        'strike': strike,
                        'lots': lots,
                        'entry_price': fill_price,
                        'entry_time': datetime.now(),
                        'expiry': expiry,
                        'order_id': order_response.get('result', {}).get('id')
                    }

                    return {
                        'order_id': str(order_response.get('result', {}).get('id', '')),
                        'fill_price': fill_price,
                        'filled_size': size_base,
                        'lots': lots,
                        'status': order_response.get('result', {}).get('state', 'filled'),
                        'timestamp': int(time.time()),
                        'symbol': option['symbol'],
                        'side': 'sell'
                    }
                else:
                    error_msg = order_response.get('error', {}).get('message', 'Unknown error') if isinstance(order_response, dict) else str(order_response)
                    self.logger.error(f"Order failed (attempt {attempt + 1}/{max_retries}): {error_msg}")

                    if attempt < max_retries - 1:
                        self.logger.info(f"Retrying in {retry_delay} seconds...")
                        time.sleep(retry_delay)
                    else:
                        return {'success': False, 'error': error_msg}

            except Exception as e:
                self.logger.error(f"Error placing option order (attempt {attempt + 1}/{max_retries}): {e}")

                if attempt < max_retries - 1:
                    self.logger.info(f"Retrying in {retry_delay} seconds...")
                    time.sleep(retry_delay)
                else:
                    return {'success': False, 'error': str(e)}

        return {'success': False, 'error': 'Max retries exceeded'}

    def close_position(self, symbol: str = None) -> Dict:
        """
        Close current option position by buying back

        Args:
            symbol: Trading symbol (not used, for interface compatibility)

        Returns:
            Order result dict
        """
        if not self.current_position:
            self.logger.warning("No open option position to close")
            return {'success': False, 'error': 'No position'}

        pos = self.current_position

        self.logger.info(f"CLOSE signal received → Buying back {pos['symbol']}")

        # Paper trading simulation
        if self.paper_trading:
            self.logger.info(f"[PAPER] BUY BACK {pos['lots']} lots of {pos['symbol']}")

            hold_time = (datetime.now() - pos['entry_time']).total_seconds() / 60
            self.logger.info(f"Position held for {hold_time:.1f} minutes")

            # For exit, we need a current price - use entry price as estimate for paper trading
            exit_price = pos['entry_price']

            # Get base symbol from stored position
            base_symbol = pos.get('base_symbol', 'BTCUSD')
            contract_size = self.CONTRACT_SPECS.get(base_symbol, 0.001)
            size_base = pos['lots'] * contract_size

            self.current_position = None

            return {
                'success': True,
                'order_id': 'PAPER_CLOSE_' + str(int(time.time())),
                'fill_price': exit_price,
                'filled_size': size_base,
                'lots': pos['lots'],
                'status': 'filled',
                'timestamp': int(time.time()),
                'symbol': pos['symbol'],
                'side': 'buy'
            }

        # Real order placement with retry logic
        max_retries = 3
        retry_delay = 2  # seconds

        for attempt in range(max_retries):
            try:
                # First, check if position is already closed (in case of retry after API failure)
                if attempt > 0:
                    self.logger.info(f"Retry attempt {attempt}/{max_retries-1} - Checking if position already closed...")

                    # Check if position still exists
                    try:
                        positions = self.client.get_positions()
                        position_found = False
                        for p in positions:
                            if (p.get('product_symbol') == pos['symbol'] and
                                abs(float(p.get('size', 0))) > 0):
                                position_found = True
                                break

                        if not position_found:
                            self.logger.info(f"✓ Position {pos['symbol']} is already closed")

                            # Fetch exit price from mark price
                            exit_price = pos['entry_price']
                            try:
                                ticker_data = self.client.request('GET', f"/v2/tickers/{pos['symbol']}")
                                if ticker_data and 'result' in ticker_data:
                                    exit_price = float(ticker_data['result'].get('mark_price', pos['entry_price']))
                            except:
                                pass

                            # Get base symbol from stored position
                            base_symbol = pos.get('base_symbol', 'BTCUSD')
                            contract_size = self.CONTRACT_SPECS.get(base_symbol, 0.001)
                            size_base = pos['lots'] * contract_size

                            hold_time = (datetime.now() - pos['entry_time']).total_seconds() / 60
                            self.logger.info(f"Position held for {hold_time:.1f} minutes")

                            self.current_position = None

                            return {
                                'success': True,
                                'order_id': 'RECOVERED_CLOSE',
                                'fill_price': exit_price,
                                'filled_size': size_base,
                                'lots': pos['lots'],
                                'status': 'filled',
                                'timestamp': int(time.time()),
                                'symbol': pos['symbol'],
                                'side': 'buy'
                            }
                    except Exception as check_error:
                        self.logger.warning(f"Could not check existing positions: {check_error}")

                # Place the close order
                self.logger.info(f"Placing close order (attempt {attempt + 1}/{max_retries})...")
                order_response = self.client.place_order(
                    product_id=pos['product_id'],
                    size=pos['lots'],
                    side='buy',  # Buy to close
                    order_type=OrderType.MARKET,
                    limit_price=None
                )

                if order_response and order_response.get('success'):
                    hold_time = (datetime.now() - pos['entry_time']).total_seconds() / 60
                    self.logger.info(f"✓ CLOSED {pos['lots']} lots of {pos['symbol']}")
                    self.logger.info(f"Position held for {hold_time:.1f} minutes")

                    # Extract fill price from response
                    avg_fill = order_response.get('result', {}).get('average_fill_price')
                    fill_price = float(avg_fill) if avg_fill is not None else pos['entry_price']

                    # Get base symbol from stored position
                    base_symbol = pos.get('base_symbol', 'BTCUSD')
                    contract_size = self.CONTRACT_SPECS.get(base_symbol, 0.001)
                    size_base = pos['lots'] * contract_size

                    self.current_position = None

                    return {
                        'success': True,
                        'order_id': str(order_response.get('result', {}).get('id', '')),
                        'fill_price': fill_price,
                        'filled_size': size_base,
                        'lots': pos['lots'],
                        'status': order_response.get('result', {}).get('state', 'filled'),
                        'timestamp': int(time.time()),
                        'symbol': pos['symbol'],
                        'side': 'buy'
                    }
                else:
                    error_msg = order_response.get('error', {}).get('message', 'Unknown error') if isinstance(order_response, dict) else str(order_response)
                    self.logger.error(f"Close order failed (attempt {attempt + 1}/{max_retries}): {error_msg}")

                    if attempt < max_retries - 1:
                        self.logger.info(f"Retrying in {retry_delay} seconds...")
                        time.sleep(retry_delay)
                    else:
                        # CRITICAL: Do not clear position if we couldn't confirm closure
                        self.logger.error(f"CRITICAL: Failed to close position after {max_retries} attempts - POSITION STILL OPEN!")
                        return {'success': False, 'error': error_msg, 'position_still_open': True}

            except Exception as e:
                self.logger.error(f"Error closing option position (attempt {attempt + 1}/{max_retries}): {e}")

                if attempt < max_retries - 1:
                    self.logger.info(f"Retrying in {retry_delay} seconds...")
                    time.sleep(retry_delay)
                else:
                    # CRITICAL: Do not clear position if we couldn't confirm closure
                    self.logger.error(f"CRITICAL: Failed to close position after {max_retries} attempts - POSITION STILL OPEN!")
                    return {'success': False, 'error': str(e), 'position_still_open': True}

        return {'success': False, 'error': 'Max retries exceeded', 'position_still_open': True}

    def get_position(self, symbol: str) -> Optional[Dict]:
        """
        Get current option position

        Args:
            symbol: Trading symbol

        Returns:
            Position dict or None
        """
        return self.current_position

    # =========================================================================
    # INTERFACE COMPATIBILITY METHODS
    # These methods match DeltaOrderManager interface for bot compatibility
    # =========================================================================

    def place_entry_order(self, symbol: str, side: str, size_usd: float,
                         current_price: Optional[float] = None) -> Dict:
        """
        Place entry order (interface compatibility with DeltaOrderManager)
        Routes to enter_long or enter_short based on side

        Args:
            symbol: Trading symbol (e.g., 'BTCUSD')
            side: 'buy' (LONG) or 'sell' (SHORT)
            size_usd: Position size in USD
            current_price: Current market price

        Returns:
            Order result dict
        """
        if side.lower() == 'buy':
            return self.enter_long(symbol, size_usd, current_price)
        elif side.lower() == 'sell':
            return self.enter_short(symbol, size_usd, current_price)
        else:
            self.logger.error(f"Invalid side: {side}. Must be 'buy' or 'sell'")
            return {'success': False, 'error': f'Invalid side: {side}'}

    def place_exit_order(self, symbol: str, side: str, size_base: float,
                        current_price: Optional[float] = None, reason: str = "Exit") -> Dict:
        """
        Place exit order (interface compatibility with DeltaOrderManager)

        Args:
            symbol: Trading symbol
            side: Exit side (opposite of entry) - ignored for options
            size_base: Position size - ignored for options (always full position)
            current_price: Current price - ignored for options
            reason: Exit reason (for logging)

        Returns:
            Order result dict
        """
        self.logger.info(f"Exit reason: {reason}")
        return self.close_position(symbol)

    def place_partial_exit(self, symbol: str, side: str, size_base: float,
                          percentage: int) -> Dict:
        """
        Partial exit NOT supported for options
        Options must be closed fully (can't partially close option contracts)

        Args:
            symbol: Trading symbol
            side: Exit side
            size_base: Partial size
            percentage: Percentage to close

        Returns:
            Error dict
        """
        self.logger.warning("Partial exits not supported for options - must close full position")
        return {
            'success': False,
            'error': 'Partial exits not supported for options'
        }
