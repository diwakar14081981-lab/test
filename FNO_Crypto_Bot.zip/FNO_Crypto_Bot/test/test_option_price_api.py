#!/usr/bin/env python3
"""
Test script to understand Delta Exchange Options API
and how to fetch option mark prices correctly
"""

import sys
sys.path.insert(0, 'D:\\Latest_Bot\\final_bot')

from live_trading_credentials import LIVE_API_KEY, LIVE_API_SECRET

try:
    from delta_rest_client import DeltaRestClient
except ImportError:
    print("ERROR: delta-rest-client not installed")
    print("Install with: pip install delta-rest-client")
    sys.exit(1)

print("="*70)
print("Testing Delta Exchange Options API")
print("="*70)

# Initialize client
client = DeltaRestClient(
    base_url='https://api.india.delta.exchange',
    api_key=LIVE_API_KEY,
    api_secret=LIVE_API_SECRET
)

print("\n1. Testing get_product() method...")
try:
    # Test with a known BTC option product ID (we'll need to find the right one)
    # For now, let's try to list products using a different approach

    # Method 1: Use get_ticker to find available products
    print("   Testing get_ticker()...")
    ticker_response = client.get_ticker(symbol='BTCUSD')
    print(f"   Ticker response: {ticker_response}")

    # Method 2: Check delta_options_manager to see how it fetches options
    print("\n2. Checking existing _get_btc_options implementation...")
    from delta_options_manager import DeltaOptionsManager
    manager = DeltaOptionsManager(LIVE_API_KEY, LIVE_API_SECRET, paper_trading=False)

    btc_options = manager._get_btc_options()
    print(f"   Found {len(btc_options)} BTC options")

    if all_products and 'result' in all_products:
        products = all_products['result']
        print(f"   Total products: {len(products)}")

        # Filter for BTC options
        btc_options = [p for p in products if 'BTC' in p.get('symbol', '')
                      and p.get('contract_type') in ['call_options', 'put_options']
                      and p.get('state') == 'live']

        print(f"   Live BTC options: {len(btc_options)}")

        if len(btc_options) > 0:
            print("\n2. Sample BTC option details:")
            sample = btc_options[0]
            print(f"   Symbol: {sample.get('symbol')}")
            print(f"   Product ID: {sample.get('id')}")
            print(f"   Strike: {sample.get('strike_price')}")
            print(f"   Type: {sample.get('contract_type')}")
            print(f"   Settlement: {sample.get('settlement_time')}")
            print(f"   Mark Price: {sample.get('mark_price')}")
            print(f"   Underlying Price: {sample.get('underlying_asset', {}).get('mark_price')}")

            print("\n3. Full sample product structure:")
            for key, value in sample.items():
                print(f"   {key}: {value}")

            print("\n4. Testing get_product() for a specific option:")
            product_id = sample.get('id')
            print(f"   Fetching product ID: {product_id}")

            single_product = client.get_product(product_id)
            print(f"   Response structure: {type(single_product)}")

            if single_product:
                print(f"   Keys in response: {list(single_product.keys())}")
                if 'result' in single_product:
                    result = single_product['result']
                    print(f"\n   Product details:")
                    print(f"   Symbol: {result.get('symbol')}")
                    print(f"   Mark Price: {result.get('mark_price')}")
                    print(f"   Index Price: {result.get('index_price')}")
                    print(f"   Best Bid: {result.get('best_bid')}")
                    print(f"   Best Ask: {result.get('best_ask')}")
                elif 'success' in single_product:
                    print(f"   Success: {single_product.get('success')}")
                    print(f"   Full response: {single_product}")
                else:
                    print(f"   Full response: {single_product}")
        else:
            print("   No live BTC options found!")
    else:
        print(f"   ERROR: Unexpected response structure: {all_products}")

except Exception as e:
    print(f"   ERROR: {e}")
    import traceback
    traceback.print_exc()

print("\n" + "="*70)
print("Test completed")
print("="*70)
