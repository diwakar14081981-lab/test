#!/usr/bin/env python3
"""
Unit Tests for DeltaOrderManager - Market Order Changes
Tests the critical bug fix: limit orders -> market orders
"""

import unittest
from unittest.mock import Mock, patch, MagicMock
import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from delta_order_manager import DeltaOrderManager
from delta_rest_client import OrderType


class TestDeltaOrderManagerPaperTrading(unittest.TestCase):
    """Test paper trading mode (no API calls)"""

    def setUp(self):
        """Initialize manager in paper trading mode"""
        self.manager = DeltaOrderManager(
            api_key="test_key",
            api_secret="test_secret",
            paper_trading=True
        )

    def test_place_entry_order_buy_paper(self):
        """Test paper trading BUY entry order"""
        result = self.manager.place_entry_order(
            symbol='BTCUSD',
            side='buy',
            size_usd=1000.0,
            current_price=100000.0
        )

        # Verify result structure
        self.assertIn('order_id', result)
        self.assertIn('fill_price', result)
        self.assertIn('filled_size', result)
        self.assertIn('lots', result)
        self.assertIn('status', result)

        # Verify values
        self.assertEqual(result['status'], 'filled')
        self.assertEqual(result['side'], 'buy')
        self.assertEqual(result['symbol'], 'BTCUSD')
        self.assertGreater(result['fill_price'], 0)
        self.assertGreater(result['lots'], 0)

        # Paper trading should simulate slippage (buy = higher price)
        self.assertGreater(result['fill_price'], 100000.0)

    def test_place_entry_order_sell_paper(self):
        """Test paper trading SELL entry order"""
        result = self.manager.place_entry_order(
            symbol='BTCUSD',
            side='sell',
            size_usd=1000.0,
            current_price=100000.0
        )

        self.assertEqual(result['status'], 'filled')
        self.assertEqual(result['side'], 'sell')

        # Paper trading should simulate slippage (sell = lower price)
        self.assertLess(result['fill_price'], 100000.0)

    def test_place_exit_order_paper(self):
        """Test paper trading exit order"""
        result = self.manager.place_exit_order(
            symbol='BTCUSD',
            side='sell',
            size_base=0.01,  # 0.01 BTC
            current_price=100000.0,
            reason="Test Exit"
        )

        # Verify result structure
        self.assertEqual(result['status'], 'filled')
        self.assertEqual(result['side'], 'sell')
        self.assertGreater(result['fill_price'], 0)
        self.assertEqual(result['filled_size'], 0.01)

    def test_lot_calculation(self):
        """Test lot size calculation for different symbols"""
        # BTC: 1 lot = 0.001 BTC
        lots = self.manager._calculate_lots(
            size_usd=1000.0,
            current_price=100000.0,
            symbol='BTCUSD'
        )
        # 1000 / 100000 = 0.01 BTC = 10 lots
        self.assertEqual(lots, 10)

        # ETH: 1 lot = 0.001 ETH
        lots = self.manager._calculate_lots(
            size_usd=100.0,
            current_price=4000.0,
            symbol='ETHUSD'
        )
        # 100 / 4000 = 0.025 ETH = 25 lots
        self.assertEqual(lots, 25)


class TestDeltaOrderManagerLiveTrading(unittest.TestCase):
    """Test live trading mode with mocked API client"""

    def setUp(self):
        """Initialize manager in live trading mode with mocked client"""
        with patch('delta_order_manager.DeltaRestClient'):
            self.manager = DeltaOrderManager(
                api_key="test_key",
                api_secret="test_secret",
                paper_trading=False
            )
            # Mock the client
            self.manager.client = Mock()

    def test_place_entry_order_uses_market_order_type(self):
        """CRITICAL: Verify entry orders use OrderType.MARKET"""
        # Mock successful order response
        self.manager.client.place_order.return_value = {
            'id': 'test_order_123',
            'average_fill_price': '100500.0',
            'state': 'filled'
        }

        result = self.manager.place_entry_order(
            symbol='BTCUSD',
            side='buy',
            size_usd=1000.0,
            current_price=100000.0
        )

        # Verify place_order was called
        self.manager.client.place_order.assert_called_once()

        # Get the actual call arguments
        call_args = self.manager.client.place_order.call_args

        # CRITICAL CHECK: Verify order_type is MARKET
        self.assertEqual(call_args.kwargs['order_type'], OrderType.MARKET)

        # CRITICAL CHECK: Verify limit_price is NOT in the call
        self.assertNotIn('limit_price', call_args.kwargs)

        # Verify other parameters
        self.assertEqual(call_args.kwargs['product_id'], 27)  # BTC product ID
        self.assertEqual(call_args.kwargs['side'], 'buy')
        self.assertGreater(call_args.kwargs['size'], 0)

    def test_place_exit_order_uses_market_order_type(self):
        """CRITICAL: Verify exit orders use OrderType.MARKET"""
        # Mock successful order response
        self.manager.client.place_order.return_value = {
            'id': 'test_exit_456',
            'average_fill_price': '100200.0',
            'state': 'filled'
        }

        result = self.manager.place_exit_order(
            symbol='BTCUSD',
            side='sell',
            size_base=0.01,
            current_price=100000.0,
            reason="Test Exit"
        )

        # Verify place_order was called
        self.manager.client.place_order.assert_called_once()

        # Get the actual call arguments
        call_args = self.manager.client.place_order.call_args

        # CRITICAL CHECK: Verify order_type is MARKET
        self.assertEqual(call_args.kwargs['order_type'], OrderType.MARKET)

        # CRITICAL CHECK: Verify limit_price is NOT in the call
        self.assertNotIn('limit_price', call_args.kwargs)

        # Verify other parameters
        self.assertEqual(call_args.kwargs['side'], 'sell')

    def test_entry_order_handles_missing_average_fill_price(self):
        """Test fallback to current_price when average_fill_price is None"""
        # Mock response without average_fill_price
        self.manager.client.place_order.return_value = {
            'id': 'test_order_789',
            'average_fill_price': None,  # Missing fill price
            'state': 'filled'
        }

        result = self.manager.place_entry_order(
            symbol='BTCUSD',
            side='buy',
            size_usd=1000.0,
            current_price=100000.0
        )

        # Should fall back to current_price
        self.assertEqual(result['fill_price'], 100000.0)
        self.assertEqual(result['order_id'], 'test_order_789')

    def test_exit_order_handles_missing_average_fill_price(self):
        """Test fallback to current_price when average_fill_price is None"""
        # Mock response without average_fill_price
        self.manager.client.place_order.return_value = {
            'id': 'test_exit_999',
            'average_fill_price': None,
            'state': 'filled'
        }

        result = self.manager.place_exit_order(
            symbol='BTCUSD',
            side='sell',
            size_base=0.01,
            current_price=100000.0
        )

        # Should fall back to current_price (not limit_price which no longer exists)
        self.assertEqual(result['fill_price'], 100000.0)

    def test_entry_order_with_valid_average_fill_price(self):
        """Test using average_fill_price when provided"""
        self.manager.client.place_order.return_value = {
            'id': 'test_order_111',
            'average_fill_price': '100750.50',  # String format
            'state': 'filled'
        }

        result = self.manager.place_entry_order(
            symbol='BTCUSD',
            side='buy',
            size_usd=1000.0,
            current_price=100000.0
        )

        # Should use average_fill_price converted to float
        self.assertEqual(result['fill_price'], 100750.50)

    def test_no_limit_price_calculation_in_new_code(self):
        """Verify old limit_price calculation logic is removed"""
        self.manager.client.place_order.return_value = {
            'id': 'test_order_222',
            'average_fill_price': '100000.0',
            'state': 'filled'
        }

        # For BUY, old code would calculate: limit_price = int(100000 * 1.001) = 100100
        # For SELL, old code would calculate: limit_price = int(100000 * 0.999) = 99900

        result = self.manager.place_entry_order(
            symbol='BTCUSD',
            side='buy',
            size_usd=1000.0,
            current_price=100000.0
        )

        # Verify the call arguments don't contain limit_price
        call_args = self.manager.client.place_order.call_args
        self.assertNotIn('limit_price', call_args.kwargs)

        # Result should use average_fill_price, not calculated limit price
        self.assertEqual(result['fill_price'], 100000.0)


class TestEdgeCases(unittest.TestCase):
    """Test edge cases and error handling"""

    def test_paper_trading_requires_current_price(self):
        """Paper trading should raise error if current_price not provided"""
        manager = DeltaOrderManager(
            api_key="test",
            api_secret="test",
            paper_trading=True
        )

        with self.assertRaises(Exception) as context:
            manager.place_entry_order(
                symbol='BTCUSD',
                side='buy',
                size_usd=1000.0
                # current_price NOT provided
            )

        self.assertIn("current_price required", str(context.exception))

    def test_invalid_symbol_raises_error(self):
        """Test that invalid symbols raise appropriate errors in LIVE mode"""
        # Paper trading doesn't validate symbols strictly (uses default contract size)
        # Only live trading mode validates symbols via _get_product_id

        with patch('delta_order_manager.DeltaRestClient'):
            manager = DeltaOrderManager(
                api_key="test",
                api_secret="test",
                paper_trading=False
            )
            manager.client = Mock()

            # Mock _get_product_id to raise exception for invalid symbol
            manager._get_product_id = Mock(side_effect=Exception("Unknown symbol: INVALID. Supported: ['BTCUSD', 'ETHUSD', 'SOLUSD']"))

            with self.assertRaises(Exception) as context:
                manager.place_entry_order(
                    symbol='INVALID',
                    side='buy',
                    size_usd=1000.0,
                    current_price=100000.0
                )

            self.assertIn("Unknown symbol", str(context.exception))

    def test_minimum_lot_size(self):
        """Test that lot size is minimum 1"""
        manager = DeltaOrderManager(
            api_key="test",
            api_secret="test",
            paper_trading=True
        )

        # Very small position should still be 1 lot
        lots = manager._calculate_lots(
            size_usd=1.0,  # $1 position
            current_price=100000.0,
            symbol='BTCUSD'
        )

        self.assertEqual(lots, 1)  # Minimum 1 lot


def run_tests():
    """Run all tests and print results"""
    # Create test suite
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()

    # Add all test classes
    suite.addTests(loader.loadTestsFromTestCase(TestDeltaOrderManagerPaperTrading))
    suite.addTests(loader.loadTestsFromTestCase(TestDeltaOrderManagerLiveTrading))
    suite.addTests(loader.loadTestsFromTestCase(TestEdgeCases))

    # Run tests with verbose output
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    # Return exit code
    return 0 if result.wasSuccessful() else 1


if __name__ == '__main__':
    print("="*70)
    print("Testing DeltaOrderManager - Market Order Implementation")
    print("="*70)
    print()

    exit_code = run_tests()

    print()
    print("="*70)
    if exit_code == 0:
        print("ALL TESTS PASSED - Safe to deploy!")
    else:
        print("TESTS FAILED - Do NOT deploy until fixed!")
    print("="*70)

    sys.exit(exit_code)
