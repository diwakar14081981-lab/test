#!/usr/bin/env python3
"""
Test script to verify indicator calculations against TradingView
Calculates SuperTrend, EMA, and other indicators for manual verification
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from datetime import datetime, timedelta
import pandas as pd
from delta_exchange_client import DeltaExchangeClient
from btc_futures_scalping import calculate_supertrend, calculate_atr
from swing_supertrend_strategy import calculate_288_ema
from live_trading_credentials import LIVE_API_KEY, LIVE_API_SECRET

def main():
    print("="*80)
    print("INDICATOR VERIFICATION TEST")
    print("="*80)
    print()

    # Initialize client
    print("[1] Initializing Delta Exchange client...")
    client = DeltaExchangeClient(
        api_key=LIVE_API_KEY,
        api_secret=LIVE_API_SECRET,
        paper_trading=True
    )
    print("[OK] Client initialized")
    print()

    # Fetch 30m candles for SuperTrend
    print("[2] Fetching 30m candles for SuperTrend calculation...")
    df_30m = client.get_historical_data('BTCUSD', '30m', 60)

    if df_30m is None or len(df_30m) == 0:
        print("[ERROR] Failed to fetch 30m candles")
        return

    print(f"[OK] Fetched {len(df_30m)} candles")

    # SORT by timestamp to ensure chronological order (oldest to newest)
    df_30m = df_30m.sort_values('timestamp').reset_index(drop=True)

    # Show first and last timestamps to understand the time range
    first_timestamp_ist = df_30m.iloc[0]['timestamp'] + timedelta(hours=5, minutes=30)
    last_timestamp_ist = df_30m.iloc[-1]['timestamp'] + timedelta(hours=5, minutes=30)
    print(f"  First candle: {first_timestamp_ist.strftime('%Y-%m-%d %H:%M IST')}")
    print(f"  Last candle:  {last_timestamp_ist.strftime('%Y-%m-%d %H:%M IST')}")
    print()

    # Display last 5 candles
    print("[3] Last 5 30m candles:")
    print("-" * 80)
    for i in range(max(0, len(df_30m) - 5), len(df_30m)):
        candle = df_30m.iloc[i]
        timestamp_ist = candle['timestamp'] + timedelta(hours=5, minutes=30)
        print(f"  {timestamp_ist.strftime('%Y-%m-%d %H:%M IST')} | O: {candle['open']:>9.2f} | H: {candle['high']:>9.2f} | L: {candle['low']:>9.2f} | C: {candle['close']:>9.2f}")
    print()

    # Calculate SuperTrend (Period=10, Multiplier=3)
    print("[4] Calculating SuperTrend (Period=10, Multiplier=3)...")
    st_values, st_direction = calculate_supertrend(df_30m, period=10, multiplier=3.0)
    df_30m['supertrend'] = st_values
    df_30m['st_direction'] = st_direction

    # Calculate ATR for debugging
    atr = calculate_atr(df_30m, period=10)
    df_30m['atr'] = atr

    print("[OK] SuperTrend calculated")
    print()

    # Display last 10 30m candles with SuperTrend
    print("[5] Last 10 30m candles with SuperTrend:")
    print("-" * 100)
    print("  Timestamp (IST)     |    Open |    High |     Low |   Close |     ATR | SuperTrend | Direction")
    print("-" * 100)
    for i in range(max(0, len(df_30m)-10), len(df_30m)):
        candle = df_30m.iloc[i]
        timestamp_ist = candle['timestamp'] + timedelta(hours=5, minutes=30)
        st_dir = 'BULL' if candle['st_direction'] == 1 else 'BEAR'
        print(f"  {timestamp_ist.strftime('%Y-%m-%d %H:%M')} | {candle['open']:>7.2f} | {candle['high']:>7.2f} | {candle['low']:>7.2f} | {candle['close']:>7.2f} | {candle['atr']:>7.2f} | {candle['supertrend']:>10.2f} | {st_dir}")
    print()

    # Display last candle details
    print("[6] Last 30m candle details:")
    print("-" * 80)
    last_candle = df_30m.iloc[-1]
    timestamp_ist = last_candle['timestamp'] + timedelta(hours=5, minutes=30)

    print(f"  Timestamp (IST):  {timestamp_ist.strftime('%Y-%m-%d %H:%M')}")
    print(f"  Open:             ${last_candle['open']:,.2f}")
    print(f"  High:             ${last_candle['high']:,.2f}")
    print(f"  Low:              ${last_candle['low']:,.2f}")
    print(f"  Close:            ${last_candle['close']:,.2f}")
    print(f"  HL/2:             ${(last_candle['high'] + last_candle['low']) / 2:,.2f}")
    print(f"  ATR (10):         ${last_candle['atr']:,.2f}")
    print(f"  SuperTrend:       ${last_candle['supertrend']:,.2f}")
    print(f"  Direction:        {'BULLISH (+1)' if last_candle['st_direction'] == 1 else 'BEARISH (-1)'}")
    print()

    # Calculate bands for debugging
    hl2 = (last_candle['high'] + last_candle['low']) / 2
    basic_upper = hl2 + (3.0 * last_candle['atr'])
    basic_lower = hl2 - (3.0 * last_candle['atr'])

    print("[7] SuperTrend calculation breakdown:")
    print("-" * 80)
    print(f"  HL/2:                   ${hl2:,.2f}")
    print(f"  ATR × 3:                ${last_candle['atr'] * 3:,.2f}")
    print(f"  Basic Upper Band:       ${basic_upper:,.2f}")
    print(f"  Basic Lower Band:       ${basic_lower:,.2f}")
    print(f"  Final SuperTrend:       ${last_candle['supertrend']:,.2f}")
    print()

    # Fetch 5min candles for 288 EMA calculation
    print("[8] Fetching 5min candles for 288 EMA calculation...")
    df_5min = client.get_historical_data('BTCUSD', '5min', 350)

    if df_5min is None or len(df_5min) == 0:
        print("[ERROR] Failed to fetch 5min candles")
        return

    print(f"[OK] Fetched {len(df_5min)} candles")

    # SORT by timestamp to ensure chronological order (oldest to newest)
    df_5min = df_5min.sort_values('timestamp').reset_index(drop=True)
    print()

    # Calculate 288 EMA on 5min candles
    print("[9] Calculating 288 EMA on 5min data...")
    ema_288_series = calculate_288_ema(df_5min)
    df_5min['ema_288'] = ema_288_series

    if 'ema_288' in df_5min.columns:
        print("[OK] 288 EMA calculated")
        print()

        # Display last 5min candle with EMA
        print("[10] Last 5min candle with 288 EMA:")
        print("-" * 80)
        last_5min = df_5min.iloc[-1]
        timestamp_5min_ist = last_5min['timestamp'] + timedelta(hours=5, minutes=30)

        print(f"  Timestamp (IST):  {timestamp_5min_ist.strftime('%Y-%m-%d %H:%M')}")
        print(f"  Open:             ${last_5min['open']:,.2f}")
        print(f"  High:             ${last_5min['high']:,.2f}")
        print(f"  Low:              ${last_5min['low']:,.2f}")
        print(f"  Close:            ${last_5min['close']:,.2f}")
        print(f"  288 EMA:          ${last_5min['ema_288']:,.2f}")
        print()

        # Find and display the candle that closed at 20:25 IST and surrounding candles
        print("[11] Last 10 5min candles (for verification):")
        print("-" * 80)
        for i in range(max(0, len(df_5min)-10), len(df_5min)):
            candle = df_5min.iloc[i]
            timestamp_ist = candle['timestamp'] + timedelta(hours=5, minutes=30)
            print(f"  {timestamp_ist.strftime('%Y-%m-%d %H:%M')} | O: {candle['open']:>9.2f} | H: {candle['high']:>9.2f} | L: {candle['low']:>9.2f} | C: {candle['close']:>9.2f} | EMA: {candle['ema_288']:>9.2f}")
        print()

        # Specifically highlight 20:25
        print("[12] Candle that closed at 20:25 IST:")
        print("-" * 80)
        for i in range(len(df_5min)-1, max(0, len(df_5min)-20), -1):
            candle = df_5min.iloc[i]
            timestamp_ist = candle['timestamp'] + timedelta(hours=5, minutes=30)
            if timestamp_ist.hour == 20 and timestamp_ist.minute == 25:
                print(f"  Timestamp (IST):  {timestamp_ist.strftime('%Y-%m-%d %H:%M')}")
                print(f"  Open:             ${candle['open']:,.2f}")
                print(f"  High:             ${candle['high']:,.2f}")
                print(f"  Low:              ${candle['low']:,.2f}")
                print(f"  Close:            ${candle['close']:,.2f}")
                print(f"  288 EMA:          ${candle['ema_288']:,.2f}")
                break
        else:
            print("  [NOT FOUND] No candle found that closed at 20:25 IST")
        print()
    else:
        print("[ERROR] 288 EMA calculation failed")
        print()

    # Summary comparison table
    print("="*80)
    print("SUMMARY - Compare with TradingView:")
    print("="*80)
    print()
    print("30m SuperTrend (Period=10, Multiplier=3):")
    print(f"  Bot Value:        ${last_candle['supertrend']:,.2f}")
    print(f"  TradingView:      [Enter value from TradingView]")
    print()

    if 'ema_288' in df_5min.columns:
        print("5min 288 EMA:")
        print(f"  Bot Value:        ${last_5min['ema_288']:,.2f}")
        print(f"  TradingView:      [Enter value from TradingView]")
        print()

    print("="*80)
    print("Last 3 30m candles for reference:")
    print("="*80)
    for i in range(max(0, len(df_30m) - 3), len(df_30m)):
        candle = df_30m.iloc[i]
        timestamp_ist = candle['timestamp'] + timedelta(hours=5, minutes=30)
        st_dir = 'BULL' if candle['st_direction'] == 1 else 'BEAR'
        print(f"{timestamp_ist.strftime('%Y-%m-%d %H:%M')} | C: ${candle['close']:>9.2f} | ST: ${candle['supertrend']:>9.2f} | {st_dir}")
    print()

if __name__ == "__main__":
    main()
