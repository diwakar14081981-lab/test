#!/usr/bin/env python3
"""
Test script to verify mark price fetching works correctly
Tests the exact logic implemented in live_trading_bot_realtime.py
"""

import sys
sys.path.insert(0, 'D:\\Latest_Bot\\final_bot')

from live_trading_credentials import LIVE_API_KEY, LIVE_API_SECRET
from delta_rest_client import DeltaRestClient

print("="*70)
print("Testing Mark Price Fetch Implementation")
print("="*70)

# Initialize client
client = DeltaRestClient(
    base_url='https://api.india.delta.exchange',
    api_key=LIVE_API_KEY,
    api_secret=LIVE_API_SECRET
)

print("\n1. Getting a sample BTC option...")
try:
    # Get products
    response = client.request('GET', '/v2/products')
    data = response.json()

    if 'result' in data:
        products = data['result']

        # Find a live BTC option
        btc_options = [p for p in products
                      if 'BTC' in p.get('symbol', '')
                      and p.get('contract_type') in ['call_options', 'put_options']
                      and p.get('state') == 'live']

        if btc_options:
            sample = btc_options[0]
            product_id = sample.get('id')
            option_symbol = sample.get('symbol')

            print(f"   Found option: {option_symbol}")
            print(f"   Product ID: {product_id}")

            print("\n2. Testing mark price fetch (exact logic from bot)...")

            # EXACT IMPLEMENTATION FROM live_trading_bot_realtime.py
            option_mark_price = None
            try:
                # Fetch actual mark price using get_ticker() - NO FALLBACKS
                if client and product_id:
                    ticker_data = client.get_ticker(product_id)

                    # Parse response
                    if isinstance(ticker_data, dict):
                        # Check if 'result' key exists (wrapped response)
                        if 'result' in ticker_data:
                            mark_price_value = ticker_data['result'].get('mark_price')
                        else:
                            # Direct response
                            mark_price_value = ticker_data.get('mark_price')

                        if mark_price_value is not None:
                            option_mark_price = float(mark_price_value)
                        else:
                            print(f"   ERROR: Mark price not found in ticker response")
                    else:
                        print(f"   ERROR: Invalid ticker response type: {type(ticker_data)}")
                else:
                    print(f"   ERROR: Client not available or missing product_id")

            except Exception as e:
                print(f"   ERROR: Error fetching option mark price: {e}")

            # Display mark price (show ERROR if fetch failed - NO fake data)
            mark_display = f"${option_mark_price:,.2f}" if option_mark_price is not None else "ERROR"

            print(f"\n3. Result:")
            print(f"   Mark Price: {mark_display}")

            if option_mark_price is not None:
                print(f"\n   ✓ SUCCESS: Mark price fetched correctly!")
                print(f"   Raw value: {option_mark_price}")
            else:
                print(f"\n   ✗ FAILED: Could not fetch mark price")
        else:
            print("   No live BTC options found")
    else:
        print(f"   ERROR: Unexpected response structure")

except Exception as e:
    print(f"   ERROR: {e}")
    import traceback
    traceback.print_exc()

print("\n" + "="*70)
