#!/usr/bin/env python3
"""
Unit Test for Multi-Asset Options Support
Tests ETHUSD, BTCUSD, and SOLUSD options trading functionality
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from delta_options_manager import DeltaOptionsManager
from datetime import datetime, timedelta
import logging

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

def test_strike_intervals():
    """Test that strike intervals are correctly configured"""
    print("="*80)
    print("TEST 1: Strike Intervals Configuration")
    print("="*80)

    # Create mock manager (paper trading mode)
    manager = DeltaOptionsManager(
        api_key="test_key",
        api_secret="test_secret",
        paper_trading=True
    )

    # Test BTCUSD
    btc_strike = manager._find_atm_strike(91150.0, 'BTCUSD')
    assert btc_strike == 91200, f"BTCUSD strike failed: expected 91200, got {btc_strike}"
    print(f"[OK] BTCUSD @ $91,150 -> Strike: ${btc_strike:,} (interval: $200)")

    # Test ETHUSD
    eth_strike = manager._find_atm_strike(3990.0, 'ETHUSD')
    assert eth_strike == 4000, f"ETHUSD strike failed: expected 4000, got {eth_strike}"
    print(f"[OK] ETHUSD @ $3,990 -> Strike: ${eth_strike:,} (interval: $20, rounded to nearest)")

    eth_strike2 = manager._find_atm_strike(4012.0, 'ETHUSD')
    assert eth_strike2 == 4020, f"ETHUSD strike failed: expected 4020, got {eth_strike2}"
    print(f"[OK] ETHUSD @ $4,012 -> Strike: ${eth_strike2:,} (interval: $20)")

    # Test SOLUSD
    sol_strike = manager._find_atm_strike(242.3, 'SOLUSD')
    assert sol_strike == 240, f"SOLUSD strike failed: expected 240, got {sol_strike}"
    print(f"[OK] SOLUSD @ $242.3 -> Strike: ${sol_strike} (interval: $5)")

    print()
    return True


def test_expiry_time_logic():
    """Test expiry date selection based on current time"""
    print("="*80)
    print("TEST 2: Expiry Date Selection Logic")
    print("="*80)

    manager = DeltaOptionsManager(
        api_key="test_key",
        api_secret="test_secret",
        paper_trading=True
    )

    # Get current time
    now_utc = datetime.utcnow()
    now_ist = now_utc + timedelta(hours=5, minutes=30)
    current_hour = now_ist.hour

    expiry = manager._get_next_day_expiry()

    # Verify expiry time is always 17:30 (5:30 PM)
    assert expiry.hour == 17, f"Expiry hour should be 17, got {expiry.hour}"
    assert expiry.minute == 30, f"Expiry minute should be 30, got {expiry.minute}"

    # Check if expiry date logic is correct based on current time
    if current_hour < 15:  # Before 3 PM
        expected_date = now_ist.date()
        print(f"[OK] Current time: {now_ist.strftime('%H:%M')} IST (before 3 PM)")
        print(f"[OK] Using CURRENT DATE expiry: {expiry.strftime('%Y-%m-%d %H:%M')} IST")
    else:  # After 3 PM
        expected_date = now_ist.date() + timedelta(days=1)
        print(f"[OK] Current time: {now_ist.strftime('%H:%M')} IST (after 3 PM)")
        print(f"[OK] Using NEXT DAY expiry: {expiry.strftime('%Y-%m-%d %H:%M')} IST")

    assert expiry.date() == expected_date, f"Expiry date mismatch: expected {expected_date}, got {expiry.date()}"

    print()
    return True


def test_contract_specs():
    """Test contract size specifications and option price divisors"""
    print("="*80)
    print("TEST 3: Contract Size Specifications & Option Price Divisors")
    print("="*80)

    manager = DeltaOptionsManager(
        api_key="test_key",
        api_secret="test_secret",
        paper_trading=True
    )

    # Test BTCUSD (1000 lots = 1 BTC)
    btc_lots = manager._calculate_lots(10000.0, 91200.0, 'BTCUSD')
    btc_divisor = manager.OPTION_PRICE_DIVISOR.get('BTCUSD')
    print(f"[OK] BTCUSD: $10,000 @ $91,200 = {btc_lots} lots (0.001 BTC per lot, 1000 lots = 1 BTC)")
    print(f"[OK] BTCUSD Option Price Divisor: {btc_divisor} (option price quoted per {btc_divisor} lots)")

    # Test ETHUSD (100 lots = 1 ETH)
    eth_lots = manager._calculate_lots(10000.0, 4000.0, 'ETHUSD')
    eth_divisor = manager.OPTION_PRICE_DIVISOR.get('ETHUSD')
    assert eth_divisor == 100, f"ETH divisor should be 100, got {eth_divisor}"
    print(f"[OK] ETHUSD: $10,000 @ $4,000 = {eth_lots} lots (0.01 ETH per lot, 100 lots = 1 ETH)")
    print(f"[OK] ETHUSD Option Price Divisor: {eth_divisor} (option price quoted per {eth_divisor} lots)")

    # Test SOLUSD
    sol_lots = manager._calculate_lots(10000.0, 240.0, 'SOLUSD')
    sol_divisor = manager.OPTION_PRICE_DIVISOR.get('SOLUSD')
    print(f"[OK] SOLUSD: $10,000 @ $240 = {sol_lots} lots (1 SOL per lot)")
    print(f"[OK] SOLUSD Option Price Divisor: {sol_divisor} (option price quoted per {sol_divisor} lot)")

    print()
    return True


def test_position_storage_structure():
    """Test that position storage includes base_symbol"""
    print("="*80)
    print("TEST 4: Position Storage Structure")
    print("="*80)

    manager = DeltaOptionsManager(
        api_key="test_key",
        api_secret="test_secret",
        paper_trading=True
    )

    # Simulate position entry for ETHUSD
    # We'll manually create a position to test structure
    test_position = {
        'type': 'call',
        'symbol': 'C-ETH-4000-251120',  # Option symbol
        'base_symbol': 'ETHUSD',  # Trading pair symbol
        'product_id': 12345,
        'strike': 4000,
        'lots': 2500,
        'entry_price': 3990.0,
        'entry_time': datetime.now(),
        'expiry': datetime.now() + timedelta(days=1)
    }

    manager.current_position = test_position

    # Verify structure
    assert 'base_symbol' in manager.current_position, "Position missing 'base_symbol' field"
    assert manager.current_position['base_symbol'] == 'ETHUSD', "base_symbol should be 'ETHUSD'"
    assert manager.current_position['symbol'] == 'C-ETH-4000-251120', "Option symbol mismatch"

    print(f"[OK] Position structure correct:")
    print(f"  Option Symbol: {manager.current_position['symbol']}")
    print(f"  Base Symbol:   {manager.current_position['base_symbol']}")
    print(f"  Strike:        ${manager.current_position['strike']}")
    print(f"  Lots:          {manager.current_position['lots']}")

    # Test contract size retrieval
    base_symbol = manager.current_position.get('base_symbol', 'BTCUSD')
    contract_size = manager.CONTRACT_SPECS.get(base_symbol, 0.001)

    assert base_symbol == 'ETHUSD', "Failed to retrieve base_symbol from position"
    assert contract_size == 0.01, f"Wrong contract size for ETH: expected 0.01, got {contract_size}"

    print(f"[OK] Contract size lookup: {contract_size} ETH per lot (100 lots = 1 ETH)")

    # Clear position
    manager.current_position = None

    print()
    return True


def test_base_asset_extraction():
    """Test base asset extraction from trading symbols"""
    print("="*80)
    print("TEST 5: Base Asset Extraction")
    print("="*80)

    test_cases = [
        ('BTCUSD', 'BTC'),
        ('ETHUSD', 'ETH'),
        ('SOLUSD', 'SOL'),
    ]

    for symbol, expected_base in test_cases:
        base_asset = symbol.replace('USD', '')
        assert base_asset == expected_base, f"Failed to extract base from {symbol}: expected {expected_base}, got {base_asset}"
        print(f"[OK] {symbol} -> {base_asset}")

    print()
    return True


def test_close_position_contract_size():
    """Test that close_position uses correct contract size from base_symbol"""
    print("="*80)
    print("TEST 6: Close Position Contract Size Handling")
    print("="*80)

    manager = DeltaOptionsManager(
        api_key="test_key",
        api_secret="test_secret",
        paper_trading=True
    )

    # Test with ETHUSD position (100 lots = 1 ETH)
    eth_position = {
        'type': 'put',
        'symbol': 'P-ETH-3980-251120',
        'base_symbol': 'ETHUSD',  # This is the key field
        'product_id': 12345,
        'strike': 3980,
        'lots': 250,  # 250 lots = 2.5 ETH
        'entry_price': 100.0,  # Option premium
        'entry_time': datetime.now(),
        'expiry': datetime.now() + timedelta(days=1)
    }

    manager.current_position = eth_position

    # Simulate close (paper trading)
    result = manager.close_position(symbol=None)

    # Verify the result used correct contract specs
    assert result['success'] != False or 'filled_size' in result, "Close position failed"

    # Calculate expected size (100 lots = 1 ETH, so 250 lots = 2.5 ETH)
    expected_contract_size = 0.01  # ETH contract size (1 lot = 0.01 ETH)
    expected_size = 250 * expected_contract_size  # 250 * 0.01 = 2.5 ETH

    if 'filled_size' in result:
        assert result['filled_size'] == expected_size, f"Wrong filled size: expected {expected_size}, got {result['filled_size']}"
        print(f"[OK] ETHUSD close position:")
        print(f"  Lots:          {eth_position['lots']}")
        print(f"  Contract Size: {expected_contract_size} ETH per lot")
        print(f"  Filled Size:   {result['filled_size']} ETH")

    # Test with BTCUSD position
    manager.current_position = {
        'type': 'call',
        'symbol': 'C-BTC-91200-251120',
        'base_symbol': 'BTCUSD',
        'product_id': 67890,
        'strike': 91200,
        'lots': 109,
        'entry_price': 1000.0,
        'entry_time': datetime.now(),
        'expiry': datetime.now() + timedelta(days=1)
    }

    result = manager.close_position(symbol=None)

    expected_contract_size_btc = 0.001
    expected_size_btc = 109 * expected_contract_size_btc

    if 'filled_size' in result:
        assert result['filled_size'] == expected_size_btc, f"Wrong filled size for BTC: expected {expected_size_btc}, got {result['filled_size']}"
        print(f"[OK] BTCUSD close position:")
        print(f"  Lots:          109")
        print(f"  Contract Size: {expected_contract_size_btc} BTC")
        print(f"  Filled Size:   {result['filled_size']} BTC")

    print()
    return True


def run_all_tests():
    """Run all unit tests"""
    print()
    print("="*80)
    print("MULTI-ASSET OPTIONS MANAGER - UNIT TESTS")
    print("="*80)
    print()

    tests = [
        ("Strike Intervals", test_strike_intervals),
        ("Expiry Time Logic", test_expiry_time_logic),
        ("Contract Specifications", test_contract_specs),
        ("Position Storage Structure", test_position_storage_structure),
        ("Base Asset Extraction", test_base_asset_extraction),
        ("Close Position Contract Size", test_close_position_contract_size),
    ]

    passed = 0
    failed = 0
    errors = []

    for test_name, test_func in tests:
        try:
            if test_func():
                passed += 1
            else:
                failed += 1
                errors.append(f"{test_name}: Test returned False")
        except AssertionError as e:
            failed += 1
            errors.append(f"{test_name}: {str(e)}")
            print(f"[FAILED] {test_name}: {str(e)}")
            print()
        except Exception as e:
            failed += 1
            errors.append(f"{test_name}: Unexpected error: {str(e)}")
            print(f"[ERROR] {test_name}: {str(e)}")
            import traceback
            traceback.print_exc()
            print()

    # Summary
    print("="*80)
    print("TEST SUMMARY")
    print("="*80)
    print(f"Total Tests: {passed + failed}")
    print(f"Passed:      {passed}")
    print(f"Failed:      {failed}")
    print()

    if failed > 0:
        print("FAILED TESTS:")
        for error in errors:
            print(f"  - {error}")
        print()
        return False
    else:
        print("[SUCCESS] All tests passed!")
        print()
        return True


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
