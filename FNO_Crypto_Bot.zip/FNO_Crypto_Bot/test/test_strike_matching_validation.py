#!/usr/bin/env python3
"""
Comprehensive validation of option matching logic
Ensures data type mismatches cannot occur
"""

import sys
sys.path.insert(0, 'D:\\Latest_Bot\\final_bot')

from live_trading_credentials import LIVE_API_KEY, LIVE_API_SECRET
from delta_options_manager import DeltaOptionsManager
from datetime import datetime, timedelta

print("="*70)
print("COMPREHENSIVE OPTION MATCHING VALIDATION")
print("="*70)

manager = DeltaOptionsManager(LIVE_API_KEY, LIVE_API_SECRET, paper_trading=True)

# Get options
options = manager._get_btc_options()
print(f"\nFetched {len(options)} options from Delta Exchange")

# Check data types from API
if options:
    sample = options[0]
    strike_price = sample.get('strike_price')
    print(f"\n1. DATA TYPE CHECK:")
    print(f"   Sample option: {sample.get('symbol')}")
    print(f"   strike_price value: {strike_price}")
    print(f"   strike_price type: {type(strike_price)}")
    print(f"   Is int? {isinstance(strike_price, int)}")
    print(f"   Is str? {isinstance(strike_price, str)}")

# Test matching with known option
print(f"\n2. MATCHING TEST:")
print(f"   Looking for: Strike=93000 (int), Type=put, Expiry=2025-11-20")

expiry = datetime(2025, 11, 20, 17, 30)
result = manager._find_option_product(93000, 'put', expiry)

if result:
    print(f"   SUCCESS: Found {result.get('symbol')}")
    print(f"   Product ID: {result.get('id')}")
    print(f"   Strike from result: {result.get('strike_price')} (type: {type(result.get('strike_price'))})")
else:
    print(f"   FAILED: Option not found")

# Test with CALL
print(f"\n3. CALL OPTION TEST:")
result_call = manager._find_option_product(93000, 'call', expiry)

if result_call:
    print(f"   SUCCESS: Found {result_call.get('symbol')}")
    print(f"   Product ID: {result_call.get('id')}")
else:
    print(f"   FAILED: Call option not found")

# Test edge cases
print(f"\n4. EDGE CASE TESTS:")

# Test with strike that doesn't exist
result_invalid = manager._find_option_product(99999999, 'put', expiry)
print(f"   Invalid strike (99999999): {'Found' if result_invalid else 'Not found (CORRECT)'}")

# Test with future expiry that doesn't exist
future_expiry = datetime(2030, 1, 1, 17, 30)
result_future = manager._find_option_product(93000, 'put', future_expiry)
print(f"   Future expiry (2030-01-01): {'Found' if result_future else 'Not found (CORRECT)'}")

print(f"\n5. TYPE SAFETY VERIFICATION:")
# Manually verify the comparison logic
test_strike_int = 93000
test_strike_str = "93000"

print(f"   int == int: {93000 == 93000} (CORRECT)")
print(f"   int == str: {93000 == '93000'} (Should be False)")
print(f"   str == str: {'93000' == '93000'} (Would work but inconsistent)")

print("\n" + "="*70)
print("VALIDATION COMPLETE")
print("="*70)
