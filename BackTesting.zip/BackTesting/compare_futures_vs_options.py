"""
Compare Futures vs Options Strategy
Uses exact same entry/exit signals, just different instruments
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from option_pricing import (
    black_scholes, calculate_implied_volatility_from_historical,
    find_atm_strike, get_next_friday_expiry, time_to_expiry_years
)

def convert_futures_trades_to_options(futures_trades_csv, df_5min_path):
    """
    Convert futures trades to options trades using same signals

    For each futures trade:
    - LONG → Sell ATM Put
    - SHORT → Sell ATM Call
    - Entry/Exit at exact same time
    - Calculate option prices using Black-Scholes
    """

    # Load futures trades
    futures_trades = pd.read_csv(futures_trades_csv)
    futures_trades['entry_time_ist'] = pd.to_datetime(futures_trades['entry_time_ist'])
    futures_trades['exit_time_ist'] = pd.to_datetime(futures_trades['exit_time_ist'])

    # Load 5-min data for volatility calculation
    df_5min = pd.read_csv(df_5min_path)
    if 'datetime' in df_5min.columns:
        df_5min['timestamp'] = pd.to_datetime(df_5min['datetime'])
    else:
        df_5min['timestamp'] = pd.to_datetime(df_5min['timestamp'], unit='s')

    # Risk-free rate
    risk_free_rate = 0.05
    strike_interval = 500  # BTC strikes

    options_trades = []

    print(f"\nProcessing {len(futures_trades)} futures trades...")
    print("Converting to options trades with same entry/exit timing...\n")

    for idx, trade in futures_trades.iterrows():
        direction = trade['direction']
        entry_time_ist = trade['entry_time_ist']
        exit_time_ist = trade['exit_time_ist']
        entry_price = trade['entry_price']
        exit_price = trade['exit_price']

        # Convert IST to UTC
        entry_time_utc = entry_time_ist - timedelta(hours=5, minutes=30)
        exit_time_utc = exit_time_ist - timedelta(hours=5, minutes=30)

        # Determine option type
        if direction == 'LONG':
            option_type = 'put'  # Sell put when bullish
        else:  # SHORT
            option_type = 'call'  # Sell call when bearish

        # Find ATM strike based on entry price
        strike = find_atm_strike(entry_price, strike_interval)

        # Get expiry (next Friday)
        expiry_time = get_next_friday_expiry(entry_time_utc)

        # Calculate time to expiry at entry
        tte_entry = time_to_expiry_years(entry_time_utc, expiry_time)

        # Calculate historical volatility at entry
        df_history = df_5min[df_5min['timestamp'] <= entry_time_utc]
        if len(df_history) < 30 * 288:  # Need at least 30 days
            volatility = 0.6  # Default 60% IV for BTC
        else:
            volatility = calculate_implied_volatility_from_historical(
                df_history.tail(30 * 288), lookback_days=30
            )

        # Calculate option premium at entry (what we receive)
        entry_premium = black_scholes(
            S=entry_price,
            K=strike,
            T=tte_entry,
            r=risk_free_rate,
            sigma=volatility,
            option_type=option_type
        )

        # Calculate time to expiry at exit
        tte_exit = time_to_expiry_years(exit_time_utc, expiry_time)

        # Calculate option price at exit (what we pay to buy back)
        exit_premium = black_scholes(
            S=exit_price,
            K=strike,
            T=tte_exit,
            r=risk_free_rate,
            sigma=volatility,
            option_type=option_type
        )

        # Position sizing (same $5000 notional)
        position_size_usd = 5000
        num_contracts = position_size_usd / strike

        # Calculate P&L
        premium_received = entry_premium * num_contracts
        buyback_cost = exit_premium * num_contracts
        gross_pnl = premium_received - buyback_cost

        # Commission (0.05% on entry and exit)
        commission_rate = 0.0005
        entry_commission = premium_received * commission_rate
        exit_commission = buyback_cost * commission_rate
        total_commission = entry_commission + exit_commission

        net_pnl = gross_pnl - total_commission
        pnl_pct = (net_pnl / premium_received) * 100 if premium_received > 0 else 0

        # Hold time
        hold_time = trade['hold_time_minutes']

        options_trades.append({
            'entry_time_ist': entry_time_ist,
            'exit_time_ist': exit_time_ist,
            'option_type': option_type.upper(),
            'direction_equivalent': direction,
            'strike': strike,
            'spot_at_entry': entry_price,
            'spot_at_exit': exit_price,
            'volatility': volatility,
            'tte_entry_days': tte_entry * 365,
            'tte_exit_days': tte_exit * 365,
            'premium_received': premium_received,
            'buyback_cost': buyback_cost,
            'exit_reason': trade['exit_reason'],
            'hold_time_minutes': hold_time,
            'gross_pnl': gross_pnl,
            'commission': total_commission,
            'net_pnl': net_pnl,
            'pnl_pct': pnl_pct,
            'futures_pnl': trade['net_pnl']  # For comparison
        })

    return pd.DataFrame(options_trades)


def analyze_options_results(options_df):
    """Analyze options trading results"""

    total_trades = len(options_df)
    winning_trades = len(options_df[options_df['net_pnl'] > 0])
    losing_trades = len(options_df[options_df['net_pnl'] <= 0])
    win_rate = (winning_trades / total_trades * 100) if total_trades > 0 else 0

    total_pnl = options_df['net_pnl'].sum()
    gross_profit = options_df[options_df['net_pnl'] > 0]['net_pnl'].sum()
    gross_loss = abs(options_df[options_df['net_pnl'] <= 0]['net_pnl'].sum())

    profit_factor = (gross_profit / gross_loss) if gross_loss > 0 else 0

    avg_win = options_df[options_df['net_pnl'] > 0]['net_pnl'].mean() if winning_trades > 0 else 0
    avg_loss = options_df[options_df['net_pnl'] <= 0]['net_pnl'].mean() if losing_trades > 0 else 0

    # Calculate drawdown
    cumulative_pnl = options_df['net_pnl'].cumsum()
    running_max = cumulative_pnl.expanding().max()
    drawdown = running_max - cumulative_pnl
    max_drawdown = drawdown.max()

    initial_capital = 10000
    max_drawdown_pct = (max_drawdown / initial_capital) * 100

    final_equity = initial_capital + total_pnl

    return {
        'total_trades': total_trades,
        'winning_trades': winning_trades,
        'losing_trades': losing_trades,
        'win_rate': win_rate,
        'total_pnl': total_pnl,
        'gross_profit': gross_profit,
        'gross_loss': gross_loss,
        'profit_factor': profit_factor,
        'avg_win': avg_win,
        'avg_loss': avg_loss,
        'max_drawdown': max_drawdown,
        'max_drawdown_pct': max_drawdown_pct,
        'final_equity': final_equity
    }


if __name__ == '__main__':
    # Paths
    futures_trades_csv = 'D:/Latest_Bot/latest_reports/BTC/trades_BTCUSD_Q4_2025.csv'
    df_5min_path = 'D:/Latest_Bot/Data/BTC/Q4_2025/BTC_5min_Q4_2025.csv'
    output_csv = 'D:/Latest_Bot/latest_reports/BTC/trades_options_BTCUSD_Q4_2025_v2.csv'
    output_summary = 'D:/Latest_Bot/latest_reports/BTC/summary_options_BTCUSD_Q4_2025_v2.txt'

    print("="*80)
    print("FUTURES vs OPTIONS COMPARISON - BTC Q4 2025")
    print("="*80)
    print("Using EXACT same entry/exit signals for both strategies")
    print("="*80)

    # Convert futures trades to options
    options_df = convert_futures_trades_to_options(futures_trades_csv, df_5min_path)

    # Analyze results
    options_stats = analyze_options_results(options_df)

    # Load futures stats
    futures_df = pd.read_csv(futures_trades_csv)
    futures_pnl = futures_df['net_pnl'].sum()
    futures_win_rate = (len(futures_df[futures_df['net_pnl'] > 0]) / len(futures_df)) * 100

    # Print comparison
    print("\n" + "="*80)
    print("RESULTS COMPARISON")
    print("="*80)

    print(f"\n{'Metric':<30} {'Futures':>20} {'Options':>20} {'Difference':>20}")
    print("-"*95)

    print(f"{'Total Trades':<30} {len(futures_df):>20} {options_stats['total_trades']:>20} {options_stats['total_trades'] - len(futures_df):>20}")
    print(f"{'Win Rate (%)':<30} {futures_win_rate:>20.2f} {options_stats['win_rate']:>20.2f} {options_stats['win_rate'] - futures_win_rate:>19.2f}")
    print(f"{'Total P&L ($)':<30} ${futures_pnl:>19,.2f} ${options_stats['total_pnl']:>19,.2f} ${options_stats['total_pnl'] - futures_pnl:>18,.2f}")

    futures_pf = (futures_df[futures_df['net_pnl'] > 0]['net_pnl'].sum() /
                  abs(futures_df[futures_df['net_pnl'] <= 0]['net_pnl'].sum()))
    print(f"{'Profit Factor':<30} {futures_pf:>20.2f} {options_stats['profit_factor']:>20.2f} {options_stats['profit_factor'] - futures_pf:>19.2f}")

    print(f"{'Max Drawdown (%)':<30} {1.06:>19.2f}% {options_stats['max_drawdown_pct']:>19.2f}% {options_stats['max_drawdown_pct'] - 1.06:>18.2f}%")
    print(f"{'Final Equity ($)':<30} ${11651.84:>19,.2f} ${options_stats['final_equity']:>19,.2f} ${options_stats['final_equity'] - 11651.84:>18,.2f}")

    print("="*95)

    # Save options trades
    options_df.to_csv(output_csv, index=False)
    print(f"\nOptions trades saved to: {output_csv}")

    # Save summary
    with open(output_summary, 'w') as f:
        f.write("="*80 + "\n")
        f.write("OPTIONS STRATEGY - BACKTEST SUMMARY (Using Futures Signals)\n")
        f.write("="*80 + "\n")
        f.write(f"Symbol: BTCUSD\n")
        f.write(f"Period: Q4 2025 (Oct 1 - Nov 18, 2025)\n")
        f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write("="*80 + "\n\n")
        f.write("Strategy: Sell ATM Options\n")
        f.write("  - LONG signal -> Sell ATM Put\n")
        f.write("  - SHORT signal -> Sell ATM Call\n")
        f.write("  - Entry/Exit timing: Exact same as futures\n\n")
        f.write("Overall Performance:\n")
        f.write(f"  Total Trades: {options_stats['total_trades']}\n")
        f.write(f"  Winning Trades: {options_stats['winning_trades']} ({options_stats['win_rate']:.2f}%)\n")
        f.write(f"  Losing Trades: {options_stats['losing_trades']}\n")
        f.write(f"  Total P&L: ${options_stats['total_pnl']:.2f}\n")
        f.write(f"  Gross Profit: ${options_stats['gross_profit']:.2f}\n")
        f.write(f"  Gross Loss: ${options_stats['gross_loss']:.2f}\n")
        f.write(f"  Profit Factor: {options_stats['profit_factor']:.2f}\n")
        f.write(f"  Average Win: ${options_stats['avg_win']:.2f}\n")
        f.write(f"  Average Loss: ${options_stats['avg_loss']:.2f}\n")
        f.write(f"  Max Drawdown: ${options_stats['max_drawdown']:.2f} ({options_stats['max_drawdown_pct']:.2f}%)\n")
        f.write(f"  Final Equity: ${options_stats['final_equity']:.2f}\n")

    print(f"Summary saved to: {output_summary}")
    print("="*80)
