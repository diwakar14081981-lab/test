"""
Test BTC Q4 2025 (Oct 1 - Nov 18, 2025) with different SuperTrend timeframes
"""

from run_backtest_config import get_default_config, run_backtest

# Base data paths
base_paths = {
    '1min': 'D:/Latest_Bot/Data/BTC/Q4_2025/BTC_1min_Q4_2025.csv',
    '5min': 'D:/Latest_Bot/Data/BTC/Q4_2025/BTC_5min_Q4_2025.csv',
}

results = []

print("\n" + "="*80)
print("BTC Q4 2025 - SUPERTREND TIMEFRAME COMPARISON")
print("="*80)

# Test 1: 30-min SuperTrend
print("\n[1/3] Testing 30-min SuperTrend...")
config_30m = get_default_config()
config_30m['TRADING_SYMBOL'] = 'BTCUSD'
config_30m['SUPERTREND_TIMEFRAME'] = '30m'
config_30m['ADX_THRESHOLD'] = 26
config_30m['BACKTEST_QUARTER'] = 'Q4'
config_30m['BACKTEST_YEAR'] = '2025'

data_paths_30m = base_paths.copy()
data_paths_30m['30min'] = 'D:/Latest_Bot/Data/BTC/Q4_2025/BTC_30min_Q4_2025.csv'

bt_30m = run_backtest(config_30m, data_paths_30m, 'BTC Q4 2025 - 30min ST')
results.append(('30-min ST', bt_30m))

# Test 2: 4-hour SuperTrend
print("\n[2/3] Testing 4-hour SuperTrend...")
config_4h = get_default_config()
config_4h['TRADING_SYMBOL'] = 'BTCUSD'
config_4h['SUPERTREND_TIMEFRAME'] = '4h'
config_4h['ADX_THRESHOLD'] = 26
config_4h['BACKTEST_QUARTER'] = 'Q4'
config_4h['BACKTEST_YEAR'] = '2025'

data_paths_4h = base_paths.copy()
data_paths_4h['30min'] = 'D:/Latest_Bot/Data/BTC/Q4_2025/BTC_4hour_Q4_2025.csv'

bt_4h = run_backtest(config_4h, data_paths_4h, 'BTC Q4 2025 - 4hour ST')
results.append(('4-hour ST', bt_4h))

# Test 3: 1-day SuperTrend
print("\n[3/3] Testing 1-day SuperTrend...")
config_1d = get_default_config()
config_1d['TRADING_SYMBOL'] = 'BTCUSD'
config_1d['SUPERTREND_TIMEFRAME'] = '1d'
config_1d['ADX_THRESHOLD'] = 26
config_1d['BACKTEST_QUARTER'] = 'Q4'
config_1d['BACKTEST_YEAR'] = '2025'

data_paths_1d = base_paths.copy()
data_paths_1d['30min'] = 'D:/Latest_Bot/Data/BTC/Q4_2025/BTC_1day_Q4_2025.csv'

bt_1d = run_backtest(config_1d, data_paths_1d, 'BTC Q4 2025 - 1day ST')
results.append(('1-day ST', bt_1d))

# Summary comparison
print("\n" + "="*80)
print("SUMMARY COMPARISON - BTC Q4 2025")
print("="*80)

print(f"\n{'Metric':<25} {'30-min ST':>20} {'4-hour ST':>20} {'1-day ST':>20}")
print("-"*90)

metrics = [
    ('Total Trades', lambda bt: bt.stats['total_trades']),
    ('Win Rate (%)', lambda bt: (bt.stats['winning_trades'] / bt.stats['total_trades'] * 100) if bt.stats['total_trades'] > 0 else 0),
    ('Total P&L ($)', lambda bt: bt.stats['total_pnl']),
    ('Profit Factor', lambda bt: (bt.stats['gross_profit'] / bt.stats['gross_loss']) if bt.stats['gross_loss'] > 0 else 0),
    ('Max Drawdown ($)', lambda bt: bt.stats['max_drawdown']),
    ('Max Drawdown (%)', lambda bt: bt.stats['max_drawdown_pct']),
]

for metric_name, metric_func in metrics:
    print(f"{metric_name:<25}", end='')
    for label, bt in results:
        value = metric_func(bt)
        if 'P&L' in metric_name or 'Drawdown $' in metric_name:
            print(f"${value:>19,.2f}", end='')
        elif '%' in metric_name:
            print(f"{value:>19.2f}%", end='')
        elif 'Factor' in metric_name:
            print(f"{value:>20.2f}", end='')
        else:
            print(f"{int(value):>20}", end='')
    print()

print("="*90)
print(f"\nReports saved in: D:\\Latest_Bot\\latest_reports\\BTC\\")
print("="*80)
