"""
Compare Futures vs Options for Ethereum Q3 2025
"""
import sys
sys.path.append('D:/Latest_Bot/BackTesting')
from compare_futures_vs_options import convert_futures_trades_to_options, analyze_options_results
import pandas as pd
from datetime import datetime

# Paths
futures_trades_csv = 'D:/Latest_Bot/latest_reports/ETH/trades_ETHUSD_Q3_2025.csv'
df_5min_path = 'D:/Latest_Bot/Data/Ethereum/Q3_2025/Ethereum_5min_Q3_2025.csv'
output_csv = 'D:/Latest_Bot/latest_reports/ETH/trades_options_ETHUSD_Q3_2025.csv'
output_summary = 'D:/Latest_Bot/latest_reports/ETH/summary_options_ETHUSD_Q3_2025.txt'

print("="*80)
print("ETHEREUM Q3 2025 - FUTURES vs OPTIONS COMPARISON")
print("="*80)
print("Using EXACT same entry/exit signals for both strategies")
print("="*80)

# Convert futures trades to options
options_df = convert_futures_trades_to_options(futures_trades_csv, df_5min_path)

# Analyze results
options_stats = analyze_options_results(options_df)

# Load futures stats
futures_df = pd.read_csv(futures_trades_csv)
futures_pnl = futures_df['net_pnl'].sum()
futures_win_rate = (len(futures_df[futures_df['net_pnl'] > 0]) / len(futures_df)) * 100
futures_gross_profit = futures_df[futures_df['net_pnl'] > 0]['net_pnl'].sum()
futures_gross_loss = abs(futures_df[futures_df['net_pnl'] <= 0]['net_pnl'].sum())
futures_pf = futures_gross_profit / futures_gross_loss if futures_gross_loss > 0 else 0

# Print comparison
print("\n" + "="*80)
print("RESULTS COMPARISON")
print("="*80)

print(f"\n{'Metric':<30} {'Futures':>20} {'Options':>20} {'Difference':>20}")
print("-"*95)

print(f"{'Total Trades':<30} {len(futures_df):>20} {options_stats['total_trades']:>20} {options_stats['total_trades'] - len(futures_df):>20}")
print(f"{'Win Rate (%)':<30} {futures_win_rate:>20.2f} {options_stats['win_rate']:>20.2f} {options_stats['win_rate'] - futures_win_rate:>19.2f}")
print(f"{'Total P&L ($)':<30} ${futures_pnl:>19,.2f} ${options_stats['total_pnl']:>19,.2f} ${options_stats['total_pnl'] - futures_pnl:>18,.2f}")
print(f"{'Profit Factor':<30} {futures_pf:>20.2f} {options_stats['profit_factor']:>20.2f} {options_stats['profit_factor'] - futures_pf:>19.2f}")
print(f"{'Max Drawdown (%)':<30} {2.39:>19.2f}% {options_stats['max_drawdown_pct']:>19.2f}% {options_stats['max_drawdown_pct'] - 2.39:>18.2f}%")
print(f"{'Final Equity ($)':<30} ${10000 + futures_pnl:>19,.2f} ${options_stats['final_equity']:>19,.2f} ${options_stats['final_equity'] - (10000 + futures_pnl):>18,.2f}")

print("="*95)

# Save options trades
options_df.to_csv(output_csv, index=False)
print(f"\nOptions trades saved to: {output_csv}")

# Save summary
with open(output_summary, 'w') as f:
    f.write("="*80 + "\n")
    f.write("OPTIONS STRATEGY - BACKTEST SUMMARY (Using Futures Signals)\n")
    f.write("="*80 + "\n")
    f.write(f"Symbol: ETHUSD\n")
    f.write(f"Period: Q3 2025 (Jul-Sep 2025)\n")
    f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    f.write("="*80 + "\n\n")
    f.write("Strategy: Sell ATM Options\n")
    f.write("  - LONG signal -> Sell ATM Put\n")
    f.write("  - SHORT signal -> Sell ATM Call\n")
    f.write("  - Entry/Exit timing: Exact same as futures\n\n")
    f.write("Overall Performance:\n")
    f.write(f"  Total Trades: {options_stats['total_trades']}\n")
    f.write(f"  Winning Trades: {options_stats['winning_trades']} ({options_stats['win_rate']:.2f}%)\n")
    f.write(f"  Losing Trades: {options_stats['losing_trades']}\n")
    f.write(f"  Total P&L: ${options_stats['total_pnl']:.2f}\n")
    f.write(f"  Gross Profit: ${options_stats['gross_profit']:.2f}\n")
    f.write(f"  Gross Loss: ${options_stats['gross_loss']:.2f}\n")
    f.write(f"  Profit Factor: {options_stats['profit_factor']:.2f}\n")
    f.write(f"  Average Win: ${options_stats['avg_win']:.2f}\n")
    f.write(f"  Average Loss: ${options_stats['avg_loss']:.2f}\n")
    f.write(f"  Max Drawdown: ${options_stats['max_drawdown']:.2f} ({options_stats['max_drawdown_pct']:.2f}%)\n")
    f.write(f"  Final Equity: ${options_stats['final_equity']:.2f}\n")

print(f"Summary saved to: {output_summary}")
print("="*80)
