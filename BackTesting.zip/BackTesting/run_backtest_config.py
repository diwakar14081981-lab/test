"""
Configurable Backtest Runner
Run backtests with custom parameters for any asset and time period
"""

import os
import sys
import json
from datetime import datetime
from swing_strategy_backtest import SwingStrategyBacktest

# =============================================================================
# BACKTEST CONFIGURATION
# =============================================================================

def get_default_config():
    """
    Returns default strategy configuration
    Modify these parameters to test different strategy variations
    """
    return {
        # Asset and Timeframes
        'TRADING_SYMBOL': 'SOLUSD',           # Asset to trade (BTCUSD, ETHUSD, SOLUSD)
        'ENTRY_TIMEFRAME': '5min',            # Entry signal timeframe (fixed at 5min)
        'SUPERTREND_TIMEFRAME': '30m',        # SuperTrend timeframe (30m or 1h)

        # Filter Toggles
        'USE_288_EMA_FILTER': True,           # Enable/disable 288 EMA filter
        'USE_SUPERTREND_FILTER': True,        # Enable/disable SuperTrend filter
        'USE_ADX_FILTER': True,               # Enable/disable ADX filter
        'USE_MARUBOZU_FILTER': False,         # Enable/disable Marubozu candle filter

        # Swing Point Settings
        'SWING_LOOKBACK_CANDLES': 4,          # Swing identification lookback period
        'SWING_CONFIRMATION_CANDLES': 3,      # Swing confirmation period

        # SuperTrend Parameters
        'SUPERTREND_PERIOD': 10,              # ATR period for SuperTrend
        'SUPERTREND_MULTIPLIER': 3.0,         # ATR multiplier for SuperTrend bands

        # ADX Parameters
        'ADX_PERIOD': 14,                     # ADX calculation period
        'ADX_THRESHOLD': 26,                  # Minimum ADX for trade entry

        # Marubozu Parameters (if enabled)
        'FIRST_CANDLE_MIN_BODY_PERCENTAGE': 60,  # Minimum body % for Marubozu

        # Risk Management
        'STOP_LOSS_BUFFER_PCT': 0.15,        # Stop loss buffer (0.15% = 15 pips)
        'MAX_STOP_LOSS_PCT': 1.5,            # Maximum risk per trade (1.5%)

        # Position Sizing
        'POSITION_SIZE_DOLLARS': 5000,        # Dollar amount per trade
        'LEVERAGE': 1,                        # Leverage multiplier
        'ACCOUNT_SIZE': 10000,                # Initial account size

        # Trading Costs
        'COMMISSION_RATE': 0.0005,            # Commission per trade (0.05%)

        # Cooldown
        'COOLDOWN_PERIOD_SECONDS': 600        # Cooldown after exit (10 minutes)
    }


def get_data_paths(asset, quarter, year, data_root='D:/Latest_Bot/Data'):
    """
    Get file paths for historical data

    Args:
        asset: Asset name (BTC, Ethereum, Solana)
        quarter: Quarter (Q1, Q2, Q3, Q4)
        year: Year (2024, 2025)
        data_root: Root directory for data files

    Returns:
        dict with paths to 1min, 5min, and 30min data files
    """
    asset_dir = os.path.join(data_root, asset, f'{quarter}_{year}')

    return {
        '1min': os.path.join(asset_dir, f'{asset}_1min_{quarter}_{year}.csv'),
        '5min': os.path.join(asset_dir, f'{asset}_5min_{quarter}_{year}.csv'),
        '30min': os.path.join(asset_dir, f'{asset}_30min_{quarter}_{year}.csv')
    }


def run_backtest(config, data_paths, description=""):
    """
    Run a single backtest with given configuration

    Args:
        config: Configuration dictionary
        data_paths: Dictionary with paths to data files
        description: Optional description of this backtest run

    Returns:
        SwingStrategyBacktest object with results
    """
    print("\n" + "="*80)
    print("STARTING BACKTEST")
    print("="*80)
    if description:
        print(f"Description: {description}")
    print(f"Asset: {config['TRADING_SYMBOL']}")
    print(f"Data: {os.path.basename(data_paths['1min'])}")
    print("="*80)

    # Initialize backtest
    backtest = SwingStrategyBacktest(config)

    # Load data
    backtest.load_data(
        data_1min_path=data_paths['1min'],
        data_5min_path=data_paths.get('5min'),
        data_30min_path=data_paths.get('30min')
    )

    # Calculate indicators
    backtest.calculate_indicators()

    # Run simulation
    backtest.run()

    return backtest


# =============================================================================
# PRE-CONFIGURED TEST SCENARIOS
# =============================================================================

def scenario_solana_q1_2025_default():
    """Solana Q1 2025 with default settings"""
    config = get_default_config()
    config['TRADING_SYMBOL'] = 'SOLUSD'

    data_paths = get_data_paths('Solana', 'Q1', '2025')

    return run_backtest(
        config,
        data_paths,
        description="Solana Q1 2025 - Default Settings (All Filters Enabled)"
    )


def scenario_btc_q1_2025_default():
    """Bitcoin Q1 2025 with default settings"""
    config = get_default_config()
    config['TRADING_SYMBOL'] = 'BTCUSD'

    data_paths = get_data_paths('BTC', 'Q1', '2025')

    return run_backtest(
        config,
        data_paths,
        description="Bitcoin Q1 2025 - Default Settings"
    )


def scenario_eth_q1_2025_default():
    """Ethereum Q1 2025 with default settings"""
    config = get_default_config()
    config['TRADING_SYMBOL'] = 'ETHUSD'

    data_paths = get_data_paths('Ethereum', 'Q1', '2025')

    return run_backtest(
        config,
        data_paths,
        description="Ethereum Q1 2025 - Default Settings"
    )


def scenario_solana_no_adx():
    """Test without ADX filter"""
    config = get_default_config()
    config['TRADING_SYMBOL'] = 'SOLUSD'
    config['USE_ADX_FILTER'] = False

    data_paths = get_data_paths('Solana', 'Q1', '2025')

    return run_backtest(
        config,
        data_paths,
        description="Solana Q1 2025 - NO ADX Filter"
    )


def scenario_solana_adx_31():
    """Test with ADX threshold = 31"""
    config = get_default_config()
    config['TRADING_SYMBOL'] = 'SOLUSD'
    config['ADX_THRESHOLD'] = 31

    data_paths = get_data_paths('Solana', 'Q1', '2025')

    return run_backtest(
        config,
        data_paths,
        description="Solana Q1 2025 - ADX Threshold = 31"
    )


def scenario_solana_no_ema():
    """Test without 288 EMA filter"""
    config = get_default_config()
    config['TRADING_SYMBOL'] = 'SOLUSD'
    config['USE_288_EMA_FILTER'] = False

    data_paths = get_data_paths('Solana', 'Q1', '2025')

    return run_backtest(
        config,
        data_paths,
        description="Solana Q1 2025 - NO 288 EMA Filter"
    )


def scenario_solana_1h_supertrend():
    """Test with 1-hour SuperTrend instead of 30-min"""
    config = get_default_config()
    config['TRADING_SYMBOL'] = 'SOLUSD'
    config['SUPERTREND_TIMEFRAME'] = '1h'

    data_paths = get_data_paths('Solana', 'Q1', '2025')
    # Need to provide 1h data instead of 30min
    data_paths['30min'] = data_paths['1min'].replace('1min', '1hour')

    return run_backtest(
        config,
        data_paths,
        description="Solana Q1 2025 - 1H SuperTrend (instead of 30min)"
    )


# =============================================================================
# BATCH RUNNER
# =============================================================================

def run_multiple_quarters(asset, quarters, year, config_modifier=None):
    """
    Run backtest across multiple quarters for same asset

    Args:
        asset: Asset name (BTC, Ethereum, Solana)
        quarters: List of quarters (e.g., ['Q1', 'Q2', 'Q3', 'Q4'])
        year: Year (2024 or 2025)
        config_modifier: Optional function to modify config before each run

    Returns:
        List of backtest results
    """
    results = []

    for quarter in quarters:
        config = get_default_config()

        # Set trading symbol based on asset
        if asset == 'BTC':
            config['TRADING_SYMBOL'] = 'BTCUSD'
        elif asset == 'Ethereum':
            config['TRADING_SYMBOL'] = 'ETHUSD'
        elif asset == 'Solana':
            config['TRADING_SYMBOL'] = 'SOLUSD'

        # Apply custom config modifications
        if config_modifier:
            config = config_modifier(config)

        # Get data paths
        data_paths = get_data_paths(asset, quarter, year)

        # Check if data exists
        if not os.path.exists(data_paths['1min']):
            print(f"\n[SKIP] Data not found for {asset} {quarter} {year}")
            continue

        # Run backtest
        result = run_backtest(
            config,
            data_paths,
            description=f"{asset} {quarter} {year}"
        )

        results.append({
            'asset': asset,
            'quarter': quarter,
            'year': year,
            'backtest': result
        })

    return results


def run_parameter_sweep(asset, quarter, year, parameter_name, parameter_values):
    """
    Run backtest with different values for a single parameter

    Args:
        asset: Asset name
        quarter: Quarter
        year: Year
        parameter_name: Name of config parameter to sweep
        parameter_values: List of values to test

    Returns:
        List of backtest results with parameter values
    """
    results = []

    for value in parameter_values:
        config = get_default_config()

        # Set trading symbol
        if asset == 'BTC':
            config['TRADING_SYMBOL'] = 'BTCUSD'
        elif asset == 'Ethereum':
            config['TRADING_SYMBOL'] = 'ETHUSD'
        elif asset == 'Solana':
            config['TRADING_SYMBOL'] = 'SOLUSD'

        # Set parameter value
        config[parameter_name] = value

        # Get data paths
        data_paths = get_data_paths(asset, quarter, year)

        # Run backtest
        result = run_backtest(
            config,
            data_paths,
            description=f"{asset} {quarter} {year} - {parameter_name}={value}"
        )

        results.append({
            'parameter': parameter_name,
            'value': value,
            'backtest': result
        })

    return results


# =============================================================================
# RESULTS COMPARISON
# =============================================================================

def compare_results(results_list, labels=None):
    """
    Compare multiple backtest results side by side

    Args:
        results_list: List of SwingStrategyBacktest objects
        labels: Optional list of labels for each result
    """
    if not results_list:
        print("No results to compare")
        return

    if labels is None:
        labels = [f"Run {i+1}" for i in range(len(results_list))]

    print("\n" + "="*100)
    print("BACKTEST COMPARISON")
    print("="*100)

    # Header
    print(f"\n{'Metric':<30}", end='')
    for label in labels:
        print(f"{label:>20}", end='')
    print()
    print("-"*100)

    # Metrics to compare
    metrics = [
        ('Total Trades', lambda bt: bt.stats['total_trades']),
        ('Win Rate (%)', lambda bt: (bt.stats['winning_trades'] / bt.stats['total_trades'] * 100) if bt.stats['total_trades'] > 0 else 0),
        ('Total P&L ($)', lambda bt: bt.stats['total_pnl']),
        ('Profit Factor', lambda bt: (bt.stats['gross_profit'] / bt.stats['gross_loss']) if bt.stats['gross_loss'] > 0 else 0),
        ('Max Drawdown ($)', lambda bt: bt.stats['max_drawdown']),
        ('Max Drawdown (%)', lambda bt: bt.stats['max_drawdown_pct']),
    ]

    for metric_name, metric_func in metrics:
        print(f"{metric_name:<30}", end='')
        for bt in results_list:
            value = metric_func(bt)
            if 'P&L' in metric_name or 'Drawdown' in metric_name:
                if '%' in metric_name:
                    print(f"{value:>19.2f}%", end='')
                else:
                    print(f"${value:>18,.2f}", end='')
            elif '%' in metric_name:
                print(f"{value:>19.2f}%", end='')
            elif 'Factor' in metric_name:
                print(f"{value:>20.2f}", end='')
            else:
                print(f"{int(value):>20}", end='')
        print()

    print("="*100)


# =============================================================================
# SAVE/LOAD CONFIGURATION
# =============================================================================

def save_config(config, filename):
    """Save configuration to JSON file"""
    output_dir = os.path.join(os.path.dirname(__file__), '..', 'Temp')
    os.makedirs(output_dir, exist_ok=True)

    filepath = os.path.join(output_dir, filename)
    with open(filepath, 'w') as f:
        json.dump(config, f, indent=4)

    print(f"\nConfiguration saved to: {filepath}")


def load_config(filename):
    """Load configuration from JSON file"""
    filepath = os.path.join(os.path.dirname(__file__), '..', 'Temp', filename)

    with open(filepath, 'r') as f:
        config = json.load(f)

    print(f"\nConfiguration loaded from: {filepath}")
    return config


# =============================================================================
# MAIN EXECUTION
# =============================================================================

if __name__ == "__main__":
    """
    Example usage - uncomment the scenario you want to run
    """

    # Single backtest examples:
    # -----------------------

    # Run Solana Q1 2025 with default settings
    # result = scenario_solana_q1_2025_default()

    # Run Bitcoin Q1 2025
    # result = scenario_btc_q1_2025_default()

    # Run Ethereum Q1 2025
    # result = scenario_eth_q1_2025_default()

    # Test without ADX filter
    # result = scenario_solana_no_adx()

    # Test with higher ADX threshold
    # result = scenario_solana_adx_31()

    # Test without 288 EMA
    # result = scenario_solana_no_ema()

    # Test with 1H SuperTrend
    # result = scenario_solana_1h_supertrend()


    # Batch backtest examples:
    # -----------------------

    # Run all 4 quarters of 2025 for Solana
    # results = run_multiple_quarters('Solana', ['Q1', 'Q2', 'Q3', 'Q4'], 2025)

    # Run parameter sweep for ADX threshold
    # results = run_parameter_sweep('Solana', 'Q1', 2025, 'ADX_THRESHOLD', [20, 23, 26, 29, 31])

    # Comparison example:
    # ------------------

    # Compare different ADX thresholds
    # results = []
    # for adx in [20, 26, 31]:
    #     config = get_default_config()
    #     config['ADX_THRESHOLD'] = adx
    #     data_paths = get_data_paths('Solana', 'Q1', '2025')
    #     bt = run_backtest(config, data_paths, f"ADX={adx}")
    #     results.append(bt)
    #
    # compare_results(results, labels=[f"ADX={adx}" for adx in [20, 26, 31]])


    print("\n" + "="*80)
    print("No scenario selected. Edit this file to uncomment a scenario to run.")
    print("="*80)
    print("\nAvailable scenarios:")
    print("  - scenario_solana_q1_2025_default()")
    print("  - scenario_btc_q1_2025_default()")
    print("  - scenario_eth_q1_2025_default()")
    print("  - scenario_solana_no_adx()")
    print("  - scenario_solana_adx_31()")
    print("  - scenario_solana_no_ema()")
    print("  - scenario_solana_1h_supertrend()")
    print("\nBatch functions:")
    print("  - run_multiple_quarters(asset, quarters, year)")
    print("  - run_parameter_sweep(asset, quarter, year, parameter, values)")
    print("  - compare_results(results_list, labels)")
    print("="*80)
