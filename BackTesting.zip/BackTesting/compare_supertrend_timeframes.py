"""
Compare 30-min SuperTrend vs 4-hour SuperTrend
Test on Solana Q4 2024
"""

import sys
import os
from run_backtest_config import get_default_config
from swing_strategy_backtest import SwingStrategyBacktest

def run_comparison():
    """Run backtests with 30-min and 4-hour SuperTrend"""

    print("\n" + "="*80)
    print("SUPERTREND TIMEFRAME COMPARISON - Solana Q4 2024")
    print("="*80)

    # Data paths
    data_dir = 'D:/Latest_Bot/Data/Solana/Q4_2024'
    data_1min = os.path.join(data_dir, 'Solana_1min_Q4_2024.csv')
    data_5min = os.path.join(data_dir, 'Solana_5min_Q4_2024.csv')
    data_30min = os.path.join(data_dir, 'Solana_30min_Q4_2024.csv')
    data_4hour = os.path.join(data_dir, 'Solana_4hour_Q4_2024.csv')

    results = []

    # Test 1: 30-min SuperTrend
    print("\n" + "="*80)
    print("TEST 1: 30-MINUTE SUPERTREND")
    print("="*80)

    config_30m = get_default_config()
    config_30m['TRADING_SYMBOL'] = 'SOLUSD'
    config_30m['SUPERTREND_TIMEFRAME'] = '30m'
    config_30m['ADX_THRESHOLD'] = 26

    bt_30m = SwingStrategyBacktest(config_30m)
    bt_30m.load_data(
        data_1min_path=data_1min,
        data_5min_path=data_5min,
        data_30min_path=data_30min
    )
    bt_30m.calculate_indicators()
    bt_30m.run()
    bt_30m._generate_results()

    results.append({
        'name': '30-min SuperTrend',
        'backtest': bt_30m
    })

    # Test 2: 4-hour SuperTrend
    print("\n" + "="*80)
    print("TEST 2: 4-HOUR SUPERTREND")
    print("="*80)

    config_4h = get_default_config()
    config_4h['TRADING_SYMBOL'] = 'SOLUSD'
    config_4h['SUPERTREND_TIMEFRAME'] = '4h'
    config_4h['ADX_THRESHOLD'] = 26

    bt_4h = SwingStrategyBacktest(config_4h)
    bt_4h.load_data(
        data_1min_path=data_1min,
        data_5min_path=data_5min,
        data_30min_path=data_4hour  # Use 4-hour data for SuperTrend
    )
    bt_4h.calculate_indicators()
    bt_4h.run()
    bt_4h._generate_results()

    results.append({
        'name': '4-hour SuperTrend',
        'backtest': bt_4h
    })

    # Comparison
    print("\n" + "="*80)
    print("COMPARISON: 30-MIN vs 4-HOUR SUPERTREND")
    print("="*80)

    metrics = [
        ('Total Trades', lambda bt: bt.stats['total_trades']),
        ('Win Rate (%)', lambda bt: (bt.stats['winning_trades'] / bt.stats['total_trades'] * 100) if bt.stats['total_trades'] > 0 else 0),
        ('Total P&L ($)', lambda bt: bt.stats['total_pnl']),
        ('Profit Factor', lambda bt: (bt.stats['gross_profit'] / bt.stats['gross_loss']) if bt.stats['gross_loss'] > 0 else 0),
        ('Gross Profit ($)', lambda bt: bt.stats['gross_profit']),
        ('Gross Loss ($)', lambda bt: bt.stats['gross_loss']),
        ('Max Drawdown ($)', lambda bt: bt.stats['max_drawdown']),
        ('Max Drawdown (%)', lambda bt: bt.stats['max_drawdown_pct']),
    ]

    print(f"\n{'Metric':<25} {'30-min ST':>20} {'4-hour ST':>20} {'Difference':>20}")
    print("-"*90)

    for metric_name, metric_func in metrics:
        val_30m = metric_func(results[0]['backtest'])
        val_4h = metric_func(results[1]['backtest'])
        diff = val_4h - val_30m

        if 'P&L' in metric_name or 'Profit' in metric_name or 'Loss' in metric_name or 'Drawdown $' in metric_name:
            print(f"{metric_name:<25} ${val_30m:>18,.2f} ${val_4h:>18,.2f} ${diff:>18,.2f}")
        elif '%' in metric_name:
            print(f"{metric_name:<25} {val_30m:>19.2f}% {val_4h:>19.2f}% {diff:>19.2f}%")
        elif 'Factor' in metric_name:
            print(f"{metric_name:<25} {val_30m:>20.2f} {val_4h:>20.2f} {diff:>20.2f}")
        else:
            print(f"{metric_name:<25} {int(val_30m):>20} {int(val_4h):>20} {int(diff):>20}")

    print("="*90)

    # Direction breakdown
    import pandas as pd

    print("\n" + "="*80)
    print("DIRECTION BREAKDOWN")
    print("="*80)

    for result in results:
        name = result['name']
        bt = result['backtest']

        if bt.trades:
            df = pd.DataFrame(bt.trades)
            long_trades = df[df['direction'] == 'LONG']
            short_trades = df[df['direction'] == 'SHORT']

            print(f"\n{name}:")
            if len(long_trades) > 0:
                long_wr = (len(long_trades[long_trades['net_pnl'] > 0]) / len(long_trades)) * 100
                long_pnl = long_trades['net_pnl'].sum()
                print(f"  LONG:  {len(long_trades):3d} trades, {long_wr:5.2f}% WR, ${long_pnl:>10,.2f} P&L")

            if len(short_trades) > 0:
                short_wr = (len(short_trades[short_trades['net_pnl'] > 0]) / len(short_trades)) * 100
                short_pnl = short_trades['net_pnl'].sum()
                print(f"  SHORT: {len(short_trades):3d} trades, {short_wr:5.2f}% WR, ${short_pnl:>10,.2f} P&L")

    print("\n" + "="*80)


if __name__ == "__main__":
    run_comparison()
