"""
Swing SuperTrend Strategy - Backtesting Engine
Exact replication of live trading bot logic for historical testing
"""

import sys
import os
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import glob

# Add parent directory to path to import strategy modules
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'final bot_sol'))

from btc_futures_scalping import calculate_supertrend, calculate_adx, calculate_atr
from swing_supertrend_strategy import (
    identify_swing_points,
    calculate_288_ema,
    get_most_recent_swing,
    calculate_initial_stop_loss,
    update_swing_trailing_stop,
    check_swing_exit
)


class SwingStrategyBacktest:
    """
    Generic backtesting engine for Swing SuperTrend Strategy
    Supports all configurable parameters
    """

    def __init__(self, config):
        """
        Initialize backtest with configuration

        Args:
            config: Configuration object or dict with strategy parameters
        """
        self.config = config

        # Results tracking
        self.trades = []
        self.equity_curve = []
        self.current_position = None
        self.last_exit_time = None

        # Statistics
        self.stats = {
            'total_trades': 0,
            'winning_trades': 0,
            'losing_trades': 0,
            'total_pnl': 0.0,
            'gross_profit': 0.0,
            'gross_loss': 0.0,
            'max_drawdown': 0.0,
            'max_drawdown_pct': 0.0,
            'peak_equity': 0.0
        }

        # Data storage
        self.df_1min = None
        self.df_5min = None
        self.df_30min = None

        print("="*80)
        print("SWING SUPERTREND STRATEGY - BACKTESTING ENGINE")
        print("="*80)
        print(f"Symbol: {config.get('TRADING_SYMBOL', 'N/A')}")
        print(f"Position Size: ${config.get('POSITION_SIZE_DOLLARS', 0):,.0f}")
        print(f"Leverage: {config.get('LEVERAGE', 1)}x")
        print(f"Commission Rate: {config.get('COMMISSION_RATE', 0.0005)*100:.3f}%")
        print("="*80)

    def load_data(self, data_1min_path, data_5min_path=None, data_30min_path=None):
        """
        Load historical data from CSV files

        Args:
            data_1min_path: Path to 1-minute data CSV
            data_5min_path: Path to 5-minute data CSV (optional, will aggregate from 1min if not provided)
            data_30min_path: Path to 30-minute data CSV (optional, will aggregate from 1min if not provided)
        """
        print("\n[LOADING DATA]")
        print(f"1-min data: {data_1min_path}")

        # Load 1-minute data
        self.df_1min = pd.read_csv(data_1min_path)

        # Handle timestamp column - prefer 'datetime' column if exists, otherwise convert 'timestamp'
        if 'datetime' in self.df_1min.columns:
            self.df_1min['timestamp'] = pd.to_datetime(self.df_1min['datetime'])
        elif 'timestamp' in self.df_1min.columns:
            # Try to detect if timestamp is Unix epoch
            first_ts = self.df_1min['timestamp'].iloc[0]
            if isinstance(first_ts, (int, float)) and first_ts > 1000000000:
                # Unix timestamp (seconds since epoch)
                self.df_1min['timestamp'] = pd.to_datetime(self.df_1min['timestamp'], unit='s')
            else:
                self.df_1min['timestamp'] = pd.to_datetime(self.df_1min['timestamp'])
        else:
            raise ValueError("No timestamp or datetime column found in data")

        self.df_1min = self.df_1min.sort_values('timestamp').reset_index(drop=True)
        print(f"  Loaded {len(self.df_1min):,} 1-minute candles")
        print(f"  Date Range: {self.df_1min['timestamp'].min()} to {self.df_1min['timestamp'].max()}")

        # Load or aggregate 5-minute data
        if data_5min_path and os.path.exists(data_5min_path):
            self.df_5min = pd.read_csv(data_5min_path)

            # Handle timestamp column
            if 'datetime' in self.df_5min.columns:
                self.df_5min['timestamp'] = pd.to_datetime(self.df_5min['datetime'])
            elif 'timestamp' in self.df_5min.columns:
                first_ts = self.df_5min['timestamp'].iloc[0]
                if isinstance(first_ts, (int, float)) and first_ts > 1000000000:
                    self.df_5min['timestamp'] = pd.to_datetime(self.df_5min['timestamp'], unit='s')
                else:
                    self.df_5min['timestamp'] = pd.to_datetime(self.df_5min['timestamp'])
            else:
                raise ValueError("No timestamp or datetime column found in 5min data")

            self.df_5min = self.df_5min.sort_values('timestamp').reset_index(drop=True)
            print(f"  Loaded {len(self.df_5min):,} 5-minute candles")
        else:
            print("  Aggregating 5-minute candles from 1-minute data...")
            self.df_5min = self._aggregate_candles(self.df_1min, '5min')
            print(f"  Created {len(self.df_5min):,} 5-minute candles")

        # Load or aggregate 30-minute data
        if data_30min_path and os.path.exists(data_30min_path):
            self.df_30min = pd.read_csv(data_30min_path)

            # Handle timestamp column
            if 'datetime' in self.df_30min.columns:
                self.df_30min['timestamp'] = pd.to_datetime(self.df_30min['datetime'])
            elif 'timestamp' in self.df_30min.columns:
                first_ts = self.df_30min['timestamp'].iloc[0]
                if isinstance(first_ts, (int, float)) and first_ts > 1000000000:
                    self.df_30min['timestamp'] = pd.to_datetime(self.df_30min['timestamp'], unit='s')
                else:
                    self.df_30min['timestamp'] = pd.to_datetime(self.df_30min['timestamp'])
            else:
                raise ValueError("No timestamp or datetime column found in 30min data")

            self.df_30min = self.df_30min.sort_values('timestamp').reset_index(drop=True)
            print(f"  Loaded {len(self.df_30min):,} 30-minute candles")
        else:
            print("  Aggregating 30-minute candles from 1-minute data...")
            self.df_30min = self._aggregate_candles(self.df_1min, '30min')
            print(f"  Created {len(self.df_30min):,} 30-minute candles")

        print(f"  Data loaded successfully")
        print("="*80)

    def _aggregate_candles(self, df_1min, timeframe):
        """
        Aggregate 1-minute candles to higher timeframe

        Args:
            df_1min: DataFrame with 1-minute OHLCV data
            timeframe: Target timeframe ('5min', '30min', '1h')

        Returns:
            DataFrame with aggregated candles
        """
        df = df_1min.copy()
        df.set_index('timestamp', inplace=True)

        # Resample and aggregate
        ohlc_dict = {
            'open': 'first',
            'high': 'max',
            'low': 'min',
            'close': 'last',
            'volume': 'sum'
        }

        df_agg = df.resample(timeframe).agg(ohlc_dict).dropna()
        df_agg.reset_index(inplace=True)

        return df_agg

    def calculate_indicators(self):
        """
        Calculate all indicators on each timeframe
        """
        print("\n[CALCULATING INDICATORS]")

        # 5-minute indicators
        print("  Calculating 5-minute indicators...")
        if self.config.get('USE_288_EMA_FILTER', True):
            self.df_5min['ema_288'] = calculate_288_ema(self.df_5min)
            print("    - 288 EMA (24-hour trend)")

        if self.config.get('USE_ADX_FILTER', True):
            self.df_5min['adx'] = calculate_adx(
                self.df_5min,
                period=self.config.get('ADX_PERIOD', 14)
            )
            print(f"    - ADX (period={self.config.get('ADX_PERIOD', 14)})")

        # Identify swing points
        print(f"    - Swing Points (lookback={self.config.get('SWING_LOOKBACK_CANDLES', 4)}, confirmation={self.config.get('SWING_CONFIRMATION_CANDLES', 3)})")
        self.df_5min = identify_swing_points(
            self.df_5min,
            lookback=self.config.get('SWING_LOOKBACK_CANDLES', 4),
            confirmation=self.config.get('SWING_CONFIRMATION_CANDLES', 3)
        )

        # 30-minute indicators
        print("  Calculating 30-minute indicators...")
        if self.config.get('USE_SUPERTREND_FILTER', True):
            st_30m, dir_30m = calculate_supertrend(
                self.df_30min,
                period=self.config.get('SUPERTREND_PERIOD', 10),
                multiplier=self.config.get('SUPERTREND_MULTIPLIER', 3.0)
            )
            self.df_30min['supertrend'] = st_30m
            self.df_30min['st_direction'] = dir_30m
            print(f"    - SuperTrend (period={self.config.get('SUPERTREND_PERIOD', 10)}, multiplier={self.config.get('SUPERTREND_MULTIPLIER', 3.0)})")

        print("  Indicators calculated successfully")
        print("="*80)

    def run(self):
        """
        Run backtest simulation
        """
        print("\n[STARTING BACKTEST SIMULATION]")
        print(f"Start Time: {self.df_1min['timestamp'].min()}")
        print(f"End Time: {self.df_1min['timestamp'].max()}")
        print(f"Total Duration: {(self.df_1min['timestamp'].max() - self.df_1min['timestamp'].min()).days} days")
        print("="*80)

        # Initialize equity
        initial_capital = self.config.get('ACCOUNT_SIZE', 10000)
        current_equity = initial_capital
        self.equity_curve.append({
            'timestamp': self.df_1min['timestamp'].min(),
            'equity': current_equity,
            'drawdown': 0.0,
            'drawdown_pct': 0.0
        })
        self.stats['peak_equity'] = current_equity

        # Pre-flight conditions tracking
        long_conditions_met = False
        short_conditions_met = False
        swing_high_level = None
        swing_low_level = None
        ema_288_value = None
        supertrend_direction = None
        adx_value = None

        # Track progress
        total_5min_candles = len(self.df_5min)
        candles_processed = 0
        last_progress_pct = 0

        # Iterate through 5-minute candles
        for idx_5min in range(len(self.df_5min)):
            candle_5min = self.df_5min.iloc[idx_5min]
            candle_time = candle_5min['timestamp']

            # Progress reporting (every 10%)
            candles_processed += 1
            progress_pct = int((candles_processed / total_5min_candles) * 100)
            if progress_pct >= last_progress_pct + 10:
                print(f"Progress: {progress_pct}% ({candles_processed:,}/{total_5min_candles:,} candles) - {candle_time.date()}")
                last_progress_pct = progress_pct

            # Check cooldown period
            if self.last_exit_time is not None:
                time_since_exit = (candle_time - self.last_exit_time).total_seconds()
                cooldown_seconds = self.config.get('COOLDOWN_PERIOD_SECONDS', 600)  # 10 minutes

                if time_since_exit < cooldown_seconds:
                    # Skip signal detection during cooldown
                    long_conditions_met = False
                    short_conditions_met = False
                    swing_high_level = None
                    swing_low_level = None

                    # But still monitor position if exists
                    if self.current_position:
                        self._monitor_position_on_5min_candle(idx_5min, current_equity)
                        # Calculate actual equity = initial capital + accumulated P&L
                        current_equity = initial_capital + self.stats['total_pnl']
                        self._update_equity(current_equity)

                    continue
                else:
                    # Cooldown expired
                    self.last_exit_time = None

            # Update pre-flight conditions on each 5-min candle close
            if not self.current_position:
                # Need enough historical data for indicators
                if idx_5min < 300:
                    continue

                # Get latest values
                latest_close = candle_5min['close']

                # Get 288 EMA
                if self.config.get('USE_288_EMA_FILTER', True):
                    ema_288_value = candle_5min.get('ema_288', None)
                    if pd.isna(ema_288_value):
                        continue
                else:
                    ema_288_value = None

                # Get ADX
                if self.config.get('USE_ADX_FILTER', True):
                    adx_value = candle_5min.get('adx', None)
                    if pd.isna(adx_value):
                        continue
                    if adx_value < self.config.get('ADX_THRESHOLD', 26):
                        long_conditions_met = False
                        short_conditions_met = False
                        continue
                else:
                    adx_value = None

                # Get SuperTrend direction from 30-min
                if self.config.get('USE_SUPERTREND_FILTER', True):
                    # Find corresponding 30-min candle
                    df_30min_up_to_now = self.df_30min[self.df_30min['timestamp'] <= candle_time]
                    if len(df_30min_up_to_now) == 0:
                        continue
                    latest_30min = df_30min_up_to_now.iloc[-1]
                    supertrend_direction = latest_30min.get('st_direction', None)
                    if pd.isna(supertrend_direction):
                        continue
                else:
                    supertrend_direction = None

                # Get most recent swing points
                df_5min_up_to_now = self.df_5min.iloc[:idx_5min+1]
                swing_high, swing_high_idx = get_most_recent_swing(
                    df_5min_up_to_now, 'high', before_index=len(df_5min_up_to_now)-1
                )
                swing_low, swing_low_idx = get_most_recent_swing(
                    df_5min_up_to_now, 'low', before_index=len(df_5min_up_to_now)-1
                )

                swing_high_level = swing_high
                swing_low_level = swing_low

                # Check LONG conditions
                long_ema_ok = True
                long_st_ok = True
                long_adx_ok = True
                long_swing_ok = swing_high is not None

                if self.config.get('USE_288_EMA_FILTER', True):
                    if ema_288_value is not None:
                        long_ema_ok = latest_close > ema_288_value
                    else:
                        long_ema_ok = False

                if self.config.get('USE_SUPERTREND_FILTER', True):
                    if supertrend_direction is not None:
                        long_st_ok = supertrend_direction == 1
                    else:
                        long_st_ok = False

                if self.config.get('USE_ADX_FILTER', True):
                    if adx_value is not None:
                        long_adx_ok = adx_value >= self.config.get('ADX_THRESHOLD', 26)
                    else:
                        long_adx_ok = False

                long_conditions_met = long_ema_ok and long_st_ok and long_adx_ok and long_swing_ok

                # Check SHORT conditions
                short_ema_ok = True
                short_st_ok = True
                short_adx_ok = True
                short_swing_ok = swing_low is not None

                if self.config.get('USE_288_EMA_FILTER', True):
                    if ema_288_value is not None:
                        short_ema_ok = latest_close < ema_288_value
                    else:
                        short_ema_ok = False

                if self.config.get('USE_SUPERTREND_FILTER', True):
                    if supertrend_direction is not None:
                        short_st_ok = supertrend_direction == -1
                    else:
                        short_st_ok = False

                if self.config.get('USE_ADX_FILTER', True):
                    if adx_value is not None:
                        short_adx_ok = adx_value >= self.config.get('ADX_THRESHOLD', 26)
                    else:
                        short_adx_ok = False

                short_conditions_met = short_ema_ok and short_st_ok and short_adx_ok and short_swing_ok

            # Monitor for breakout entry in NEXT 5-min period (forward-looking)
            # This prevents look-ahead bias - we wait for next period after conditions are confirmed
            if not self.current_position:
                # Check for breakout entry
                self._check_breakout_entry(
                    candle_time,
                    long_conditions_met,
                    short_conditions_met,
                    swing_high_level,
                    swing_low_level,
                    ema_288_value,
                    supertrend_direction,
                    adx_value,
                    idx_5min
                )

            # Monitor existing position
            if self.current_position:
                self._monitor_position_on_5min_candle(idx_5min, current_equity)

            # Update equity after processing this 5-min candle
            # Calculate actual equity = initial capital + accumulated P&L
            current_equity = initial_capital + self.stats['total_pnl']
            self._update_equity(current_equity)

        print("\n" + "="*80)
        print("[BACKTEST COMPLETE]")
        print("="*80)

        # Generate results
        self._generate_results()

    def _check_breakout_entry(self, candle_time, long_cond, short_cond, swing_high, swing_low, ema_288, st_dir, adx, idx_5min):
        """
        Check for breakout entry on 1-minute ticks
        IMPORTANT: Monitor NEXT 5-min period after conditions are set (forward-looking, not look-ahead bias)
        """
        if not long_cond and not short_cond:
            return

        # Get 1-minute ticks AFTER current 5-min candle closes
        # Monitor from now until next 5-min candle (forward-looking, not look-ahead)
        next_5min_time = candle_time + timedelta(minutes=5)

        df_1min_window = self.df_1min[
            (self.df_1min['timestamp'] > candle_time) &
            (self.df_1min['timestamp'] <= next_5min_time)
        ]

        for _, tick in df_1min_window.iterrows():
            tick_high = tick['high']
            tick_low = tick['low']
            tick_time = tick['timestamp']

            # Check LONG breakout (with 2-pip buffer like live bot)
            if long_cond and swing_high is not None:
                breakout_level = swing_high + 0.02  # Swing high + 2 pips
                # For LONG: Check if HIGH of this 1-min candle touched/crossed the breakout level
                if tick_high >= breakout_level:
                    # Enter at EXACT breakout level (not candle price)
                    entry_price = breakout_level
                    # LONG entry triggered
                    self._enter_position(
                        direction='LONG',
                        entry_price=entry_price,
                        entry_time=tick_time,
                        swing_high=swing_high,
                        swing_low=swing_low,
                        ema_288=ema_288,
                        st_dir=st_dir,
                        adx=adx,
                        idx_5min=idx_5min
                    )
                    return

            # Check SHORT breakout (with 2-pip buffer like live bot)
            if short_cond and swing_low is not None:
                breakout_level = swing_low - 0.02  # Swing low - 2 pips
                # For SHORT: Check if LOW of this 1-min candle touched/crossed the breakout level
                if tick_low <= breakout_level:
                    # Enter at EXACT breakout level (not candle price)
                    entry_price = breakout_level
                    # SHORT entry triggered
                    self._enter_position(
                        direction='SHORT',
                        entry_price=entry_price,
                        entry_time=tick_time,
                        swing_high=swing_high,
                        swing_low=swing_low,
                        ema_288=ema_288,
                        st_dir=st_dir,
                        adx=adx,
                        idx_5min=idx_5min
                    )
                    return

    def _enter_position(self, direction, entry_price, entry_time, swing_high, swing_low, ema_288, st_dir, adx, idx_5min):
        """
        Enter a new position
        """
        # Calculate initial stop loss
        initial_stop = calculate_initial_stop_loss(
            entry_price=entry_price,
            direction=direction,
            swing_high=swing_high,
            swing_low=swing_low,
            config=SimpleConfig(self.config)
        )

        # Calculate position size
        position_size_usd = self.config.get('POSITION_SIZE_DOLLARS', 10000)
        leverage = self.config.get('LEVERAGE', 1)
        position_size_base = (position_size_usd * leverage) / entry_price

        # Create position
        self.current_position = {
            'trade_id': len(self.trades) + 1,
            'direction': direction,
            'entry_price': entry_price,
            'entry_time': entry_time,
            'stop_loss': initial_stop,
            'position_size_base': position_size_base,
            'position_size_usd': position_size_usd,
            'leverage': leverage,
            'swing_high_at_entry': swing_high,
            'swing_low_at_entry': swing_low,
            'ema_288_at_entry': ema_288,
            'st_direction_at_entry': st_dir,
            'adx_at_entry': adx,
            'entry_5min_idx': idx_5min,
            'highest_price': entry_price,
            'lowest_price': entry_price,
            'highest_profit_pips': 0.0,
            'lowest_profit_pips': 0.0
        }

        # Convert to IST for display
        entry_time_ist = entry_time + timedelta(hours=5, minutes=30)
        print(f"\n[ENTRY] {direction} @ ${entry_price:.2f} at {entry_time_ist.strftime('%Y-%m-%d %H:%M:%S')} IST")
        print(f"  Stop Loss: ${initial_stop:.2f}")
        print(f"  Position Size: {position_size_base:.4f} ({position_size_usd:,.0f} USD)")

    def _monitor_position_on_5min_candle(self, idx_5min, current_equity):
        """
        Monitor position on each new 5-min candle (update trailing stop)
        """
        if not self.current_position:
            return

        # Update trailing stop based on new swing points
        df_5min_up_to_now = self.df_5min.iloc[:idx_5min+1]

        updated_stop = update_swing_trailing_stop(
            position=self.current_position,
            df_5min=df_5min_up_to_now,
            config=SimpleConfig(self.config)
        )

        if updated_stop != self.current_position['stop_loss']:
            print(f"  [TRAILING STOP UPDATE] ${self.current_position['stop_loss']:.2f} -> ${updated_stop:.2f}")
            self.current_position['stop_loss'] = updated_stop

        # Check for exit on 1-min ticks AFTER this candle closes
        candle_time = df_5min_up_to_now.iloc[-1]['timestamp']
        next_5min_time = candle_time + timedelta(minutes=5)

        df_1min_window = self.df_1min[
            (self.df_1min['timestamp'] > candle_time) &
            (self.df_1min['timestamp'] <= next_5min_time)
        ]

        for _, tick in df_1min_window.iterrows():
            tick_high = tick['high']
            tick_low = tick['low']
            tick_time = tick['timestamp']

            # Update high/low tracking
            self.current_position['highest_price'] = max(self.current_position['highest_price'], tick_high)
            self.current_position['lowest_price'] = min(self.current_position['lowest_price'], tick_low)

            # Check exit condition using LOW for LONG (stop below) and HIGH for SHORT (stop above)
            direction = self.current_position['direction']
            stop_loss = self.current_position['stop_loss']

            if direction == 'LONG':
                # For LONG: Check if LOW of this 1-min candle touched/crossed the stop level
                if tick_low <= stop_loss:
                    # Exit at EXACT stop level (not candle price)
                    exit_price = stop_loss
                    self._exit_position(exit_price, tick_time, 'Swing Stop (LONG)', current_equity)
                    return
            else:  # SHORT
                # For SHORT: Check if HIGH of this 1-min candle touched/crossed the stop level
                if tick_high >= stop_loss:
                    # Exit at EXACT stop level (not candle price)
                    exit_price = stop_loss
                    self._exit_position(exit_price, tick_time, 'Swing Stop (SHORT)', current_equity)
                    return

    def _exit_position(self, exit_price, exit_time, exit_reason, current_equity):
        """
        Exit current position
        """
        if not self.current_position:
            return

        pos = self.current_position

        # Calculate P&L
        if pos['direction'] == 'LONG':
            gross_pnl = (exit_price - pos['entry_price']) * pos['position_size_base']
        else:  # SHORT
            gross_pnl = (pos['entry_price'] - exit_price) * pos['position_size_base']

        # Calculate commission
        commission_rate = self.config.get('COMMISSION_RATE', 0.0005)
        entry_commission = pos['entry_price'] * pos['position_size_base'] * commission_rate
        exit_commission = exit_price * pos['position_size_base'] * commission_rate
        total_commission = entry_commission + exit_commission

        # Net P&L
        net_pnl = gross_pnl - total_commission
        pnl_pct = (net_pnl / pos['position_size_usd']) * 100

        # Hold time
        hold_time = (exit_time - pos['entry_time']).total_seconds() / 60  # minutes

        # Calculate profit pips
        if pos['direction'] == 'LONG':
            highest_profit_pips = (pos['highest_price'] - pos['entry_price']) / pos['entry_price'] * 10000
            lowest_profit_pips = (pos['lowest_price'] - pos['entry_price']) / pos['entry_price'] * 10000
        else:
            highest_profit_pips = (pos['entry_price'] - pos['lowest_price']) / pos['entry_price'] * 10000
            lowest_profit_pips = (pos['entry_price'] - pos['highest_price']) / pos['entry_price'] * 10000

        # Convert to IST (UTC + 5:30)
        entry_time_ist = pos['entry_time'] + timedelta(hours=5, minutes=30)
        exit_time_ist = exit_time + timedelta(hours=5, minutes=30)

        # Store trade
        trade = {
            'trade_id': pos['trade_id'],
            'entry_time_utc': pos['entry_time'],
            'exit_time_utc': exit_time,
            'entry_time_ist': entry_time_ist,
            'exit_time_ist': exit_time_ist,
            'direction': pos['direction'],
            'entry_price': pos['entry_price'],
            'exit_price': exit_price,
            'stop_loss': pos['stop_loss'],
            'position_size_base': pos['position_size_base'],
            'position_size_usd': pos['position_size_usd'],
            'leverage': pos['leverage'],
            'highest_price': pos['highest_price'],
            'lowest_price': pos['lowest_price'],
            'highest_profit_pips': highest_profit_pips,
            'lowest_profit_pips': lowest_profit_pips,
            'exit_reason': exit_reason,
            'hold_time_minutes': hold_time,
            'gross_pnl': gross_pnl,
            'commission': total_commission,
            'net_pnl': net_pnl,
            'pnl_pct': pnl_pct,
            'ema_288_at_entry': pos['ema_288_at_entry'],
            'st_direction_at_entry': pos['st_direction_at_entry'],
            'adx_at_entry': pos['adx_at_entry'],
            'swing_high_at_entry': pos['swing_high_at_entry'],
            'swing_low_at_entry': pos['swing_low_at_entry']
        }

        self.trades.append(trade)

        # Update statistics
        self.stats['total_trades'] += 1
        self.stats['total_pnl'] += net_pnl

        if net_pnl > 0:
            self.stats['winning_trades'] += 1
            self.stats['gross_profit'] += net_pnl
        else:
            self.stats['losing_trades'] += 1
            self.stats['gross_loss'] += abs(net_pnl)

        # Convert to IST for display
        exit_time_ist = exit_time + timedelta(hours=5, minutes=30)
        print(f"\n[EXIT] {pos['direction']} @ ${exit_price:.2f} at {exit_time_ist.strftime('%Y-%m-%d %H:%M:%S')} IST")
        print(f"  Reason: {exit_reason}")
        print(f"  P&L: ${net_pnl:.2f} ({pnl_pct:+.2f}%)")
        print(f"  Hold Time: {hold_time:.0f} minutes")

        # Set cooldown
        self.last_exit_time = exit_time

        # Clear position
        self.current_position = None

    def _update_equity(self, current_equity):
        """
        Update equity curve and drawdown
        """
        # current_equity is already the running equity (initial + total_pnl)

        # Update peak equity
        if current_equity > self.stats['peak_equity']:
            self.stats['peak_equity'] = current_equity

        # Calculate drawdown from peak
        drawdown = self.stats['peak_equity'] - current_equity

        # Calculate drawdown % based on INITIAL capital, not peak
        initial_capital = self.config.get('ACCOUNT_SIZE', 10000)
        drawdown_pct = (drawdown / initial_capital) * 100

        # Update max drawdown
        if drawdown > self.stats['max_drawdown']:
            self.stats['max_drawdown'] = drawdown
            self.stats['max_drawdown_pct'] = drawdown_pct

        # Store final equity
        self.stats['final_equity'] = current_equity

        return current_equity

    def _generate_results(self):
        """
        Generate and display backtest results
        """
        print("\n" + "="*80)
        print("BACKTEST RESULTS")
        print("="*80)

        if len(self.trades) == 0:
            print("No trades executed")
            return

        # Convert trades to DataFrame
        df_trades = pd.DataFrame(self.trades)

        # Calculate metrics
        total_trades = self.stats['total_trades']
        winning_trades = self.stats['winning_trades']
        losing_trades = self.stats['losing_trades']
        win_rate = (winning_trades / total_trades * 100) if total_trades > 0 else 0

        avg_win = df_trades[df_trades['net_pnl'] > 0]['net_pnl'].mean() if winning_trades > 0 else 0
        avg_loss = df_trades[df_trades['net_pnl'] < 0]['net_pnl'].mean() if losing_trades > 0 else 0

        profit_factor = (self.stats['gross_profit'] / self.stats['gross_loss']) if self.stats['gross_loss'] > 0 else 0

        # Direction breakdown
        long_trades = df_trades[df_trades['direction'] == 'LONG']
        short_trades = df_trades[df_trades['direction'] == 'SHORT']

        print(f"\nOverall Performance:")
        print(f"  Total Trades: {total_trades}")
        print(f"  Winning Trades: {winning_trades} ({win_rate:.2f}%)")
        print(f"  Losing Trades: {losing_trades}")
        print(f"  Total P&L: ${self.stats['total_pnl']:,.2f}")
        print(f"  Gross Profit: ${self.stats['gross_profit']:,.2f}")
        print(f"  Gross Loss: ${self.stats['gross_loss']:,.2f}")
        print(f"  Profit Factor: {profit_factor:.2f}")
        print(f"  Average Win: ${avg_win:.2f}")
        print(f"  Average Loss: ${avg_loss:.2f}")
        print(f"  Max Drawdown: ${self.stats['max_drawdown']:,.2f} ({self.stats['max_drawdown_pct']:.2f}%)")

        if len(long_trades) > 0:
            long_win_rate = (len(long_trades[long_trades['net_pnl'] > 0]) / len(long_trades)) * 100
            long_pnl = long_trades['net_pnl'].sum()
            print(f"\nLONG Trades:")
            print(f"  Count: {len(long_trades)}")
            print(f"  Win Rate: {long_win_rate:.2f}%")
            print(f"  Total P&L: ${long_pnl:,.2f}")

        if len(short_trades) > 0:
            short_win_rate = (len(short_trades[short_trades['net_pnl'] > 0]) / len(short_trades)) * 100
            short_pnl = short_trades['net_pnl'].sum()
            print(f"\nSHORT Trades:")
            print(f"  Count: {len(short_trades)}")
            print(f"  Win Rate: {short_win_rate:.2f}%")
            print(f"  Total P&L: ${short_pnl:,.2f}")

        # Save to latest_reports/{asset} folder
        symbol = self.config.get('TRADING_SYMBOL', 'UNKNOWN')
        asset_name = symbol.replace('USD', '')  # BTCUSD -> BTC, SOLUSD -> SOL
        output_dir = os.path.join(os.path.dirname(__file__), '..', 'latest_reports', asset_name)
        os.makedirs(output_dir, exist_ok=True)

        # Use quarter/year from config if available, otherwise use timestamp
        quarter = self.config.get('BACKTEST_QUARTER', None)
        year = self.config.get('BACKTEST_YEAR', None)

        if quarter and year:
            suffix = f'{quarter}_{year}'
        else:
            suffix = datetime.now().strftime('%Y%m%d_%H%M%S')

        # Save trades CSV
        trades_file = os.path.join(output_dir, f'trades_{symbol}_{suffix}.csv')
        df_trades.to_csv(trades_file, index=False)

        # Save summary report
        summary_file = os.path.join(output_dir, f'summary_{symbol}_{suffix}.txt')
        with open(summary_file, 'w') as f:
            f.write("="*80 + "\n")
            f.write("BACKTEST SUMMARY REPORT\n")
            f.write("="*80 + "\n")
            f.write(f"Symbol: {symbol}\n")
            f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write("="*80 + "\n\n")

            f.write("Overall Performance:\n")
            f.write(f"  Total Trades: {total_trades}\n")
            f.write(f"  Winning Trades: {winning_trades} ({win_rate:.2f}%)\n")
            f.write(f"  Losing Trades: {losing_trades}\n")
            f.write(f"  Total P&L: ${self.stats['total_pnl']:,.2f}\n")
            f.write(f"  Gross Profit: ${self.stats['gross_profit']:,.2f}\n")
            f.write(f"  Gross Loss: ${self.stats['gross_loss']:,.2f}\n")
            f.write(f"  Profit Factor: {profit_factor:.2f}\n")
            f.write(f"  Average Win: ${avg_win:.2f}\n")
            f.write(f"  Average Loss: ${avg_loss:.2f}\n")
            f.write(f"  Max Drawdown: ${self.stats['max_drawdown']:,.2f} ({self.stats['max_drawdown_pct']:.2f}%)\n")

            if len(long_trades) > 0:
                long_win_rate = (len(long_trades[long_trades['net_pnl'] > 0]) / len(long_trades)) * 100
                long_pnl = long_trades['net_pnl'].sum()
                f.write(f"\nLONG Trades:\n")
                f.write(f"  Count: {len(long_trades)}\n")
                f.write(f"  Win Rate: {long_win_rate:.2f}%\n")
                f.write(f"  Total P&L: ${long_pnl:,.2f}\n")

            if len(short_trades) > 0:
                short_win_rate = (len(short_trades[short_trades['net_pnl'] > 0]) / len(short_trades)) * 100
                short_pnl = short_trades['net_pnl'].sum()
                f.write(f"\nSHORT Trades:\n")
                f.write(f"  Count: {len(short_trades)}\n")
                f.write(f"  Win Rate: {short_win_rate:.2f}%\n")
                f.write(f"  Total P&L: ${short_pnl:,.2f}\n")

            # Configuration used
            f.write(f"\n" + "="*80 + "\n")
            f.write("Configuration Used:\n")
            f.write("="*80 + "\n")
            f.write(f"  SuperTrend Timeframe: {self.config.get('SUPERTREND_TIMEFRAME', 'N/A')}\n")
            f.write(f"  ADX Threshold: {self.config.get('ADX_THRESHOLD', 'N/A')}\n")
            f.write(f"  288 EMA Filter: {self.config.get('USE_288_EMA_FILTER', 'N/A')}\n")
            f.write(f"  SuperTrend Filter: {self.config.get('USE_SUPERTREND_FILTER', 'N/A')}\n")
            f.write(f"  Swing Lookback: {self.config.get('SWING_LOOKBACK_CANDLES', 'N/A')}\n")
            f.write(f"  Swing Confirmation: {self.config.get('SWING_CONFIRMATION_CANDLES', 'N/A')}\n")

        print(f"\nReports saved:")
        print(f"  Trades CSV: {trades_file}")
        print(f"  Summary: {summary_file}")
        print("="*80)


class SimpleConfig:
    """Simple config wrapper for strategy functions"""
    def __init__(self, config_dict):
        for key, value in config_dict.items():
            setattr(self, key, value)


def load_config_from_file(config_path=None):
    """
    Load configuration from config file or use defaults
    """
    if config_path:
        # Load from file
        sys.path.append(os.path.dirname(config_path))
        from config import load_config
        return load_config()
    else:
        # Use default swing supertrend config
        return {
            'TRADING_SYMBOL': 'SOLUSD',
            'ENTRY_TIMEFRAME': '5min',
            'SUPERTREND_TIMEFRAME': '30m',
            'USE_288_EMA_FILTER': True,
            'USE_SUPERTREND_FILTER': True,
            'USE_ADX_FILTER': True,
            'USE_MARUBOZU_FILTER': False,
            'SWING_LOOKBACK_CANDLES': 4,
            'SWING_CONFIRMATION_CANDLES': 3,
            'SUPERTREND_PERIOD': 10,
            'SUPERTREND_MULTIPLIER': 3.0,
            'ADX_PERIOD': 14,
            'ADX_THRESHOLD': 26,
            'STOP_LOSS_BUFFER_PCT': 0.15,
            'MAX_STOP_LOSS_PCT': 1.5,
            'POSITION_SIZE_DOLLARS': 5000,
            'LEVERAGE': 1,
            'ACCOUNT_SIZE': 10000,
            'COMMISSION_RATE': 0.0005,
            'COOLDOWN_PERIOD_SECONDS': 600
        }


if __name__ == "__main__":
    """
    Example usage
    """
    # Load configuration
    config = load_config_from_file()

    # Override config for testing
    config['TRADING_SYMBOL'] = 'SOLUSD'
    config['POSITION_SIZE_DOLLARS'] = 5000

    # Initialize backtest
    backtest = SwingStrategyBacktest(config)

    # Load data
    data_dir = os.path.join(os.path.dirname(__file__), '..', 'Data', 'Solana', 'Q1_2025')
    backtest.load_data(
        data_1min_path=os.path.join(data_dir, 'Solana_1min_Q1_2025.csv'),
        data_5min_path=os.path.join(data_dir, 'Solana_5min_Q1_2025.csv'),
        data_30min_path=os.path.join(data_dir, 'Solana_30min_Q1_2025.csv')
    )

    # Calculate indicators
    backtest.calculate_indicators()

    # Run backtest
    backtest.run()
