"""
Options Selling Strategy Backtest
Sells ATM weekly options based on swing strategy signals
- LONG signal → Sell ATM Put
- SHORT signal → Sell ATM Call
- No trades on Friday (expiry day)
- Exit on opposite signal or at expiry
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import os
from option_pricing import (
    black_scholes, calculate_implied_volatility_from_historical,
    find_atm_strike, get_next_day_expiry, get_next_friday_expiry, is_friday_no_trade_zone,
    time_to_expiry_years
)

# Import indicators from the existing strategy
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'final bot_sol'))
from btc_futures_scalping import calculate_supertrend, calculate_adx, calculate_atr
from swing_supertrend_strategy import (
    identify_swing_points,
    calculate_288_ema,
    get_most_recent_swing
)

# Helper function for EMA
def calculate_ema(df, period=288, column='close'):
    return calculate_288_ema(df)


class OptionsSellingBacktest:
    def __init__(self, config, df_1min, df_5min, df_30min):
        self.config = config
        self.df_1min = df_1min
        self.df_5min = df_5min
        self.df_30min = df_30min

        # Track positions
        self.current_position = None
        self.trades = []
        self.equity_curve = []

        # Statistics
        self.stats = {
            'total_trades': 0,
            'winning_trades': 0,
            'losing_trades': 0,
            'total_pnl': 0.0,
            'gross_profit': 0.0,
            'gross_loss': 0.0,
            'peak_equity': 0.0,
            'max_drawdown': 0.0,
            'max_drawdown_pct': 0.0,
            'final_equity': 0.0
        }

        # Cooldown tracking
        self.last_exit_time = None

        # Risk-free rate (annual)
        self.risk_free_rate = 0.05  # 5% annual

        # Strike interval based on asset
        if self.config.get('TRADING_SYMBOL') == 'BTCUSD':
            self.strike_interval = 200  # BTC strike interval
        elif self.config.get('TRADING_SYMBOL') == 'ETHUSD':
            self.strike_interval = 20   # ETH strike interval
        elif self.config.get('TRADING_SYMBOL') == 'SOLUSD':
            self.strike_interval = 5    # SOL strike interval
        else:
            self.strike_interval = 500  # Default

    def calculate_indicators(self):
        """Calculate all required indicators"""
        print("\n[CALCULATING INDICATORS]")

        # 5-minute indicators
        print("  Calculating 5-minute indicators...")
        self.df_5min['ema_288'] = calculate_ema(self.df_5min, period=288)
        self.df_5min['adx'] = calculate_adx(self.df_5min, period=14)

        # Identify swing points
        print(f"    - Swing Points (lookback={self.config.get('SWING_LOOKBACK_CANDLES', 4)})")
        self.df_5min = identify_swing_points(
            self.df_5min,
            lookback=self.config.get('SWING_LOOKBACK_CANDLES', 4),
            confirmation=self.config.get('SWING_CONFIRMATION_CANDLES', 3)
        )

        # 30-minute SuperTrend
        print("  Calculating 30-minute indicators...")
        if self.config.get('USE_SUPERTREND_FILTER', True):
            st_30m, dir_30m = calculate_supertrend(
                self.df_30min,
                period=self.config.get('SUPERTREND_PERIOD', 10),
                multiplier=self.config.get('SUPERTREND_MULTIPLIER', 3.0)
            )
            self.df_30min['supertrend'] = st_30m
            self.df_30min['st_direction'] = dir_30m
            print(f"    - SuperTrend Filter")

        print("  Indicators calculated successfully")
        print("="*80)

    def run(self):
        """Run options backtest simulation"""
        print("\n[STARTING OPTIONS BACKTEST SIMULATION]")
        print(f"Start Time: {self.df_1min['timestamp'].min()}")
        print(f"End Time: {self.df_1min['timestamp'].max()}")
        print(f"Strategy: Sell ATM Weekly Options")
        print("="*80)

        # Initialize equity
        initial_capital = self.config.get('ACCOUNT_SIZE', 10000)
        current_equity = initial_capital
        self.stats['peak_equity'] = current_equity

        # Pre-flight conditions tracking
        long_conditions_met = False
        short_conditions_met = False

        # Track progress
        total_5min_candles = len(self.df_5min)
        candles_processed = 0
        last_progress_pct = 0

        # Iterate through 5-minute candles
        for idx_5min in range(len(self.df_5min)):
            candle_5min = self.df_5min.iloc[idx_5min]
            candle_time = candle_5min['timestamp']

            # Progress reporting
            candles_processed += 1
            progress_pct = int((candles_processed / total_5min_candles) * 100)
            if progress_pct >= last_progress_pct + 10:
                print(f"Progress: {progress_pct}% ({candles_processed:,}/{total_5min_candles:,} candles) - {candle_time.date()}")
                last_progress_pct = progress_pct

            # Check if option expired
            if self.current_position:
                if candle_time >= self.current_position['expiry_time']:
                    self._exit_option_at_expiry(candle_time, candle_5min['close'])
                    current_equity = initial_capital + self.stats['total_pnl']
                    self._update_equity(current_equity)

            # Check cooldown period
            if self.last_exit_time is not None:
                time_since_exit = (candle_time - self.last_exit_time).total_seconds()
                cooldown_seconds = self.config.get('COOLDOWN_PERIOD_SECONDS', 600)

                if time_since_exit < cooldown_seconds:
                    # Monitor position during cooldown
                    if self.current_position:
                        self._monitor_position_on_5min_candle(idx_5min, candle_5min['close'])
                        current_equity = initial_capital + self.stats['total_pnl']
                        self._update_equity(current_equity)
                    continue
                else:
                    self.last_exit_time = None

            # Update conditions on each 5-min candle close
            if not self.current_position:
                # Need enough historical data
                if idx_5min < 300:
                    continue

                # No new trades on Friday
                if is_friday_no_trade_zone(candle_time):
                    continue

                # Get latest values
                latest_close = candle_5min['close']
                ema_288_value = candle_5min.get('ema_288', None)
                adx_value = candle_5min.get('adx', None)

                if pd.isna(ema_288_value) or pd.isna(adx_value):
                    continue

                if adx_value < self.config.get('ADX_THRESHOLD', 26):
                    continue

                # Get SuperTrend direction
                df_30min_up_to_now = self.df_30min[self.df_30min['timestamp'] <= candle_time]
                if len(df_30min_up_to_now) == 0:
                    continue
                latest_30min = df_30min_up_to_now.iloc[-1]
                supertrend_direction = latest_30min.get('st_direction', None)
                if pd.isna(supertrend_direction):
                    continue

                # Get most recent swing points
                df_5min_up_to_now = self.df_5min.iloc[:idx_5min+1]
                swing_high, swing_high_idx = get_most_recent_swing(
                    df_5min_up_to_now, 'high', before_index=len(df_5min_up_to_now)-1
                )
                swing_low, swing_low_idx = get_most_recent_swing(
                    df_5min_up_to_now, 'low', before_index=len(df_5min_up_to_now)-1
                )

                # Check LONG conditions (Sell PUT)
                if (latest_close > ema_288_value and
                    supertrend_direction == 1 and
                    swing_high is not None):
                    if not long_conditions_met:
                        long_conditions_met = True
                    # Check for entry trigger (breakout above swing high)
                    if latest_close > swing_high:
                        self._enter_option_position('PUT', candle_time, latest_close,
                                                   swing_high, swing_low, idx_5min)
                        long_conditions_met = False

                # Check SHORT conditions (Sell CALL)
                elif (latest_close < ema_288_value and
                      supertrend_direction == -1 and
                      swing_low is not None):
                    if not short_conditions_met:
                        short_conditions_met = True
                    # Check for entry trigger (breakdown below swing low)
                    if latest_close < swing_low:
                        self._enter_option_position('CALL', candle_time, latest_close,
                                                   swing_high, swing_low, idx_5min)
                        short_conditions_met = False
                else:
                    long_conditions_met = False
                    short_conditions_met = False

            # Monitor existing position
            if self.current_position:
                self._monitor_position_on_5min_candle(idx_5min, latest_close)

            # Update equity
            current_equity = initial_capital + self.stats['total_pnl']
            self._update_equity(current_equity)

        print("\n" + "="*80)
        print("[BACKTEST COMPLETE]")
        print("="*80)

        # Generate results
        self._generate_results()

        return self

    def _enter_option_position(self, option_type, entry_time, spot_price,
                               swing_high, swing_low, idx_5min):
        """Enter an option position (sell ATM option)"""
        # Calculate ATM strike
        strike = find_atm_strike(spot_price, self.strike_interval)

        # Get expiry (intraday/next-day at 5:30 PM IST)
        expiry_time = get_next_day_expiry(entry_time)

        # Calculate time to expiry
        tte = time_to_expiry_years(entry_time, expiry_time)

        # Calculate historical volatility
        df_5min_history = self.df_5min.iloc[:idx_5min+1]
        volatility = calculate_implied_volatility_from_historical(df_5min_history, lookback_days=30)

        # Calculate option premium using Black-Scholes
        option_premium = black_scholes(
            S=spot_price,
            K=strike,
            T=tte,
            r=self.risk_free_rate,
            sigma=volatility,
            option_type='call' if option_type == 'CALL' else 'put'
        )

        # Position sizing (sell 1 contract worth $5000 notional)
        position_size_usd = self.config.get('POSITION_SIZE', 5000)
        num_contracts = position_size_usd / strike  # For BTC options, 1 contract = 0.001 BTC

        # Premium received (credit)
        premium_received = option_premium * num_contracts

        # Set stop levels based on swing points
        if option_type == 'PUT':
            stop_level = swing_low  # Exit if price breaks below swing low
        else:  # CALL
            stop_level = swing_high  # Exit if price breaks above swing high

        self.current_position = {
            'option_type': option_type,
            'entry_time': entry_time,
            'expiry_time': expiry_time,
            'spot_at_entry': spot_price,
            'strike': strike,
            'premium_received': premium_received,
            'volatility': volatility,
            'num_contracts': num_contracts,
            'stop_level': stop_level,
            'highest_price': spot_price,
            'lowest_price': spot_price
        }

        # Print entry
        entry_time_ist = entry_time + timedelta(hours=5, minutes=30)
        expiry_time_ist = expiry_time + timedelta(hours=5, minutes=30)
        print(f"\n[ENTRY] SELL {option_type} @ Strike ${strike:.0f}")
        print(f"  Time: {entry_time_ist.strftime('%Y-%m-%d %H:%M:%S')} IST")
        print(f"  Spot: ${spot_price:.2f}")
        print(f"  Premium Received: ${premium_received:.2f}")
        print(f"  Expiry: {expiry_time_ist.strftime('%Y-%m-%d %H:%M:%S')} IST")
        print(f"  Stop Level: ${stop_level:.2f}")

    def _monitor_position_on_5min_candle(self, idx_5min, current_price):
        """Monitor option position and check for exit conditions"""
        if not self.current_position:
            return

        pos = self.current_position
        candle_5min = self.df_5min.iloc[idx_5min]

        # Update highest/lowest
        pos['highest_price'] = max(pos['highest_price'], candle_5min['high'])
        pos['lowest_price'] = min(pos['lowest_price'], candle_5min['low'])

        # Check stop condition
        if pos['option_type'] == 'PUT':
            # Exit if price breaks below stop (bearish for sold put)
            if candle_5min['low'] <= pos['stop_level']:
                self._exit_option_position(candle_5min['timestamp'], current_price, 'Stop Hit')
        else:  # CALL
            # Exit if price breaks above stop (bullish for sold call)
            if candle_5min['high'] >= pos['stop_level']:
                self._exit_option_position(candle_5min['timestamp'], current_price, 'Stop Hit')

    def _exit_option_position(self, exit_time, spot_price, exit_reason):
        """Exit option position (buy back the option)"""
        pos = self.current_position

        # Calculate time to expiry
        tte = time_to_expiry_years(exit_time, pos['expiry_time'])

        # Calculate option price at exit using Black-Scholes
        exit_premium = black_scholes(
            S=spot_price,
            K=pos['strike'],
            T=tte,
            r=self.risk_free_rate,
            sigma=pos['volatility'],
            option_type='call' if pos['option_type'] == 'CALL' else 'put'
        )

        # Cost to buy back
        buyback_cost = exit_premium * pos['num_contracts']

        # Calculate P&L (credit received - cost to buy back)
        gross_pnl = pos['premium_received'] - buyback_cost

        # Commission (0.05% on entry and exit)
        commission_rate = self.config.get('COMMISSION_RATE', 0.0005)
        entry_commission = pos['premium_received'] * commission_rate
        exit_commission = buyback_cost * commission_rate
        total_commission = entry_commission + exit_commission

        net_pnl = gross_pnl - total_commission
        pnl_pct = (net_pnl / pos['premium_received']) * 100 if pos['premium_received'] > 0 else 0

        # Calculate hold time
        hold_time = (exit_time - pos['entry_time']).total_seconds() / 60

        # Store trade
        entry_time_ist = pos['entry_time'] + timedelta(hours=5, minutes=30)
        exit_time_ist = exit_time + timedelta(hours=5, minutes=30)

        trade = {
            'entry_time_ist': entry_time_ist,
            'exit_time_ist': exit_time_ist,
            'option_type': pos['option_type'],
            'strike': pos['strike'],
            'spot_at_entry': pos['spot_at_entry'],
            'spot_at_exit': spot_price,
            'premium_received': pos['premium_received'],
            'buyback_cost': buyback_cost,
            'exit_reason': exit_reason,
            'hold_time_minutes': hold_time,
            'gross_pnl': gross_pnl,
            'commission': total_commission,
            'net_pnl': net_pnl,
            'pnl_pct': pnl_pct
        }

        self.trades.append(trade)

        # Update statistics
        self.stats['total_trades'] += 1
        self.stats['total_pnl'] += net_pnl

        if net_pnl > 0:
            self.stats['winning_trades'] += 1
            self.stats['gross_profit'] += net_pnl
        else:
            self.stats['losing_trades'] += 1
            self.stats['gross_loss'] += abs(net_pnl)

        # Print exit
        print(f"\n[EXIT] BUY BACK {pos['option_type']} @ ${buyback_cost:.2f}")
        print(f"  Time: {exit_time_ist.strftime('%Y-%m-%d %H:%M:%S')} IST")
        print(f"  Reason: {exit_reason}")
        print(f"  P&L: ${net_pnl:.2f} ({pnl_pct:+.2f}%)")
        print(f"  Hold Time: {hold_time:.0f} minutes")

        # Set cooldown
        self.last_exit_time = exit_time
        self.current_position = None

    def _exit_option_at_expiry(self, expiry_time, spot_price):
        """Exit option at expiry (intrinsic value)"""
        pos = self.current_position

        # At expiry, option worth intrinsic value
        if pos['option_type'] == 'CALL':
            intrinsic_value = max(0, spot_price - pos['strike'])
        else:  # PUT
            intrinsic_value = max(0, pos['strike'] - spot_price)

        # Cost is the intrinsic value * contracts
        buyback_cost = intrinsic_value * pos['num_contracts']

        # Calculate P&L
        gross_pnl = pos['premium_received'] - buyback_cost

        # Commission
        commission_rate = self.config.get('COMMISSION_RATE', 0.0005)
        entry_commission = pos['premium_received'] * commission_rate
        exit_commission = buyback_cost * commission_rate if buyback_cost > 0 else 0
        total_commission = entry_commission + exit_commission

        net_pnl = gross_pnl - total_commission
        pnl_pct = (net_pnl / pos['premium_received']) * 100 if pos['premium_received'] > 0 else 0

        # Calculate hold time
        hold_time = (expiry_time - pos['entry_time']).total_seconds() / 60

        # Store trade
        entry_time_ist = pos['entry_time'] + timedelta(hours=5, minutes=30)
        expiry_time_ist = expiry_time + timedelta(hours=5, minutes=30)

        trade = {
            'entry_time_ist': entry_time_ist,
            'exit_time_ist': expiry_time_ist,
            'option_type': pos['option_type'],
            'strike': pos['strike'],
            'spot_at_entry': pos['spot_at_entry'],
            'spot_at_exit': spot_price,
            'premium_received': pos['premium_received'],
            'buyback_cost': buyback_cost,
            'exit_reason': 'Expiry',
            'hold_time_minutes': hold_time,
            'gross_pnl': gross_pnl,
            'commission': total_commission,
            'net_pnl': net_pnl,
            'pnl_pct': pnl_pct
        }

        self.trades.append(trade)

        # Update statistics
        self.stats['total_trades'] += 1
        self.stats['total_pnl'] += net_pnl

        if net_pnl > 0:
            self.stats['winning_trades'] += 1
            self.stats['gross_profit'] += net_pnl
        else:
            self.stats['losing_trades'] += 1
            self.stats['gross_loss'] += abs(net_pnl)

        # Print exit
        print(f"\n[EXPIRY] {pos['option_type']} EXPIRED")
        print(f"  Time: {expiry_time_ist.strftime('%Y-%m-%d %H:%M:%S')} IST")
        print(f"  Intrinsic Value: ${buyback_cost:.2f}")
        print(f"  P&L: ${net_pnl:.2f} ({pnl_pct:+.2f}%)")

        # Set cooldown
        self.last_exit_time = expiry_time
        self.current_position = None

    def _update_equity(self, current_equity):
        """Update equity curve and drawdown"""
        # Update peak equity
        if current_equity > self.stats['peak_equity']:
            self.stats['peak_equity'] = current_equity

        # Calculate drawdown
        drawdown = self.stats['peak_equity'] - current_equity
        initial_capital = self.config.get('ACCOUNT_SIZE', 10000)
        drawdown_pct = (drawdown / initial_capital) * 100

        # Update max drawdown
        if drawdown > self.stats['max_drawdown']:
            self.stats['max_drawdown'] = drawdown
            self.stats['max_drawdown_pct'] = drawdown_pct

        # Store final equity
        self.stats['final_equity'] = current_equity

    def _generate_results(self):
        """Generate and display backtest results"""
        print("\n" + "="*80)
        print("BACKTEST RESULTS - OPTIONS SELLING STRATEGY")
        print("="*80)

        print("\nOverall Performance:")
        print(f"  Total Trades: {self.stats['total_trades']}")
        if self.stats['total_trades'] > 0:
            win_rate = (self.stats['winning_trades'] / self.stats['total_trades']) * 100
            print(f"  Winning Trades: {self.stats['winning_trades']} ({win_rate:.2f}%)")
            print(f"  Losing Trades: {self.stats['losing_trades']}")
        print(f"  Total P&L: ${self.stats['total_pnl']:.2f}")
        print(f"  Gross Profit: ${self.stats['gross_profit']:.2f}")
        print(f"  Gross Loss: ${self.stats['gross_loss']:.2f}")

        if self.stats['gross_loss'] > 0:
            profit_factor = self.stats['gross_profit'] / self.stats['gross_loss']
            print(f"  Profit Factor: {profit_factor:.2f}")

        print(f"  Max Drawdown: ${self.stats['max_drawdown']:.2f} ({self.stats['max_drawdown_pct']:.2f}%)")
        print(f"  Final Equity: ${self.stats['final_equity']:.2f}")

        # Save reports
        self._save_reports()

    def _save_reports(self):
        """Save trade logs and summary"""
        symbol = self.config.get('TRADING_SYMBOL', 'BTCUSD')
        quarter = self.config.get('BACKTEST_QUARTER', 'Q4')
        year = self.config.get('BACKTEST_YEAR', '2025')

        asset_name = symbol.replace('USD', '')
        output_dir = os.path.join(os.path.dirname(__file__), '..', 'latest_reports', asset_name)
        os.makedirs(output_dir, exist_ok=True)

        # Save trades CSV
        trades_file = os.path.join(output_dir, f'trades_options_{symbol}_{quarter}_{year}.csv')
        if self.trades:
            df_trades = pd.DataFrame(self.trades)
            df_trades.to_csv(trades_file, index=False)
            print(f"\nReports saved:")
            print(f"  Trades CSV: {trades_file}")

        # Save summary
        summary_file = os.path.join(output_dir, f'summary_options_{symbol}_{quarter}_{year}.txt')
        with open(summary_file, 'w') as f:
            f.write("="*80 + "\n")
            f.write("OPTIONS SELLING STRATEGY - BACKTEST SUMMARY\n")
            f.write("="*80 + "\n")
            f.write(f"Symbol: {symbol}\n")
            f.write(f"Period: {quarter} {year}\n")
            f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write("="*80 + "\n\n")
            f.write("Overall Performance:\n")
            f.write(f"  Total Trades: {self.stats['total_trades']}\n")
            if self.stats['total_trades'] > 0:
                win_rate = (self.stats['winning_trades'] / self.stats['total_trades']) * 100
                f.write(f"  Winning Trades: {self.stats['winning_trades']} ({win_rate:.2f}%)\n")
                f.write(f"  Losing Trades: {self.stats['losing_trades']}\n")
            f.write(f"  Total P&L: ${self.stats['total_pnl']:.2f}\n")
            f.write(f"  Gross Profit: ${self.stats['gross_profit']:.2f}\n")
            f.write(f"  Gross Loss: ${self.stats['gross_loss']:.2f}\n")
            if self.stats['gross_loss'] > 0:
                profit_factor = self.stats['gross_profit'] / self.stats['gross_loss']
                f.write(f"  Profit Factor: {profit_factor:.2f}\n")
            f.write(f"  Max Drawdown: ${self.stats['max_drawdown']:.2f} ({self.stats['max_drawdown_pct']:.2f}%)\n")
            f.write(f"  Final Equity: ${self.stats['final_equity']:.2f}\n")

        print(f"  Summary: {summary_file}")
        print("="*80)
