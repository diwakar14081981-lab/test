from run_backtest_config import get_default_config, run_backtest

# Solana Q4 2024 with 1-day SuperTrend
config = get_default_config()
config['SUPERTREND_TIMEFRAME'] = '1d'
config['ADX_THRESHOLD'] = 26

data_paths = {
    '1min': 'D:/Latest_Bot/Data/Solana/Q4_2024/Solana_1min_Q4_2024.csv',
    '5min': 'D:/Latest_Bot/Data/Solana/Q4_2024/Solana_5min_Q4_2024.csv',
    '30min': 'D:/Latest_Bot/Data/Solana/Q4_2024/Solana_1day_Q4_2024.csv'
}

bt = run_backtest(config, data_paths, 'Solana Q4 2024 - 1day SuperTrend')

print(f'\n\n{"="*80}')
print("QUICK SUMMARY - 1-DAY SUPERTREND")
print("="*80)
print(f'Trades: {bt.stats["total_trades"]}')
print(f'Win Rate: {bt.stats["winning_trades"]/bt.stats["total_trades"]*100:.2f}%')
print(f'Total P&L: ${bt.stats["total_pnl"]:.2f}')
if bt.stats['gross_loss'] > 0:
    print(f'Profit Factor: {bt.stats["gross_profit"]/bt.stats["gross_loss"]:.2f}')
print(f'Max Drawdown: ${bt.stats["max_drawdown"]:.2f} ({bt.stats["max_drawdown_pct"]:.2f}%)')
print("="*80)
