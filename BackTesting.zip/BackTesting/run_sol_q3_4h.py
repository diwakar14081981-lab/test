"""
Generate Solana Q3 2025 trades with 4-hour SuperTrend
"""

from run_backtest_config import get_default_config, run_backtest

# Configure for Solana Q3 2025 with 4-hour SuperTrend
config = get_default_config()
config['TRADING_SYMBOL'] = 'SOLUSD'
config['SUPERTREND_TIMEFRAME'] = '4h'
config['ADX_THRESHOLD'] = 26
config['BACKTEST_QUARTER'] = 'Q3'
config['BACKTEST_YEAR'] = '2025'

data_paths = {
    '1min': 'D:/Latest_Bot/Data/Solana/Q3_2025/Solana_1min_Q3_2025.csv',
    '5min': 'D:/Latest_Bot/Data/Solana/Q3_2025/Solana_5min_Q3_2025.csv',
    '30min': 'D:/Latest_Bot/Data/Solana/Q3_2025/Solana_4hour_Q3_2025.csv'
}

bt = run_backtest(config, data_paths, 'Solana Q3 2025 - 4hour ST')

print('\n' + '='*80)
print('BACKTEST COMPLETED SUCCESSFULLY!')
print('='*80)
print(f'Reports saved in: D:\\Latest_Bot\\latest_reports\\SOL\\')
print(f'  - trades_SOLUSD_Q3_2025.csv')
print(f'  - summary_SOLUSD_Q3_2025.txt')
print('='*80)
