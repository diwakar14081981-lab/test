"""
Run Options Selling Strategy Backtest for BTC Q4 2025
Compares with Futures strategy results
"""

import pandas as pd
import os
from options_strategy_backtest import OptionsSellingBacktest

# Configuration
config = {
    'TRADING_SYMBOL': 'BTCUSD',
    'SUPERTREND_TIMEFRAME': '4h',
    'SUPERTREND_PERIOD': 10,
    'SUPERTREND_MULTIPLIER': 3.0,
    'ADX_THRESHOLD': 26,
    'USE_288_EMA_FILTER': True,
    'USE_SUPERTREND_FILTER': True,
    'USE_ADX_FILTER': True,
    'SWING_LOOKBACK_CANDLES': 4,
    'SWING_CONFIRMATION_CANDLES': 3,
    'POSITION_SIZE': 5000,
    'ACCOUNT_SIZE': 10000,
    'COMMISSION_RATE': 0.0005,
    'COOLDOWN_PERIOD_SECONDS': 600,
    'BACKTEST_QUARTER': 'Q4',
    'BACKTEST_YEAR': '2025'
}

# Data paths
data_dir = 'D:/Latest_Bot/Data/BTC/Q4_2025'
df_1min = pd.read_csv(f'{data_dir}/BTC_1min_Q4_2025.csv')
df_5min = pd.read_csv(f'{data_dir}/BTC_5min_Q4_2025.csv')
df_30min = pd.read_csv(f'{data_dir}/BTC_4hour_Q4_2025.csv')

# Convert timestamps (use datetime column instead of Unix timestamp)
for df in [df_1min, df_5min, df_30min]:
    if 'datetime' in df.columns:
        df['timestamp'] = pd.to_datetime(df['datetime'])
    else:
        df['timestamp'] = pd.to_datetime(df['timestamp'], unit='s')

print("="*80)
print("BTC Q4 2025 - OPTIONS SELLING STRATEGY BACKTEST")
print("="*80)
print(f"Period: Oct 1 - Nov 18, 2025")
print(f"Strategy: Sell ATM Weekly Options")
print(f"  - LONG signal -> Sell ATM Put")
print(f"  - SHORT signal -> Sell ATM Call")
print(f"  - No trades on Friday (expiry day)")
print("="*80)

# Run backtest
bt = OptionsSellingBacktest(config, df_1min, df_5min, df_30min)
bt.calculate_indicators()
bt.run()

print("\n" + "="*80)
print("COMPARISON WITH FUTURES STRATEGY")
print("="*80)
print("\nFutures Strategy Results (from previous backtest):")
print("  Total Trades: 133")
print("  Win Rate: 48.12%")
print("  Total P&L: $1,651.84")
print("  Profit Factor: 2.47")
print("  Max Drawdown: $106.37 (1.06%)")
print("\nOptions Strategy Results (current backtest):")
print(f"  Total Trades: {bt.stats['total_trades']}")
if bt.stats['total_trades'] > 0:
    win_rate = (bt.stats['winning_trades'] / bt.stats['total_trades']) * 100
    print(f"  Win Rate: {win_rate:.2f}%")
print(f"  Total P&L: ${bt.stats['total_pnl']:.2f}")
if bt.stats['gross_loss'] > 0:
    profit_factor = bt.stats['gross_profit'] / bt.stats['gross_loss']
    print(f"  Profit Factor: {profit_factor:.2f}")
print(f"  Max Drawdown: ${bt.stats['max_drawdown']:.2f} ({bt.stats['max_drawdown_pct']:.2f}%)")
print("="*80)
