"""
Black-Scholes option pricing for backtesting
"""
import numpy as np
from scipy.stats import norm
from datetime import datetime, timedelta

def black_scholes(S, K, T, r, sigma, option_type='call'):
    """
    Calculate Black-Scholes option price

    Parameters:
    S: Current stock price
    K: Strike price
    T: Time to expiration in years
    r: Risk-free rate (annual)
    sigma: Volatility (annual)
    option_type: 'call' or 'put'

    Returns:
    option_price: Theoretical option price
    """
    if T <= 0:
        # At expiry
        if option_type == 'call':
            return max(0, S - K)
        else:
            return max(0, K - S)

    d1 = (np.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T))
    d2 = d1 - sigma * np.sqrt(T)

    if option_type == 'call':
        price = S * norm.cdf(d1) - K * np.exp(-r * T) * norm.cdf(d2)
    else:  # put
        price = K * np.exp(-r * T) * norm.cdf(-d2) - S * norm.cdf(-d1)

    return price


def calculate_implied_volatility_from_historical(df, lookback_days=30):
    """
    Calculate historical volatility from price data

    Parameters:
    df: DataFrame with 'close' prices and 'timestamp'
    lookback_days: Number of days to look back

    Returns:
    annualized_volatility: Historical volatility (annualized)
    """
    # Calculate log returns
    returns = np.log(df['close'] / df['close'].shift(1))

    # Use last N days
    returns_window = returns.tail(lookback_days * 288)  # 288 5-min candles per day

    # Calculate standard deviation
    std_dev = returns_window.std()

    # Annualize (assuming 365 days, 24 hours trading)
    # sqrt(365 * 24 * 12) for 5-min candles
    annualized_vol = std_dev * np.sqrt(365 * 24 * 12)

    return annualized_vol


def find_atm_strike(spot_price, strike_interval=500):
    """
    Find the ATM (At The Money) strike price

    Parameters:
    spot_price: Current spot price
    strike_interval: Strike price interval (e.g., 500 for BTC)

    Returns:
    atm_strike: Nearest ATM strike
    """
    # Round to nearest strike interval
    atm_strike = round(spot_price / strike_interval) * strike_interval
    return atm_strike


def get_next_day_expiry(current_time):
    """
    Get intraday/next-day expiry at 5:30 PM IST
    Logic matches live bot:
    - Before 3:00 PM IST: Use CURRENT DATE expiry at 5:30 PM (maximize theta decay)
    - After 3:00 PM IST: Use NEXT DAY expiry at 5:30 PM (avoid late expiry risk)

    Parameters:
    current_time: Current datetime (UTC)

    Returns:
    expiry_time: Expiry datetime (UTC)
    """
    # Convert to IST
    ist_time = current_time + timedelta(hours=5, minutes=30)
    current_hour = ist_time.hour

    if current_hour < 15:  # Before 3:00 PM
        # Use current date expiry at 17:30 IST
        expiry_date = ist_time.date()
    else:  # 3:00 PM or later
        # Use next day expiry at 17:30 IST
        expiry_date = ist_time.date() + timedelta(days=1)

    # Set expiry time to 5:30 PM IST
    expiry_datetime_ist = datetime.combine(expiry_date, datetime.strptime('17:30', '%H:%M').time())

    # Convert back to UTC
    expiry_datetime_utc = expiry_datetime_ist - timedelta(hours=5, minutes=30)

    return expiry_datetime_utc


def get_next_friday_expiry(current_time):
    """
    Get next Friday 5:30 PM IST expiry
    If current time is Friday, use NEXT Friday (not same day)

    Parameters:
    current_time: Current datetime (UTC)

    Returns:
    expiry_time: Next Friday expiry datetime (UTC)
    """
    # Convert to IST
    ist_time = current_time + timedelta(hours=5, minutes=30)

    # Find next Friday
    days_until_friday = (4 - ist_time.weekday()) % 7

    if days_until_friday == 0:
        # Today is Friday, always use NEXT Friday (7 days from now)
        next_friday = ist_time.date() + timedelta(days=7)
    else:
        # Use the upcoming Friday
        next_friday = ist_time.date() + timedelta(days=days_until_friday)

    # Set expiry time to 5:30 PM IST (12:00 PM UTC)
    expiry_datetime_ist = datetime.combine(next_friday, datetime.strptime('17:30', '%H:%M').time())

    # Convert back to UTC
    expiry_datetime_utc = expiry_datetime_ist - timedelta(hours=5, minutes=30)

    return expiry_datetime_utc


def is_friday_no_trade_zone(current_time):
    """
    Check if current time is Friday (no new trades on Friday)

    Parameters:
    current_time: Current datetime (UTC)

    Returns:
    bool: True if Friday in IST timezone
    """
    ist_time = current_time + timedelta(hours=5, minutes=30)
    return ist_time.weekday() == 4  # Friday


def time_to_expiry_years(current_time, expiry_time):
    """
    Calculate time to expiry in years

    Parameters:
    current_time: Current datetime
    expiry_time: Expiry datetime

    Returns:
    years: Time to expiry in years
    """
    time_diff = expiry_time - current_time
    years = time_diff.total_seconds() / (365.25 * 24 * 3600)
    return max(0, years)
