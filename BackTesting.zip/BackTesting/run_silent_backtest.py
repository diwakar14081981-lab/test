"""
Silent Backtest Runner - Runs backtests in background without console output
Results are saved to files only
"""

import sys
import os
import pandas as pd
from io import StringIO
from datetime import datetime
from run_backtest_config import get_default_config, get_data_paths
from swing_strategy_backtest import SwingStrategyBacktest


def run_silent_backtest(asset, quarter, year, config_overrides=None, description=""):
    """
    Run backtest silently and save results to file

    Args:
        asset: 'BTC', 'Ethereum', or 'Solana'
        quarter: 'Q1', 'Q2', 'Q3', or 'Q4'
        year: 2024 or 2025
        config_overrides: Dict of config parameters to override
        description: Description for the run

    Returns:
        Path to results CSV file
    """
    # Suppress all print output
    old_stdout = sys.stdout
    sys.stdout = StringIO()

    try:
        # Get config
        config = get_default_config()

        # Set trading symbol
        if asset == 'BTC':
            config['TRADING_SYMBOL'] = 'BTCUSD'
        elif asset == 'Ethereum':
            config['TRADING_SYMBOL'] = 'ETHUSD'
        elif asset == 'Solana':
            config['TRADING_SYMBOL'] = 'SOLUSD'

        # Apply overrides
        if config_overrides:
            config.update(config_overrides)

        # Get data paths
        data_paths = get_data_paths(asset, quarter, year)

        # Initialize backtest
        backtest = SwingStrategyBacktest(config)

        # Load data
        backtest.load_data(
            data_1min_path=data_paths['1min'],
            data_5min_path=data_paths.get('5min'),
            data_30min_path=data_paths.get('30min')
        )

        # Calculate indicators
        backtest.calculate_indicators()

        # Run simulation
        backtest.run()

        # Generate results (this prints and saves CSV)
        backtest._generate_results()

        # Capture stats for summary
        stats = backtest.stats

        # Save results
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        output_dir = os.path.join(os.path.dirname(__file__), '..', 'Temp')
        os.makedirs(output_dir, exist_ok=True)

        # CSV filename
        csv_filename = f"backtest_{config['TRADING_SYMBOL']}_{quarter}_{year}_{timestamp}.csv"
        csv_path = os.path.join(output_dir, csv_filename)

        # Summary filename
        summary_filename = f"summary_{config['TRADING_SYMBOL']}_{quarter}_{year}_{timestamp}.txt"
        summary_path = os.path.join(output_dir, summary_filename)

        # Calculate trade metrics
        df_trades = pd.DataFrame(backtest.trades) if backtest.trades else None

        # Write summary
        with open(summary_path, 'w') as f:
            f.write("="*80 + "\n")
            f.write("BACKTEST RESULTS\n")
            f.write("="*80 + "\n")
            if description:
                f.write(f"Description: {description}\n")
            f.write(f"Asset: {config['TRADING_SYMBOL']}\n")
            f.write(f"Period: {asset} {quarter} {year}\n")
            f.write(f"ADX Threshold: {config.get('ADX_THRESHOLD', 26)}\n")
            f.write(f"288 EMA Filter: {config.get('USE_288_EMA_FILTER', True)}\n")
            f.write(f"SuperTrend Filter: {config.get('USE_SUPERTREND_FILTER', True)}\n")
            f.write(f"SuperTrend Timeframe: {config.get('SUPERTREND_TIMEFRAME', '30m')}\n")
            f.write("="*80 + "\n\n")

            if stats['total_trades'] > 0:
                win_rate = (stats['winning_trades'] / stats['total_trades'] * 100)
                profit_factor = (stats['gross_profit'] / stats['gross_loss']) if stats['gross_loss'] > 0 else 0

                f.write(f"Overall Performance:\n")
                f.write(f"  Total Trades: {stats['total_trades']}\n")
                f.write(f"  Winning Trades: {stats['winning_trades']} ({win_rate:.2f}%)\n")
                f.write(f"  Losing Trades: {stats['losing_trades']}\n")
                f.write(f"  Total P&L: ${stats['total_pnl']:,.2f}\n")
                f.write(f"  Gross Profit: ${stats['gross_profit']:,.2f}\n")
                f.write(f"  Gross Loss: ${stats['gross_loss']:,.2f}\n")
                f.write(f"  Profit Factor: {profit_factor:.2f}\n")
                f.write(f"  Max Drawdown: ${stats['max_drawdown']:,.2f} ({stats['max_drawdown_pct']:.2f}%)\n")

                if df_trades is not None:
                    long_trades = df_trades[df_trades['direction'] == 'LONG']
                    short_trades = df_trades[df_trades['direction'] == 'SHORT']

                    if len(long_trades) > 0:
                        long_win_rate = (len(long_trades[long_trades['net_pnl'] > 0]) / len(long_trades)) * 100
                        long_pnl = long_trades['net_pnl'].sum()
                        f.write(f"\nLONG Trades:\n")
                        f.write(f"  Count: {len(long_trades)}\n")
                        f.write(f"  Win Rate: {long_win_rate:.2f}%\n")
                        f.write(f"  Total P&L: ${long_pnl:,.2f}\n")

                    if len(short_trades) > 0:
                        short_win_rate = (len(short_trades[short_trades['net_pnl'] > 0]) / len(short_trades)) * 100
                        short_pnl = short_trades['net_pnl'].sum()
                        f.write(f"\nSHORT Trades:\n")
                        f.write(f"  Count: {len(short_trades)}\n")
                        f.write(f"  Win Rate: {short_win_rate:.2f}%\n")
                        f.write(f"  Total P&L: ${short_pnl:,.2f}\n")
            else:
                f.write("No trades executed\n")

        return csv_path, summary_path, backtest

    finally:
        # Restore stdout
        sys.stdout = old_stdout


if __name__ == "__main__":
    # Run Solana Q4 2024 with ADX=26
    print("Starting backtest: Solana Q4 2024, ADX=26...")
    csv_path, summary_path, bt = run_silent_backtest(
        'Solana', 'Q4', '2024',
        config_overrides={'ADX_THRESHOLD': 26},
        description="Solana Q4 2024 - ADX Threshold 26 - EXACT ENTRY/EXIT"
    )

    print(f"\n✓ Backtest completed!")
    print(f"  Trades CSV: {csv_path}")
    print(f"  Summary: {summary_path}")
    print(f"\n--- SUMMARY ---")
    with open(summary_path, 'r') as f:
        print(f.read())
