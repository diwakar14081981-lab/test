"""
ETH August 2025 Backtest Comparison: Futures vs Options
Runs both strategies on same data and compares results
"""

import sys
import os
from datetime import datetime
import pandas as pd

# Add paths
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'final_bot'))

from swing_strategy_backtest import SwingStrategyBacktest
from options_strategy_backtest import OptionsSellingBacktest
from run_backtest_config import get_default_config, get_data_paths


def run_eth_q3_2025_comparison():
    """
    Run ETH Q3 2025 (includes August) with both futures and options strategies
    Compare the results side by side
    """
    print("\n" + "="*100)
    print("ETH AUGUST 2025 BACKTEST - FUTURES vs OPTIONS COMPARISON")
    print("="*100)

    # Get configuration
    config = get_default_config()
    config['TRADING_SYMBOL'] = 'ETHUSD'
    config['POSITION_SIZE_DOLLARS'] = 10000  # $10k per trade
    config['LEVERAGE'] = 1

    # Get data paths for Ethereum Q3 2025
    data_paths = get_data_paths('Ethereum', 'Q3', '2025')

    print(f"\nData Period: Ethereum AUGUST 2025 ONLY")
    print(f"Position Size: ${config['POSITION_SIZE_DOLLARS']:,}")
    print(f"Leverage: {config['LEVERAGE']}x")
    print(f"Commission: {config['COMMISSION_RATE']*100:.3f}%")

    # ==========================================================================
    # RUN FUTURES BACKTEST
    # ==========================================================================
    print("\n" + "="*100)
    print("RUNNING FUTURES BACKTEST")
    print("="*100)

    futures_bt = SwingStrategyBacktest(config)
    futures_bt.load_data(
        data_1min_path=data_paths['1min'],
        data_5min_path=data_paths['5min'],
        data_30min_path=data_paths['30min']
    )

    # Filter to August 2025 only (2025-08-01 to 2025-08-31)
    print("\n[FILTERING TO AUGUST 2025 ONLY]")
    futures_bt.df_1min = futures_bt.df_1min[(futures_bt.df_1min['timestamp'] >= '2025-08-01') &
                                              (futures_bt.df_1min['timestamp'] < '2025-09-01')]
    futures_bt.df_5min = futures_bt.df_5min[(futures_bt.df_5min['timestamp'] >= '2025-08-01') &
                                              (futures_bt.df_5min['timestamp'] < '2025-09-01')]
    futures_bt.df_30min = futures_bt.df_30min[(futures_bt.df_30min['timestamp'] >= '2025-08-01') &
                                                (futures_bt.df_30min['timestamp'] < '2025-09-01')]

    print(f"  1-min candles: {len(futures_bt.df_1min)}")
    print(f"  5-min candles: {len(futures_bt.df_5min)}")
    print(f"  30-min candles: {len(futures_bt.df_30min)}")

    futures_bt.calculate_indicators()
    futures_bt.run()

    # ==========================================================================
    # RUN OPTIONS BACKTEST
    # ==========================================================================
    print("\n" + "="*100)
    print("RUNNING OPTIONS BACKTEST")
    print("="*100)

    # Load data for options backtest
    df_1min = pd.read_csv(data_paths['1min'])
    df_5min = pd.read_csv(data_paths['5min'])
    df_30min = pd.read_csv(data_paths['30min'])

    # Handle timestamps
    for df in [df_1min, df_5min, df_30min]:
        if 'datetime' in df.columns:
            df['timestamp'] = pd.to_datetime(df['datetime'])
        elif 'timestamp' in df.columns:
            first_ts = df['timestamp'].iloc[0]
            if isinstance(first_ts, (int, float)) and first_ts > 1000000000:
                df['timestamp'] = pd.to_datetime(df['timestamp'], unit='s')
            else:
                df['timestamp'] = pd.to_datetime(df['timestamp'])
        df.sort_values('timestamp', inplace=True)
        df.reset_index(drop=True, inplace=True)

    # Filter to August 2025 only
    print("\n[FILTERING TO AUGUST 2025 ONLY]")
    df_1min = df_1min[(df_1min['timestamp'] >= '2025-08-01') & (df_1min['timestamp'] < '2025-09-01')]
    df_5min = df_5min[(df_5min['timestamp'] >= '2025-08-01') & (df_5min['timestamp'] < '2025-09-01')]
    df_30min = df_30min[(df_30min['timestamp'] >= '2025-08-01') & (df_30min['timestamp'] < '2025-09-01')]

    print(f"  1-min candles: {len(df_1min)}")
    print(f"  5-min candles: {len(df_5min)}")
    print(f"  30-min candles: {len(df_30min)}")

    options_bt = OptionsSellingBacktest(config, df_1min, df_5min, df_30min)
    options_bt.calculate_indicators()
    options_bt.run()

    # ==========================================================================
    # COMPARE RESULTS
    # ==========================================================================
    print("\n" + "="*100)
    print("COMPARISON RESULTS - FUTURES vs OPTIONS")
    print("="*100)

    # Calculate metrics
    futures_stats = futures_bt.stats
    options_stats = options_bt.stats

    futures_trades = futures_stats['total_trades']
    options_trades = options_stats['total_trades']

    futures_win_rate = (futures_stats['winning_trades'] / futures_trades * 100) if futures_trades > 0 else 0
    options_win_rate = (options_stats['winning_trades'] / options_trades * 100) if options_trades > 0 else 0

    futures_profit_factor = (futures_stats['gross_profit'] / futures_stats['gross_loss']) if futures_stats['gross_loss'] > 0 else 0
    options_profit_factor = (options_stats['gross_profit'] / options_stats['gross_loss']) if options_stats['gross_loss'] > 0 else 0

    # Print comparison table
    print(f"\n{'Metric':<35} {'FUTURES':>20} {'OPTIONS':>20} {'Difference':>20}")
    print("-" * 100)

    print(f"{'Total Trades':<35} {futures_trades:>20} {options_trades:>20} {options_trades - futures_trades:>20}")
    print(f"{'Winning Trades':<35} {futures_stats['winning_trades']:>20} {options_stats['winning_trades']:>20} {options_stats['winning_trades'] - futures_stats['winning_trades']:>20}")
    print(f"{'Losing Trades':<35} {futures_stats['losing_trades']:>20} {options_stats['losing_trades']:>20} {options_stats['losing_trades'] - futures_stats['losing_trades']:>20}")
    print(f"{'Win Rate (%)':<35} {futures_win_rate:>19.2f}% {options_win_rate:>19.2f}% {options_win_rate - futures_win_rate:>19.2f}%")

    print()
    print(f"{'Total P&L ($)':<35} ${futures_stats['total_pnl']:>18,.2f} ${options_stats['total_pnl']:>18,.2f} ${options_stats['total_pnl'] - futures_stats['total_pnl']:>18,.2f}")
    print(f"{'Gross Profit ($)':<35} ${futures_stats['gross_profit']:>18,.2f} ${options_stats['gross_profit']:>18,.2f} ${options_stats['gross_profit'] - futures_stats['gross_profit']:>18,.2f}")
    print(f"{'Gross Loss ($)':<35} ${futures_stats['gross_loss']:>18,.2f} ${options_stats['gross_loss']:>18,.2f} ${options_stats['gross_loss'] - futures_stats['gross_loss']:>18,.2f}")
    print(f"{'Profit Factor':<35} {futures_profit_factor:>20.2f} {options_profit_factor:>20.2f} {options_profit_factor - futures_profit_factor:>20.2f}")

    print()
    print(f"{'Max Drawdown ($)':<35} ${futures_stats['max_drawdown']:>18,.2f} ${options_stats['max_drawdown']:>18,.2f} ${options_stats['max_drawdown'] - futures_stats['max_drawdown']:>18,.2f}")
    print(f"{'Max Drawdown (%)':<35} {futures_stats['max_drawdown_pct']:>19.2f}% {options_stats['max_drawdown_pct']:>19.2f}% {options_stats['max_drawdown_pct'] - futures_stats['max_drawdown_pct']:>19.2f}%")

    print()

    # Calculate improvement
    pnl_improvement = ((options_stats['total_pnl'] - futures_stats['total_pnl']) / abs(futures_stats['total_pnl']) * 100) if futures_stats['total_pnl'] != 0 else 0

    print("="*100)
    print("SUMMARY")
    print("="*100)

    if options_stats['total_pnl'] > futures_stats['total_pnl']:
        print(f"[WIN] OPTIONS outperformed FUTURES by ${options_stats['total_pnl'] - futures_stats['total_pnl']:,.2f} ({pnl_improvement:+.2f}%)")
    else:
        print(f"[WIN] FUTURES outperformed OPTIONS by ${futures_stats['total_pnl'] - options_stats['total_pnl']:,.2f} ({-pnl_improvement:+.2f}%)")

    print()

    # Save results to file
    output_dir = os.path.join(os.path.dirname(__file__), '..', 'Temp')
    os.makedirs(output_dir, exist_ok=True)

    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')

    # Save comparison summary
    summary_file = os.path.join(output_dir, f'ETH_Q3_2025_futures_vs_options_{timestamp}.txt')
    with open(summary_file, 'w') as f:
        f.write("="*100 + "\n")
        f.write("ETH AUGUST 2025 BACKTEST - FUTURES vs OPTIONS COMPARISON\n")
        f.write("="*100 + "\n\n")

        f.write(f"Data Period: Ethereum Q3 2025 (Jul-Aug-Sep)\n")
        f.write(f"Position Size: ${config['POSITION_SIZE_DOLLARS']:,}\n")
        f.write(f"Leverage: {config['LEVERAGE']}x\n")
        f.write(f"Commission: {config['COMMISSION_RATE']*100:.3f}%\n\n")

        f.write(f"{'Metric':<35} {'FUTURES':>20} {'OPTIONS':>20} {'Difference':>20}\n")
        f.write("-" * 100 + "\n")

        f.write(f"{'Total Trades':<35} {futures_trades:>20} {options_trades:>20} {options_trades - futures_trades:>20}\n")
        f.write(f"{'Win Rate (%)':<35} {futures_win_rate:>19.2f}% {options_win_rate:>19.2f}% {options_win_rate - futures_win_rate:>19.2f}%\n")
        f.write(f"{'Total P&L ($)':<35} ${futures_stats['total_pnl']:>18,.2f} ${options_stats['total_pnl']:>18,.2f} ${options_stats['total_pnl'] - futures_stats['total_pnl']:>18,.2f}\n")
        f.write(f"{'Profit Factor':<35} {futures_profit_factor:>20.2f} {options_profit_factor:>20.2f} {options_profit_factor - futures_profit_factor:>20.2f}\n")
        f.write(f"{'Max Drawdown (%)':<35} {futures_stats['max_drawdown_pct']:>19.2f}% {options_stats['max_drawdown_pct']:>19.2f}% {options_stats['max_drawdown_pct'] - futures_stats['max_drawdown_pct']:>19.2f}%\n\n")

        if options_stats['total_pnl'] > futures_stats['total_pnl']:
            f.write(f"RESULT: OPTIONS outperformed FUTURES by ${options_stats['total_pnl'] - futures_stats['total_pnl']:,.2f} ({pnl_improvement:+.2f}%)\n")
        else:
            f.write(f"RESULT: FUTURES outperformed OPTIONS by ${futures_stats['total_pnl'] - options_stats['total_pnl']:,.2f} ({-pnl_improvement:+.2f}%)\n")

    print(f"Summary saved to: {summary_file}")

    # Save detailed futures trades
    if futures_bt.trades:
        futures_csv = os.path.join(output_dir, f'ETH_Q3_2025_FUTURES_trades_{timestamp}.csv')
        pd.DataFrame(futures_bt.trades).to_csv(futures_csv, index=False)
        print(f"Futures trades saved to: {futures_csv}")

    # Save detailed options trades
    if options_bt.trades:
        options_csv = os.path.join(output_dir, f'ETH_Q3_2025_OPTIONS_trades_{timestamp}.csv')
        pd.DataFrame(options_bt.trades).to_csv(options_csv, index=False)
        print(f"Options trades saved to: {options_csv}")

    print("\n" + "="*100)
    print("BACKTEST COMPLETED")
    print("="*100)

    return futures_bt, options_bt


if __name__ == "__main__":
    try:
        futures_result, options_result = run_eth_q3_2025_comparison()
    except Exception as e:
        print(f"\n[ERROR] Backtest failed: {e}")
        import traceback
        traceback.print_exc()
